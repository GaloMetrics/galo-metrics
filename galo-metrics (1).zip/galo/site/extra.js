/* =====================================================================
   Galo Metrics beta: recortes de gols, Pergunte ao Galo, cidades, mapa,
   estatísticas do "Fui ao estádio" e avisos de confiabilidade.
   ===================================================================== */
const G12 = new Set(['flamengo rj','fluminense rj','vasco da gama rj','botafogo rj','corinthians sp','palmeiras sp','santos sp','sao paulo sp','gremio rs','internacional rs','cruzeiro mg']);
const CLASSICOS = new Set(['cruzeiro mg','america mg']);
const ERA_AMADORA = '1933-01-01';
const nrm = s => String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase();
const mandante = j => j.galo_mandante===true || (j.galo_mandante==null && j.mando==='C');
const jogouEm = (j,n) => { const e=j.escalacao_galo; return !!e && (e.titulares.includes(n) || e.substituicoes.some(s=>s.entrou===n)); };
const comEscalacao = j => j.escalacao_galo && j.escalacao_galo.titulares && j.escalacao_galo.titulares.length && j.data>=D.meta.escalacoes_desde;

/* ---------- Gols com contexto ---------- */
let _EV = null, VIR = [];
function eventos(){
  if (_EV) return _EV;
  VIR = [];
  const out = [];
  J.forEach(j => {
    if (!j.resultado || j.gp==null) return;
    const gs = j.gols.map((g,i)=>({g,i}));
    const galo = gs.filter(o=>o.g.lado==='galo'), adv = gs.filter(o=>o.g.lado!=='galo');
    const completo = galo.length===j.gp && adv.length===j.gc && gs.every(o=>o.g.minuto!=null);
    const galoOrd = galo.every(o=>o.g.minuto!=null) || j.gp<=1 || new Set(galo.map(o=>o.g.jogador)).size===1;
    const ord = completo ? [...gs].sort((a,b)=>a.g.minuto-b.g.minuto||a.i-b.i) : null;
    let virada=false, abriu=null;
    if (ord){ let a=0,b=0,atras=false,def=0,min=null,ate=null; ord.forEach((o,k)=>{ const antes=a<b; if(o.g.lado==='galo') a++; else b++; if(a<b) atras=true; if(antes && a>=b) ate=o.g.minuto; if(b-a>def){ def=b-a; min=o.g.minuto; } if(k===0) abriu=o.i; }); virada = atras && j.resultado==='V'; if(virada) VIR.push({j, def, min, ate}); }
    else if (j.gc===0 && j.gp>0 && galoOrd){ abriu = [...galo].sort((x,y)=>(x.g.minuto??0)-(y.g.minuto??0)||x.i-y.i)[0].i; }
    const galoCron = galoOrd ? [...galo].sort((x,y)=>(x.g.minuto??0)-(y.g.minuto??0)||x.i-y.i) : null;
    const decisivo = (j.resultado==='V' && galoCron && galoCron.length===j.gp) ? galoCron[j.gc].i : null;
    gs.forEach(({g,i}) => {
      if (!isGoal(g)) return;
      const t = nrm(g.tipo);
      out.push({ j, nome:g.jogador, min:g.minuto, pen:t.includes('penal'), falta:t.includes('falta'), olimp:t.includes('olimp'),
        decisivo: decisivo===i, abriu: abriu===i, virada, tempo: g.minuto!=null ? (g.minuto<=45?1:g.minuto<=90?2:3) : (g.tempo||null) });
    });
  });
  return _EV = out;
}
const golsDeTipo = (nome, f) => eventos().filter(e=>e.nome===nome && f(e)).length;


/* ---------- Fases: finais e mata-mata ---------- */
const faseTxt = j => nrm(j.fase || ((j.competicao_raw||'').match(/\(([^)]*)\)/)||[])[1] || '');
const ehFinal = j => { if (j.final_mineiro) return true; const f=faseTxt(j); return (/fina(l|is)\b/.test(f) && !/semi|quarta|oitava/.test(f)) || (/^decis(ao|oes)$/.test(f)) || /supercopa|recopa/.test(nrm(j.competicao)); };
const ehSemi = j => /semi/.test(faseTxt(j));
let _MM=null;
function mataMata(){
  if (_MM) return _MM; const S=new Set();
  const grupo = L => { for (let i=0;i+6<=L.length;i++){ const w=L.slice(i,i+6), c={}; w.forEach(j=>{ c[j.adversario_id]=(c[j.adversario_id]||0)+1; }); const v=Object.values(c); if (v.length===3 && v.every(x=>x===2)) return new Set(w.map(j=>j.id)); } return null; };
  const por={}; J.forEach(j=>{ if(!j.resultado) return; const f=faseTxt(j), c=nrm(j.competicao);
    if (/final|semi|quarta|oitava|decis|eliminat/.test(f) || j.final_mineiro) S.add(j.id);
    if (j.grupo==='Copa do Brasil' || c==='conmebol' || /recopa|supercopa/.test(c) || (j.grupo==='Sul-Americana' && j.temporada<2021)) S.add(j.id);
    if ((j.grupo==='Libertadores' && j.temporada>=1988) || (j.grupo==='Sul-Americana' && j.temporada>=2021)) (por[j.grupo+j.temporada] ||= []).push(j); });
  Object.values(por).forEach(L=>{ L.sort((a,b)=>a.data.localeCompare(b.data)); const g=grupo(L); L.forEach(j=>{ if(!g||!g.has(j.id)) S.add(j.id); }); });
  return _MM=S;
}
const ehMata = j => mataMata().has(j.id);

/* ---------- Pergunte ao Galo ---------- */
const PF = [ // filtros reconhecidos no texto
  {id:'decisivo', t:'gol da vitória', re:/gols? da vitoria(?!s)|gol de vitoria(?!s)|decisiv|deram a vitoria|deu a vitoria|gols? vencedor|gol que decidiu/, ev:e=>e.decisivo},
  {id:'virada', t:'em viradas', re:/virada|viradas|virou|de tras/, ev:e=>e.virada, jg:null},
  {id:'abriu', t:'abrindo o placar', re:/abri[ur]+ o placar|primeiro gol do jogo|abrindo o placar/, ev:e=>e.abriu},
  {id:'V', t:'em vitórias', re:/vitori|vencid|venceu|triunfo/, jg:j=>j.resultado==='V'},
  {id:'E', t:'em empates', re:/empat/, jg:j=>j.resultado==='E'},
  {id:'D', t:'em derrotas', re:/derrot|perdid|perdeu/, jg:j=>j.resultado==='D'},
  {id:'g12', t:'contra os 12 grandes', re:/12 grandes|doze grandes|g ?12|grandes do brasil|times grandes|clubes grandes/, jg:j=>G12.has(j.adversario_id)},
  {id:'classico', t:'em clássicos (Cruzeiro e América)', re:/classico/, jg:j=>CLASSICOS.has(j.adversario_id)},
  {id:'acr', t:'aos 90 minutos ou depois', re:/acrescimo|apagar das luzes|ultimo minuto|aos 90|depois dos 90|no fim do jogo|nos 90/, ev:e=>e.min!=null&&e.min>=90},
  {id:'fim', t:'nos últimos 10 minutos', re:/minutos finais|ultimos minutos|reta final|final do jogo|fim de jogo|ultimos 10/, ev:e=>e.min!=null&&e.min>=80},
  {id:'t1', t:'no 1º tempo', re:/primeiro tempo|1o tempo|1º tempo|1 tempo/, ev:e=>e.tempo===1},
  {id:'t2', t:'no 2º tempo', re:/segundo tempo|2o tempo|2º tempo|etapa final/, ev:e=>e.tempo===2},
  {id:'pen', t:'de pênalti', re:/penalt|penalti|penalidade/, ev:e=>e.pen},
  {id:'falta', t:'de falta', re:/de falta|cobranca de falta|faltas|bola parada/, ev:e=>e.falta},
  {id:'olimp', t:'olímpicos', re:/olimpic/, ev:e=>e.olimp},
  {id:'final', t:'em finais', re:/\b(finais|final|decisoes|decisao de titulo)\b/, jg:ehFinal},
  {id:'semi', t:'em semifinais', re:/semi.?fina/, jg:ehSemi},
  {id:'mata', t:'em mata-mata', re:/mata.?mata|eliminatori|jogos de ida e volta|fases? finais|fase final/, jg:ehMata},
  {id:'casa', t:'como mandante', re:/em casa|como mandante|mandante/, jg:j=>mandante(j)},
  {id:'fora', t:'como visitante', re:/fora de casa|como visitante|visitante|longe de casa/, jg:j=>!mandante(j)&&j.mando==='F'},
  {id:'lib', t:'na Libertadores', re:/libertadores/, jg:j=>j.grupo==='Libertadores'},
  {id:'sula', t:'na Sul-Americana', re:/sul.?americana|sula\b/, jg:j=>j.grupo==='Sul-Americana'},
  {id:'cdb', t:'na Copa do Brasil', re:/copa do brasil/, jg:j=>j.grupo==='Copa do Brasil'},
  {id:'br', t:'no Brasileiro', re:/brasileir|serie a\b/, jg:j=>j.grupo==='Campeonato Brasileiro'},
  {id:'mg', t:'no Mineiro', re:/mineiro|estadual/, jg:j=>j.grupo==='Campeonato Mineiro'},
  {id:'amist', t:'em amistosos', re:/amistos/, jg:j=>j.grupo==='Amistoso'},
  {id:'conmebol', t:'em competições internacionais', re:/competic\w* internaciona|torneios? internaciona|copas? internaciona|continenta|conmebol|internacionais oficiais/, jg:j=>['Libertadores','Sul-Americana','Outras Conmebol'].includes(j.grupo)},
  {id:'intl', t:'contra estrangeiros', re:/estrangeir|times de fora do brasil|clubes de fora do brasil|gringo/, jg:j=>(j.adversario_uf||'').length===3},
  {id:'amad', t:'na era amadora', re:/era amadora|amadorismo/, jg:j=>j.data<ERA_AMADORA},
  {id:'prof', t:'na era profissional', re:/era profissional|profissionalismo/, jg:j=>j.data>=ERA_AMADORA},
];
const PEX = [ // perguntas de exemplo
  'Quem mais marcou gols de vitórias pelo Galo?', 'Quem mais marcou contra os 12 grandes?', 'Gols contra clubes do Rio de Janeiro', 'Gols em competições internacionais', 'Gols em finais', 'Gols em mata-mata', 'Jogador com mais gols em uma temporada', 'Quem fez mais gols num jogo', 'Gols em finais do Mineiro', 'Finais do Galo', 'Maiores goleadas contra o Cruzeiro', 'Piores derrotas na Libertadores', 'Viradas contra clubes paulistas', 'Gols excluindo o Campeonato Mineiro',
  'Quem fez mais gols de falta?', 'Quem mais marcou o gol da vitória?', 'Quem mais marcou em clássicos?', 'Quem mais marcou em viradas?',
  'Quem mais marcou na Libertadores?', 'Quem mais marcou contra o Cruzeiro no Mineirão?', 'Quem mais jogou nos anos 80?',
  'Jogador com mais vitórias desde 2000', 'Técnico com mais vitórias', 'Adversário que o Galo mais venceu', 'Estádio com mais jogos',
  'Cidade com mais jogos fora de BH', 'Quem mais marcou de pênalti no Brasileiro?', 'Quem mais abriu o placar?', 'Temporada com mais gols',
];

function entende(q){
  const t = ' '+nrm(q).replace(/[?!.,;:]/g,' ').replace(/\s+/g,' ')+' ';
  const r = {sujeito:'jogador', metrica:'gols', filtros:[], extra:[], ano:null, texto:q};
  // sujeito
  const pessoa = /\bquem\b|jogador|artilheiro|atleta/.test(t);
  const JQ = [[/goleadas?|vitorias? (mais )?elastica|maiores vitorias|melhores vitorias|vitorias mais amplas/,'saldo'],[/piores derrotas|maiores derrotas|derrotas mais (dura|elastica|amplas)|goleadas sofridas|levou de/,'derrota'],
    [/empates? com mais gols|maiores empates/,'empate'],[/jogos com mais gols|partidas com mais gols|jogos mais movimentados/,'gols'],[/maiores publicos|jogos com mais publico|jogos mais cheios|maior publico/,'publico'],[/viradas?\b|virou o jogo|jogos de virada/,'virada'],[/^ *(as )?(finais|decisoes)( do galo)?|todas as finais|jogos? (de|em) finais?|finais disputadas|^ *(os )?jogos de mata.?mata|^ *(as )?semifinais/,'data']];
  const jq = !pessoa && !/\b(estadio|cidade|tecnico|treinador|temporada|adversario)s? (com|que)/.test(t) && JQ.find(([re])=>re.test(t));
  if (jq) { r.sujeito='jogo'; r.ordem=jq[1]; }
  else if (/tecnico|treinador|comandante/.test(t)) r.sujeito='tecnico';
  else if (pessoa) r.sujeito='jogador';
  else if (/\bestadio|\barena\b/.test(t) && !/\bno estadio|\bna arena/.test(t)) r.sujeito='estadio';
  else if (/\bcidade/.test(t) && !/na cidade de/.test(t)) r.sujeito='cidade';
  else if (/\b(temporada|ano)\b/.test(t) && !/\banos \d/.test(t) && !/(uma|um|numa|num|mesma|so|unica) (temporada|ano)\b/.test(t)) r.sujeito='temporada';
  else if (/adversari|fregues|\btime\b|\bclube\b|\bequipe\b|\bvitima/.test(t) && !/jogador/.test(t)) r.sujeito='adversario';
  // métrica
  const fala = re => re.test(t);
  if (fala(/hat.?trick|tres gols|3 gols|tripleta/)) r.metrica='hat';
  else if (fala(/jogos marcando|jogos com gol|partidas marcando/)) r.metrica='jogos_gol';
  else if (fala(/media de gols|gols por jogo/)) r.metrica='media';
  else if (fala(/\bgol(?!eir)|marc|artilh|balanc|anotou|fez mais/)) r.metrica='gols';
  else if (fala(/vitori|venc|ganh|fregues/)) r.metrica='V';
  else if (fala(/derrot|perd/)) r.metrica='D';
  else if (fala(/empat/)) r.metrica='E';
  else if (fala(/titular/)) r.metrica='titular';
  else if (fala(/aproveitamento/)) r.metrica='aprov';
  else if (fala(/public|torcedor|gente|pessoas/)) r.metrica='publico';
  else if (fala(/jog|partida|atuou|vezes|enfrent|disput/)) r.metrica='jogos';
  // filtros (sem repetir o que virou métrica)
  const usados = new Set();
  const NEG = /(exclu\w*|exceto|menos|sem contar|sem|tirando|fora|nao contando|descontando|ignorando)( o| a| os| as| do| da| dos| das| em| no| na| nos| nas| de| jogos d[oa]s?| gols d[oa]s?)?( o| a)?( campeonato| copa| torneio| jogos| partidas| competicao)?( d[oa]s?| de)? *$/;
  const negado = (re) => { const m = t.match(re); if (!m) return false; return NEG.test(t.slice(Math.max(0, m.index-40), m.index)); };
  const nega = f => ({...f, t:'sem '+f.t.replace(/^(em|no|na|nos|nas|de|contra|como|aos) /,''), ev: f.ev && (e=>!f.ev(e)), jg: f.jg && (j=>!f.jg(j))});
  const tSemFim = t.replace(/minutos finais|reta final|final do jogo|finais de jogo|fim de jogo|semi.?finais?|fases? finais|fase final/g,' ');
  PF.forEach(f => { if (!f.re.test(f.id==='final'?tSemFim:t)) return;
    if (['V','E','D'].includes(f.id) && r.metrica===f.id) return;
    if (negado(f.re)) { usados.add(f.id); r.filtros.push(nega(f)); return; }
    if (['V','E','D'].includes(f.id) && r.metrica===f.id) return;
    if (f.id==='V' && (usados.has('decisivo')||usados.has('virada'))) return;
    if (f.id==='fim' && usados.has('acr')) return;
    if (f.id==='br' && /copa do brasil|grandes do brasil|fora do brasil/.test(t) && !/brasileira?o|brasileiro /.test(t.replace(/copa do brasil|grandes do brasil|fora do brasil/g,''))) return;
    usados.add(f.id); r.filtros.push(f); });
  // período
  let m;
  if ((m = t.match(/(?:decada de |anos )(19|20)?(\d)0/))) { const c = m[1] || (+m[2]<=2?'20':'19'); const d=+(c+m[2]+'0'); r.extra.push({t:`nos anos ${String(d).slice(2)}`, jg:j=>j.temporada>=d&&j.temporada<d+10}); }
  if ((m = t.match(/\bde (\d{4}) a (\d{4})/))) { const a=+m[1], b=+m[2]; r.extra.push({t:`de ${a} a ${b}`, jg:j=>j.temporada>=a&&j.temporada<=b}); }
  else if ((m = t.match(/\b(?:desde|a partir de|depois de) (\d{4})/))) { const a=+m[1]; r.extra.push({t:`desde ${a}`, jg:j=>j.temporada>=a}); }
  else if ((m = t.match(/\bantes de (\d{4})/))) { const a=+m[1]; r.extra.push({t:`antes de ${a}`, jg:j=>j.temporada<a}); }
  else if ((m = t.match(/\b(?:em|no ano de|na temporada) (19\d\d|20\d\d)\b/))) { const a=+m[1]; r.extra.push({t:`em ${a}`, jg:j=>j.temporada===a}); }
  if (/fora de bh|fora de belo horizonte/.test(t)) r.extra.push({t:'fora de Belo Horizonte', jg:j=>j.cidade && j.cidade!=='Belo Horizonte, MG'});
  // adversário citado
  const adv = advRows().filter(a=>a.J>=3).map(a=>({a, k:nrm(a.nome)})).filter(x=>x.k.length>=4 && x.k!=='atletico')
    .sort((x,y)=>y.k.length-x.k.length).find(x=>new RegExp(`(contra|diante d[oa]|sobre|em cima d[oa]|x|vs|enfrentando|frente a|no classico com) (o |a |os )?${x.k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\b`).test(t));
  if (adv) r.extra.push({t:`contra ${adv.a.nome}`, jg:j=>j.adversario_id===adv.a.id});
  else { const advN = advRows().filter(a=>a.J>=3).map(a=>({a, k:nrm(a.nome)})).filter(x=>x.k.length>=4 && x.k!=='atletico').sort((x,y)=>y.k.length-x.k.length)
      .find(x=>new RegExp(`(exclu\\w*|exceto|menos|sem|tirando|fora) (o |a |os |jogos contra o |jogos contra a )?${x.k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\b`).test(t));
    if (advN) r.extra.push({t:`sem ${advN.a.nome}`, jg:j=>j.adversario_id!==advN.a.id}); }
  const REG = [['RJ','do Rio de Janeiro',/rio de janeiro|\bdo rio\b|carioca|fluminenses do estado/],['SP','de São Paulo',/(clubes|times|equipes|adversarios) (de|do estado de) sao paulo|paulista/],['RS','do Rio Grande do Sul',/rio grande do sul|gauch/],
    ['MG','de Minas Gerais',/(clubes|times|equipes|adversarios) (de|do interior de) minas|mineiros/],['PR','do Paraná',/parana(ense)?s?\b/],['SC','de Santa Catarina',/santa catarina|catarinense/],['BA','da Bahia',/(clubes|times) da bahia|baian/],['PE','de Pernambuco',/pernambuc/],
    ['GO','de Goiás',/goias|goian/],['CE','do Ceará',/ceara|cearense/],['ES','do Espírito Santo',/espirito santo|capixaba/],['DF','do Distrito Federal',/distrito federal|brasilienses/],
    ['ARG','da Argentina',/argentin/],['URU','do Uruguai',/urugua/],['PAR','do Paraguai',/paragua/],['COL','da Colômbia',/colombia/],['CHI','do Chile',/chile/],['BOL','da Bolívia',/bolivia/],['PER','do Peru',/peru(ano|ana)?s?\b/],['ECU','do Equador',/equador|equatorian/],['VEN','da Venezuela',/venezuel/],['MEX','do México',/mexic/],['ITA','da Itália',/italia(no)?s?\b/],['ESP','da Espanha',/espanh/],['POR','de Portugal',/portug/]];
  const NE = /nordest/.test(t) ? new Set(['BA','PE','CE','RN','PB','AL','SE','PI','MA']) : null;
  if (NE) r.extra.push({t:'contra clubes do Nordeste', jg:j=>NE.has(j.adversario_uf)});
  if (/(clubes|times|equipes|adversarios|contra|rivais)/.test(t)) REG.forEach(([uf,nome,re])=>{ const m=t.match(re); if(!m) return; if(uf==='MG' && /campeonato mineiro|no mineiro/.test(t) && !/mineiros/.test(t)) return;
    const neg = NEG.test(t.slice(Math.max(0,m.index-40), m.index)); r.extra.push({t:(neg?'sem clubes ':'contra clubes ')+nome, jg:j=>neg?j.adversario_uf!==uf:j.adversario_uf===uf}); });
  // estádio citado
  const ests = Object.keys(estadiosAll()).map(e=>({e, k:nrm(e)})).filter(x=>x.k.length>=5).sort((x,y)=>y.k.length-x.k.length);
  const est = ests.find(x=>new RegExp(`(no|na|em|estadio|estadio do|estadio da) ${x.k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\b`).test(t) && !(adv && adv.k===x.k));
  if (est && r.sujeito!=='estadio') r.extra.push({t:`no ${est.e}`, jg:j=>j.estadio===est.e});
  // cidade citada ("em Sete Lagoas", "na cidade de ...")
  const cids = Object.keys(cidadesAll()).map(c=>({c, k:nrm(c.split(',')[0])})).filter(x=>x.k.length>=4 && !['casa','belo'].includes(x.k)).sort((x,y)=>y.k.length-x.k.length);
  const cid = cids.find(x=>new RegExp(`(em|na cidade de|no|na) ${x.k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\b`).test(t));
  if (cid && r.sujeito!=='cidade') r.extra.push({t:`em ${cid.c.split(',')[0]}`, jg:j=>j.cidade===cid.c});
  if (/\b(pior|piores|menor)\b|\bmenos (gols|jogos|vitorias|derrotas)\b|^ *quem menos/.test(t)) r.asc = true;
  if (/(em|numa|de|por|na mesma|numa unica|em uma unica) (uma |um )?(so |unica |mesma )?(temporada|ano)\b|num (so |unico )?ano\b|numa temporada|em um ano|em uma temporada/.test(t) && !/\bem (19|20)\d\d/.test(t)) r.por='temporada';
  else if (/(em|num|numa) (um |uma )?(so |unico |unica |mesmo |mesma )?(jogo|partida)\b|num jogo|numa partida/.test(t)) r.por='jogo';
  if (/goleir|arqueir/.test(t)) { r.goleiro = true; if (r.metrica==='gols' && !/gols? (de|do|feitos)/.test(t)) r.metrica='jogos'; }
  return r;
}
function responde(r){
  const fj = j => r.filtros.every(f=>!f.jg || f.jg(j)) && r.extra.every(f=>f.jg(j));
  const fe = e => r.filtros.every(f=>!f.ev || f.ev(e)) && fj(e.j);
  const temEv = r.filtros.some(f=>f.ev);
  const jogos = J.filter(j=>j.resultado && fj(j));
  const conta = (lista, key, val=()=>1) => { const m={}; lista.forEach(x=>{ const k=key(x); if(k==null) return; m[k]=(m[k]||0)+val(x); }); return m; };
  let linhas=[], unid='', nota='';
  const ord = o => Object.entries(o).filter(([,v])=>v>0).sort((a,b)=>r.asc?a[1]-b[1]:b[1]-a[1]);
  if (r.sujeito==='jogo'){
    eventos(); let L=J.filter(j=>j.resultado&&j.gp!=null&&fj(j)), extra=()=> '';
    if (r.ordem==='saldo') L=L.filter(j=>j.resultado==='V').sort((a,b)=>(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp);
    else if (r.ordem==='derrota') L=L.filter(j=>j.resultado==='D').sort((a,b)=>(b.gc-b.gp)-(a.gc-a.gp)||b.gc-a.gc);
    else if (r.ordem==='empate') L=L.filter(j=>j.resultado==='E').sort((a,b)=>b.gp-a.gp);
    else if (r.ordem==='gols') L=L.sort((a,b)=>(b.gp+b.gc)-(a.gp+a.gc));
    else if (r.ordem==='publico'){ L=L.filter(j=>j.publico).sort((a,b)=>b.publico-a.publico); extra=j=>`${N(j.publico)} pessoas`; }
    else if (r.ordem==='data'){ L=L.sort((a,b)=>b.data.localeCompare(a.data)); extra=j=>esc(j.fase||''); }
    else if (r.ordem==='virada'){ const m=new Map(VIR.map(v=>[v.j.id,v])); L=L.filter(j=>m.has(j.id)).sort((a,b)=>m.get(b.id).def-m.get(a.id).def||b.data.localeCompare(a.data)); extra=j=>{ const v=m.get(j.id); return `perdia por ${v.def}${v.ate!=null?`, empatou aos ${v.ate}'`:''}`; }; }
    const U={data:'lista, da mais recente para a mais antiga',saldo:'maiores vitórias',derrota:'piores derrotas',empate:'empates com mais gols',gols:'jogos com mais gols',publico:'maiores públicos',virada:'viradas'};
    return {jogos:L, extra, unid:U[r.ordem], total:L.length, nota:r.ordem==='virada'?'Só entram jogos com o minuto de todos os gols registrado.':r.filtros.some(f=>['final','semi','mata'].includes(f.id))?avisoFases():''};
  }
  const jogosDe = n => {
    if (['gols','hat','jogos_gol','media'].includes(r.metrica) || temEv){ const c={}; eventos().filter(e=>e.nome===n&&fe(e)).forEach(e=>{ c[e.j.id]=(c[e.j.id]||0)+1; }); return Object.keys(c).map(id=>byId[id]).sort((a,b)=>a.data.localeCompare(b.data)).map(j=>({j, g:c[j.id]})); }
    return jogos.filter(comEscalacao).filter(j=>(r.metrica==='titular'?j.escalacao_galo.titulares:elenco(j.escalacao_galo)).includes(n)).filter(j=>!['V','E','D'].includes(r.metrica)||j.resultado===r.metrica).map(j=>({j, g:j.gols.filter(g=>isGoal(g)&&g.jogador===n).length}));
  };
  if (r.sujeito==='jogador'){
    if (['gols','hat','jogos_gol','media'].includes(r.metrica) || temEv){
      const ev = eventos().filter(fe);
      if (r.metrica==='hat'){ const pj=conta(ev,e=>e.nome+'|'+e.j.id); const h={}; Object.entries(pj).forEach(([k,v])=>{ if(v>=3){ const n=k.split('|')[0]; h[n]=(h[n]||0)+1; } }); linhas=ord(h); unid='jogos com 3 ou mais gols'; }
      else if (r.metrica==='jogos_gol'){ const s={}; ev.forEach(e=>{ (s[e.nome] ||= new Set()).add(e.j.id); }); linhas=ord(Object.fromEntries(Object.entries(s).map(([k,v])=>[k,v.size]))); unid='jogos marcando'; }
      else if (r.metrica==='media'){ const g=conta(ev.filter(e=>comEscalacao(e.j)),e=>e.nome); const jj=conta(jogos.filter(comEscalacao).flatMap(j=>[...j.escalacao_galo.titulares,...j.escalacao_galo.substituicoes.map(s=>s.entrou)].filter(Boolean).map(n=>({n}))),x=>x.n);
        linhas=Object.entries(g).filter(([n])=>(jj[n]||0)>=30).map(([n,v])=>[n,+(v/jj[n]).toFixed(2)]).sort((a,b)=>b[1]-a[1]); unid='gols por jogo (mín. 30 jogos, desde '+D.meta.escalacoes_desde.slice(0,4)+')'; }
      else if (r.por){ linhas=ord(conta(ev,e=>e.nome+'|'+(r.por==='temporada'?e.j.temporada:e.j.id))); unid=r.por==='temporada'?'gols numa temporada':'gols num jogo'; }
      else { linhas=ord(conta(ev,e=>e.nome)); unid='gols'; if(!r.filtros.length&&!r.extra.length) nota='Contagem jogo a jogo da base. Para alguns artilheiros o número aceito pelo clube é maior (Reinaldo, por exemplo, tem 255); veja o perfil de cada um.'; }
      if (r.filtros.some(f=>['acr','fim','t1','t2'].includes(f.id))) nota='Conta só os gols com minuto registrado. As fichas não separam os acréscimos: um gol aos 90+3 aparece como 90.';
      if (r.filtros.some(f=>['decisivo','virada','abriu'].includes(f.id))) nota='Conta só os jogos em que a ordem dos gols é conhecida (minuto de todos os gols, ou um único gol do Galo).';
      if (r.filtros.some(f=>['pen','falta','olimp'].includes(f.id))) nota=avisoBolaParada();
      if (r.filtros.some(f=>['final','semi','mata'].includes(f.id))) nota=avisoFases();
    } else {
      const ap = jogos.filter(comEscalacao).filter(j=>r.metrica!=='V'||j.resultado==='V').filter(j=>r.metrica!=='D'||j.resultado==='D').filter(j=>r.metrica!=='E'||j.resultado==='E');
      const lista = ap.flatMap(j=>[...(r.metrica==='titular'?j.escalacao_galo.titulares:[...j.escalacao_galo.titulares,...j.escalacao_galo.substituicoes.map(s=>s.entrou)])].filter(Boolean));
      linhas=ord(conta(lista,n=>n));
      if (r.por==='temporada'){ const m={}; ap.forEach(j=>(r.metrica==='titular'?j.escalacao_galo.titulares:elenco(j.escalacao_galo)).forEach(n=>{ const k=n+'|'+j.temporada; m[k]=(m[k]||0)+1; })); linhas=ord(m); }
      if (r.asc){ const tot=conta(jogos.filter(comEscalacao).flatMap(j=>elenco(j.escalacao_galo)),n=>n); const base=conta(lista,n=>n); linhas=Object.keys(tot).filter(n=>tot[n]>=100).map(n=>[n,base[n]||0]).sort((a,b)=>a[1]-b[1]); nota='Entre jogadores com pelo menos 100 jogos. '; }
      unid=({V:'vitórias em campo',D:'derrotas em campo',E:'empates em campo',titular:'jogos como titular'}[r.metrica]||'jogos')+(r.por==='temporada'?' numa temporada':'');
      nota=(nota||'')+`Jogos contados a partir de ${fmtD(D.meta.escalacoes_desde)}, quando as escalações ficam completas.`;
    }
    if (r.goleiro) linhas=linhas.filter(([n])=>{ try{ return posTxt(n)==='Goleiro'; }catch(e){ return false; } });
    const rot = n => { if(!n.includes('|')) return nomeV(n); const [a,b]=n.split('|'); return r.por==='jogo'&&byId[b] ? `${nomeV(a)} · ${byId[b].adversario} ${placar(byId[b])} (${fmtD(byId[b].data)})` : `${nomeV(a)} · ${b}`; };
    return {linhas:linhas.slice(0,25).map(([n,v])=>({href:'#jogador-'+slug(n.split('|')[0]), nome:rot(n), cheio:n, v})), unid, nota, total:linhas.length, jogosDe:n=>{ const [a,b]=n.split('|'); const l=jogosDe(a); return b?l.filter(x=>r.por==='jogo'?String(x.j.id)===b:String(x.j.temporada)===b):l; }};
  }
  const agrupa = (key, nome, href) => {
    const m={}; jogos.forEach(j=>{ const k=key(j); if(!k) return; const o=(m[k] ||= {k, nome:nome(j), href:href(j), l:[]}); o.l.push(j); });
    const val = o => { const rr=rec(o.l); return r.metrica==='V'?rr.V:r.metrica==='D'?rr.D:r.metrica==='E'?rr.E:r.metrica==='gols'?rr.gp:r.metrica==='aprov'?(o.l.length>=20?Math.round(100*pct(rr)):0):r.metrica==='publico'?o.l.reduce((s,j)=>s+(j.publico||0),0):o.l.length; };
    return Object.values(m).map(o=>({...o, v:val(o)})).filter(o=>o.v>0).sort((a,b)=>r.asc?a.v-b.v:b.v-a.v);
  };
  const U = {V:'vitórias do Galo',D:'derrotas do Galo',E:'empates',gols:'gols do Galo',aprov:'% de aproveitamento (mín. 20 jogos)',publico:'pessoas (público somado)'};
  let L;
  if (r.sujeito==='tecnico') L=agrupa(j=>j.tecnico_galo, j=>j.tecnico_galo, j=>'#tecnicos');
  else if (r.sujeito==='adversario') L=agrupa(j=>j.adversario_id, j=>(advRows().find(a=>a.id===j.adversario_id)||j).nome||j.adversario, j=>'#adversario-'+slug(j.adversario_id));
  else if (r.sujeito==='estadio') L=agrupa(j=>j.estadio&&!/n[ãa]o identificado/i.test(j.estadio)?j.estadio:null, j=>j.estadio, j=>linkJogos({est:j.estadio}));
  else if (r.sujeito==='cidade') L=agrupa(j=>j.cidade, j=>j.cidade, j=>'#cidade-'+slug(j.cidade));
  else L=agrupa(j=>String(j.temporada), j=>String(j.temporada), j=>'#temporada-'+j.temporada);
  return {linhas:L.slice(0,25).map(o=>({href:o.href, nome:o.nome, cheio:o.k, v:o.v})), unid:U[r.metrica]||'jogos', total:L.length, jogosDe:k=>(L.find(o=>String(o.k)===String(k))||{l:[]}).l.map(j=>({j, g:null})),
    nota: r.sujeito==='tecnico'?'Técnico conforme as fichas (desde 1930 quase completo).':r.metrica==='publico'?'Soma do público registrado nas fichas; jogos sem público informado ficam de fora.':''};
}
function avisoFases(){ return 'Finais e semifinais vêm da fase anotada na ficha. Mata-mata inclui toda a Copa do Brasil, a Copa Conmebol, a Sul-Americana até 2020, a Libertadores (desde 1988) e a Sul-Americana (desde 2021) fora da fase de grupos, e os jogos marcados como final, semifinal, quartas ou decisão. Fases eliminatórias antigas do Brasileiro quase nunca estão anotadas.'; }
function avisoBolaParada(){ return 'Gols de pênalti e de falta dependem do que cada ficha anota. Antes de 2000 muitas fichas não dizem como o gol saiu, então esses números tendem a ficar abaixo do real.'; }

function buscaEntidades(q){
  const k = nrm(q).trim(); if (k.length<2) return '';
  const tem = s => nrm(s).includes(k);
  const jog = D.jogadores.filter(p=>tem(p.nome)).sort((a,b)=>golsBest(b)+b.jogos-(golsBest(a)+a.jogos)).slice(0,12);
  const adv = advRows().filter(a=>tem(a.nome)).sort((a,b)=>b.J-a.J).slice(0,10);
  const cid = Object.entries(cidadesAll()).filter(([c])=>tem(c)).sort((a,b)=>b[1].l.length-a[1].l.length).slice(0,10);
  const est = Object.entries(estadiosAll()).filter(([e])=>tem(e)).sort((a,b)=>b[1]-a[1]).slice(0,10);
  const tec = (D.tecnicos||[]).filter(t=>tem(t.nome)).slice(0,8);
  const temp = /^\d{4}$/.test(k) && J.some(j=>j.temporada===+k) ? [+k] : [];
  const bloco = (tit, itens) => itens.length?`<div class="busca-b"><h3>${tit}</h3><ul>${itens.join('')}</ul></div>`:'';
  const html = bloco('Jogadores', jog.map(p=>`<li><a href="#jogador-${slug(p.nome)}">${esc(p.nome)}</a> <small class="uf">${N(golsBest(p))} gols${p.jogos?' · '+N(p.jogos)+' jogos':''} · ${(p.primeiro||'').slice(0,4)}–${(p.ultimo||'').slice(0,4)}</small></li>`))
    + bloco('Adversários', adv.map(a=>`<li>${cr(a.id)}<a href="#adversario-${slug(a.id)}">${esc(a.nome)}</a> <small class="uf">${a.J} jogos</small></li>`))
    + bloco('Cidades', cid.map(([c,o])=>`<li><a href="#cidade-${slug(c)}">${esc(c)}</a> <small class="uf">${o.l.length} jogos</small></li>`))
    + bloco('Estádios', est.map(([e,n])=>`<li><a href="${linkJogos({est:e})}">${esc(e)}</a> <small class="uf">${n} jogos</small></li>`))
    + bloco('Técnicos', tec.map(t=>`<li><a href="#tecnicos">${esc(t.nome)}</a> <small class="uf">${t.jogos} jogos · ${t.V}V ${t.E}E ${t.D}D</small></li>`))
    + bloco('Temporada', temp.map(y=>`<li><a href="#temporada-${y}">Temporada ${y}</a></li>`));
  return html;
}
function vPergunte(params){
  const q = new URLSearchParams(params||'').get('q')||'';
  let corpo = '';
  if (q.trim()){
    const r = entende(q), ents = buscaEntidades(q);
    const ehPergunta = /quem|qual|quais|mais|maior|menos|ranking|top|melhor|artilheiro|\bgols?\b|\bjogos\b|vitorias|derrotas|hat|viradas?/.test(nrm(q)) || r.filtros.length || r.extra.length;
    if (ehPergunta){
      const res = responde(r);
      const P = new URLSearchParams(params||''), ver = P.get('ver');
      const verLink = x => res.jogosDe ? `<a class="rank-ver" href="#pergunte?${new URLSearchParams({q, ver:x.cheio})}">jogos →</a>` : '';
      if (r.sujeito==='jogo'){
        corpo += `<div class="entendi"><span class="osw">Entendi</span> <b>Jogos</b>: <b>${esc(res.unid)}</b>${[...r.filtros,...r.extra].map(f=>` <span class="chip">${esc(f.t)}</span>`).join('')}</div>
        ${res.jogos.length?`<table><thead><tr><th>Data</th><th></th><th>Partida</th><th class="hide-s">Competição</th><th class="n"></th></tr></thead><tbody>${res.jogos.slice(0,50).map(j=>`<tr class="click" onclick="location.hash='jogo-${j.id}'"><td class="mono">${fmtD(j.data,j.data_aprox)}</td><td>${resBox(j)}</td><td>${linha(j)}</td><td class="hide-s">${esc(j.competicao||'')}</td><td class="n uf">${res.extra(j)}</td></tr>`).join('')}</tbody></table>`:'<p class="empty">Nenhum jogo com esses filtros.</p>'}
        ${res.nota?`<p class="count">${esc(res.nota)}</p>`:''}<p class="count">${N(res.total)} jogos${res.total>50?', mostrando os 50 primeiros':''}.</p>`;
      } else {
      const SU={jogador:r.goleiro?'Goleiros':'Jogadores',tecnico:'Técnicos',adversario:'Adversários',estadio:'Estádios',cidade:'Cidades',temporada:'Temporadas'}[r.sujeito];
      corpo += `<div class="entendi"><span class="osw">Entendi</span> <b>${SU}</b> com mais <b>${esc(res.unid)}</b>${[...r.filtros,...r.extra].map(f=>` <span class="chip">${esc(f.t)}</span>`).join('')}${r.asc?' <span class="chip">do menor para o maior</span>':''}</div>
      ${res.linhas.length?`<ol class="rank">${res.linhas.map((x,i)=>`<li><span class="rank-n">${i+1}</span><a href="${x.href}">${esc(x.nome)}</a>${verLink(x)}<b>${Number.isInteger(x.v)?N(x.v):String(x.v).replace('.',',')}</b></li>`).join('')}</ol>`:'<p class="empty">Nada encontrado com esses filtros.</p>'}
      ${res.nota?`<p class="count">${esc(res.nota)}</p>`:''}${res.total>25?`<p class="count">Mostrando 25 de ${N(res.total)}.</p>`:''}`;
      if (ver && res.jogosDe){ const L=res.jogosDe(ver); const nome=res.linhas.find(x=>String(x.cheio)===ver)?.nome||ver;
        corpo += `<h2 id="verjogos">Os jogos: ${esc(nomeV(nome))} <small class="uf">${L.length} ${L.length===1?'jogo':'jogos'}</small></h2>
        <table><thead><tr><th>Data</th><th></th><th>Partida</th><th class="hide-s">Competição</th><th class="n">${r.sujeito==='jogador'?'Gols':''}</th></tr></thead><tbody>${[...L].reverse().map(({j,g})=>`<tr class="click" onclick="location.hash='jogo-${j.id}'"><td class="mono">${fmtD(j.data,j.data_aprox)}</td><td>${resBox(j)}</td><td>${linha(j)}</td><td class="hide-s">${esc(j.competicao||'')}</td><td class="n">${g||''}</td></tr>`).join('')}</tbody></table>`;
        setTimeout(()=>{ const h=document.getElementById('verjogos'); if(h) h.scrollIntoView({behavior:'smooth'}); }, 50); }
      }
    }
    if (ents) corpo += `<h2>${ehPergunta?'Também na base':'Resultados da busca'}</h2><div class="busca-grid">${ents}</div>`;
    if (!corpo) corpo = `<p class="empty">Não achei nada para "${esc(q)}". Tente um nome, uma cidade ou uma das perguntas de exemplo.</p>`;
  }
  setTimeout(()=>{ const f=$('#pqform'); if(f) f.onsubmit=e=>{ e.preventDefault(); location.hash='pergunte?'+new URLSearchParams({q:$('#pq').value}); }; const i=$('#pq'); if(i&&!q) i.focus(); });
  return `<div class="kicker">Almanaque · busca</div><h1>Pergunte ao Galo</h1>
  <p class="lede">Escreva do seu jeito: um nome, uma cidade, um estádio, ou uma pergunta como "quem mais marcou contra os 12 grandes".</p>
  <form id="pqform" class="pq"><input id="pq" type="search" value="${esc(q)}" placeholder="Ex.: quem mais marcou gols de falta na Libertadores?" aria-label="Pergunta ou busca"><button class="more" type="submit">Perguntar</button></form>
  ${corpo}
  <h2>Experimente</h2><div class="pq-ex">${PEX.map(x=>`<a class="chip" href="#pergunte?${new URLSearchParams({q:x})}">${esc(x)}</a>`).join('')}</div>
  <p class="count">Entende: gols, jogos, vitórias, derrotas, empates, hat-tricks, jogos marcando, média de gols, público; recortes como em vitórias, gol da vitória, viradas, abrindo o placar, 12 grandes, clássicos, acréscimos, minutos finais, 1º e 2º tempo, pênalti, falta, olímpico, em casa, fora, competições, estrangeiros, era amadora; períodos (anos 70, desde 2000, de 1970 a 1980, em 1977); um adversário ("contra o Cruzeiro"), um estádio ("no Mineirão") ou uma cidade ("em Sete Lagoas").</p>`;
}

/* ---------- Cidades ---------- */
let _CID=null, _EST=null;
function cidadesAll(){ if(_CID) return _CID; const m={}; J.forEach(j=>{ if(!j.cidade) return; (m[j.cidade] ||= {l:[]}).l.push(j); }); return _CID=m; }
function estadiosAll(){ if(_EST) return _EST; const m={}; J.forEach(j=>{ if(j.estadio && !/n[ãa]o identificado/i.test(j.estadio)) m[j.estadio]=(m[j.estadio]||0)+1; }); return _EST=m; }
const geoC = c => ((D.geo||{}).cidades||{})[c];
function cidadeRows(){ return Object.entries(cidadesAll()).map(([c,o])=>{ const r=rec(o.l), g=geoC(c)||{}; return {c, nome:c.split(',')[0], reg:g.uf||g.pais||c.split(', ')[1]||'', pais:g.pais||'Brasil', l:o.l, ...r, ap:aprov(r), est:new Set(o.l.map(j=>j.estadio).filter(Boolean)).size}; }).sort((a,b)=>b.l.length-a.l.length); }
function vCidades(){
  const rows = cidadeRows();
  setTimeout(()=>{ const i=$('#cq'); if(!i) return; const tb=$('#ctab tbody'); const draw=()=>{ const k=nrm(i.value); tb.innerHTML=rows.filter(r=>!k||nrm(r.c+' '+r.pais).includes(k)).slice(0,400).map(r=>`<tr class="click" onclick="location.hash='cidade-${slug(r.c)}'"><td><b>${esc(r.nome)}</b></td><td>${esc(r.reg)}</td><td class="n">${N(r.l.length)}</td><td class="n hide-s">${r.V}</td><td class="n hide-s">${r.E}</td><td class="n hide-s">${r.D}</td><td class="n">${r.ap}</td><td class="n hide-s">${r.est}</td></tr>`).join(''); }; i.oninput=draw; draw(); });
  const br=rows.filter(r=>r.pais==='Brasil');
  return `<div class="kicker">Almanaque · onde o Galo jogou</div><h1>Cidades</h1>
  <p class="lede">${N(rows.length)} cidades em ${new Set(rows.map(r=>r.pais)).size} países, ${new Set(br.map(r=>r.reg)).size} estados brasileiros. <a href="#mapa">Ver no mapa →</a></p>
  <input id="cq" type="search" placeholder="Buscar cidade, estado ou país" aria-label="Buscar cidade" class="busca-in">
  <table id="ctab"><thead><tr><th>Cidade</th><th>UF / país</th><th class="n">Jogos</th><th class="n hide-s">V</th><th class="n hide-s">E</th><th class="n hide-s">D</th><th class="n">Aprov.</th><th class="n hide-s">Estádios</th></tr></thead><tbody></tbody></table>
  <p class="count">Cidade conforme as fichas; em ${N(J.filter(j=>j.cidade_inferida).length)} jogos ela veio do estádio. Jogos sem cidade nem estádio ficam de fora.</p>`;
}
function vCidade(s){
  const row = cidadeRows().find(r=>slug(r.c)===s); if(!row) return '<p class="empty">Cidade não encontrada.</p>';
  const l=row.l, r=rec(l), g=geoC(row.c);
  const est={}; l.forEach(j=>{ if(j.estadio && !/n[ãa]o identificado/i.test(j.estadio)) est[j.estadio]=(est[j.estadio]||0)+1; });
  const adv={}; l.forEach(j=>{ const a=(adv[j.adversario_id] ||= {n:j.adversario,id:j.adversario_id,l:[]}); a.l.push(j); });
  const pub=l.reduce((s,j)=>s+(j.publico||0),0);
  const gol={}; l.forEach(j=>j.gols.forEach(x=>{ if(isGoal(x)) gol[x.jogador]=(gol[x.jogador]||0)+1; }));
  return `<a class="back" href="#cidades">← Cidades</a><div class="kicker">${esc(g&&g.pais!=='Brasil'?g.pais:(g&&g.estado)||row.reg)} · ${fmtD(l[0].data,l[0].data_aprox)} a ${fmtD(l[l.length-1].data)}</div><h1>${esc(row.nome)}</h1>
  ${tiles(r)}${resultBar(r)}
  ${pub?`<p class="count">Público somado nas fichas: <b>${N(pub)}</b> pessoas.</p>`:''}
  <div class="grid2"><div><h2>Estádios</h2><table><tbody>${Object.entries(est).sort((a,b)=>b[1]-a[1]).map(([e,n])=>`<tr class="click" onclick="location.hash='${linkJogos({est:e})}'"><td>${esc(e)}</td><td class="n">${n}</td></tr>`).join('')||'<tr><td>Sem estádio registrado.</td></tr>'}</tbody></table>
  <h2>Artilheiros na cidade</h2><table><tbody>${Object.entries(gol).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([n,v])=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td>${esc(nomeV(n))}</td><td class="n">${v}</td></tr>`).join('')||'<tr><td>Nenhum gol com autor.</td></tr>'}</tbody></table></div>
  <div><h2>Adversários</h2><table><tbody>${Object.values(adv).sort((a,b)=>b.l.length-a.l.length).slice(0,12).map(a=>{ const x=rec(a.l); return `<tr class="click" onclick="location.hash='adversario-${slug(a.id)}'"><td>${cr(a.id)}${esc(a.n)}</td><td class="n">${a.l.length}</td><td class="n mono">${x.V}V ${x.E}E ${x.D}D</td></tr>`; }).join('')}</tbody></table>
  ${g?miniMapa(g):''}</div></div>
  <h2>Jogos em ${esc(row.nome)}</h2>${matchTable([...l].reverse())}`;
}

/* ---------- Mapa do Galo ---------- */
function miniMapa(g){
  const M=D.geo; if(!M) return '';
  if (g.pais==='Brasil') return `<svg class="mapa mini" viewBox="0 0 ${M.br.w} ${M.br.h}" role="img" aria-label="Localização no mapa do Brasil">${Object.entries(M.br.uf).map(([uf,d])=>`<path d="${d}" class="${uf===g.uf?'on':''}"/>`).join('')}<circle cx="${g.bx}" cy="${g.by}" r="9" class="pin"/></svg>`;
  return `<svg class="mapa mini" viewBox="0 40 1000 380" role="img" aria-label="Localização no mapa do mundo">${Object.entries(M.mundo.p).map(([k,d])=>`<path d="${d}" class="${k===g.iso3?'on':''}"/>`).join('')}<circle cx="${g.wx}" cy="${g.wy}" r="7" class="pin"/></svg>`;
}
function vMapa(params){
  const M=D.geo; if(!M) return '<p class="empty">Mapa indisponível.</p>';
  const P=new URLSearchParams(params||''), aba=P.get('aba')||'brasil', uf=P.get('uf'), pais=P.get('pais');
  const rows=cidadeRows().filter(r=>geoC(r.c));
  const porUF={}, porPais={}; rows.forEach(r=>{ const g=geoC(r.c); if(g.pais==='Brasil'){ const o=(porUF[g.uf] ||= {n:0,c:0,l:[]}); o.n+=r.l.length; o.c++; o.l.push(...r.l); } const p=(porPais[g.iso3] ||= {nome:g.pais,n:0,c:0,l:[]}); p.n+=r.l.length; p.c++; p.l.push(...r.l); });
  const nPaises=new Set(rows.map(r=>geoC(r.c).pais)).size, nEst=Object.keys(estadiosAll()).length;
  const tom = (n, max) => { if(!n) return ''; const t=Math.log(1+n)/Math.log(1+max); return t>.8?'t5':t>.6?'t4':t>.4?'t3':t>.2?'t2':'t1'; };
  const raio = n => Math.max(2.2, Math.min(14, 1.2*Math.sqrt(n)));
  let svg, lista;
  if (aba==='brasil'){
    const mx=Math.max(...Object.values(porUF).map(o=>o.n));
    const br=rows.filter(r=>geoC(r.c).pais==='Brasil').sort((a,b)=>b.l.length-a.l.length);
    svg=`<svg class="mapa" viewBox="0 0 ${M.br.w} ${M.br.h}" role="img" aria-label="Mapa do Brasil com as cidades onde o Galo jogou">
      ${Object.entries(M.br.uf).map(([u,d])=>`<a href="#mapa?aba=brasil&uf=${u}"><path d="${d}" class="uf ${tom((porUF[u]||{}).n,mx)}${u===uf?' sel':''}"><title>${esc(M.br.nomes[u])}: ${N((porUF[u]||{}).n||0)} jogos em ${(porUF[u]||{}).c||0} cidades</title></path></a>`).join('')}
      ${[...br].reverse().map(r=>{ const g=geoC(r.c); return `<a href="#cidade-${slug(r.c)}"><circle cx="${g.bx}" cy="${g.by}" r="${raio(r.l.length)}" class="dot"><title>${esc(r.c)}: ${N(r.l.length)} jogos</title></circle></a>`; }).join('')}</svg>`;
    const sel = uf ? br.filter(r=>geoC(r.c).uf===uf) : null;
    lista = sel ? `<h2>${esc(M.br.nomes[uf])}: ${N(sel.reduce((s,r)=>s+r.l.length,0))} jogos em ${sel.length} cidades</h2>${tabCid(sel)}<p class="count"><a href="#mapa?aba=brasil">← Todos os estados</a></p>`
      : `<h2>Estados</h2><table><thead><tr><th>Estado</th><th class="n">Cidades</th><th class="n">Jogos</th><th class="n">Aprov.</th></tr></thead><tbody>${Object.entries(porUF).sort((a,b)=>b[1].n-a[1].n).map(([u,o])=>`<tr class="click" onclick="location.hash='mapa?aba=brasil&uf=${u}'"><td><b>${esc(M.br.nomes[u])}</b></td><td class="n">${o.c}</td><td class="n">${N(o.n)}</td><td class="n">${aprov(rec(o.l))}</td></tr>`).join('')}</tbody></table>
      <p class="count">O Galo já jogou em ${Object.keys(porUF).length} das 27 unidades da federação.${Object.keys(M.br.nomes).filter(u=>!porUF[u]).length?' Faltam: '+Object.keys(M.br.nomes).filter(u=>!porUF[u]).map(u=>M.br.nomes[u]).join(', ')+'.':''}</p>`;
  } else {
    const mx=Math.max(...Object.entries(porPais).filter(([k])=>k!=='BRA').map(([,o])=>o.n));
    const ext=rows.filter(r=>geoC(r.c).pais!=='Brasil');
    svg=`<svg class="mapa" viewBox="0 40 1000 380" role="img" aria-label="Mapa do mundo com os países onde o Galo jogou">
      ${Object.entries(M.mundo.p).map(([k,d])=>`<a href="#mapa?aba=mundo&pais=${k}"><path d="${d}" class="uf ${k==='BRA'?'br':tom((porPais[k]||{}).n,mx)}${k===pais?' sel':''}"><title>${esc((porPais[k]||{}).nome||k)}${porPais[k]?': '+N(porPais[k].n)+' jogos':''}</title></path></a>`).join('')}
      ${ext.map(r=>{ const g=geoC(r.c); return `<a href="#cidade-${slug(r.c)}"><circle cx="${g.wx}" cy="${g.wy}" r="${Math.max(2,raio(r.l.length)*.55)}" class="dot"><title>${esc(r.c)}: ${N(r.l.length)} jogos</title></circle></a>`; }).join('')}</svg>`;
    const sel = pais && porPais[pais] ? ext.filter(r=>geoC(r.c).iso3===pais) : null;
    lista = sel ? `<h2>${esc(porPais[pais].nome)}: ${N(porPais[pais].n)} jogos</h2>${tabCid(sel)}<p class="count"><a href="#mapa?aba=mundo">← Todos os países</a></p>`
      : `<h2>Países</h2><table><thead><tr><th>País</th><th class="n">Cidades</th><th class="n">Jogos</th><th class="n">Aprov.</th></tr></thead><tbody>${Object.entries(porPais).sort((a,b)=>b[1].n-a[1].n).map(([k,o])=>`<tr class="click" onclick="location.hash='mapa?aba=mundo&pais=${k}'"><td><b>${esc(o.nome)}</b></td><td class="n">${o.c}</td><td class="n">${N(o.n)}</td><td class="n">${aprov(rec(o.l))}</td></tr>`).join('')}</tbody></table>
      <p class="count">Jogos no exterior pela cidade da ficha. Os adversários estrangeiros que vieram jogar no Brasil contam na cidade brasileira.</p>`;
  }
  return `<div class="kicker">Almanaque · geografia</div><h1>O mapa do Galo</h1>
  <div class="tiles"><div class="tile"><b>${N(rows.length)}</b><span>Cidades</span></div><div class="tile"><b>${Object.keys(porUF).length}<small>/27</small></b><span>Estados</span></div><div class="tile"><b>${nPaises}</b><span>Países</span></div><div class="tile"><b>${N(nEst)}</b><span>Estádios</span></div></div>
  <div class="abas"><a href="#mapa?aba=brasil" class="${aba==='brasil'?'on':''}">Brasil</a><a href="#mapa?aba=mundo" class="${aba!=='brasil'?'on':''}">Mundo</a><a href="#cidades">Lista de cidades</a></div>
  <div class="mapa-box">${svg}<div class="mapa-leg"><span><i class="t1"></i>poucos jogos</span><span><i class="t5"></i>muitos jogos</span><span><i class="dotl"></i>cidade (tamanho = jogos)</span></div></div>
  ${lista}`;
}
function tabCid(l){ return `<table><thead><tr><th>Cidade</th><th class="n">Jogos</th><th class="n hide-s">V</th><th class="n hide-s">E</th><th class="n hide-s">D</th><th class="n">Aprov.</th></tr></thead><tbody>${l.map(r=>`<tr class="click" onclick="location.hash='cidade-${slug(r.c)}'"><td><b>${esc(r.nome)}</b></td><td class="n">${N(r.l.length)}</td><td class="n hide-s">${r.V}</td><td class="n hide-s">${r.E}</td><td class="n hide-s">${r.D}</td><td class="n">${r.ap}</td></tr>`).join('')}</tbody></table>`; }

/* ---------- Fui ao estádio: estatísticas completas ---------- */
function vistoAoVivo(){ return Object.entries(diario()).filter(([id,x])=>x.est&&byId[id]).map(([id])=>byId[id]).sort((a,b)=>a.data<b.data?-1:1); }
const elenco = e => e ? [...(e.titulares||[]), ...(e.substituicoes||[]).map(s=>s.entrou)].filter(Boolean) : [];
function sincronizaVivo(){
  try{ figuras(); }catch(e){ return; }
  G.vivo ||= {}; let novas=0;
  vistoAoVivo().forEach(j=>{ const ns=new Set(elenco(j.escalacao_galo)); j.gols.forEach(g=>{ if(isGoal(g)) ns.add(g.jogador); });
    ns.forEach(n=>{ if(FIGN[n] && !G.vivo[n]){ G.vivo[n]=j.id; if(!G.owned[n]){ G.owned[n]=1; novas++; } } }); });
  if (novas){ gSave(); toast(`+${novas} figurinha${novas>1?'s':''}: jogadores que você viu ao vivo`); }
}
function secEstadio(){
  const L = vistoAoVivo();
  if (!L.length) return `<h2>Fui ao estádio</h2><p class="empty">Nenhum jogo registrado ainda. Abra a página de um jogo e marque "Eu estava no estádio". Cada jogador do Galo que você viu em campo vira figurinha no seu álbum.</p>`;
  const r = rec(L.filter(j=>j.resultado)), cnt=(o,k,v=1)=>{ o[k]=(o[k]||0)+v; };
  const galo={}, advJ={}, golsG={}, golsA={}, est={}, cid={}, adv={}, comp={}, anos={}, estPrim={}, cidPrim={};
  let pub=0, pubN=0, pen=0, falta=0, sofr=0;
  L.forEach(j=>{
    elenco(j.escalacao_galo).forEach(n=>cnt(galo,n));
    elenco(j.escalacao_adv).forEach(n=>cnt(advJ,n+'|'+j.adversario));
    j.gols.forEach(g=>{ if(isGoal(g)){ cnt(golsG,g.jogador); const t=nrm(g.tipo); if(t.includes('penal')) pen++; if(t.includes('falta')) falta++; } else if(g.lado!=='galo' && g.jogador!=='Não identificado' && !nrm(g.tipo).includes('contra')) cnt(golsA,g.jogador+'|'+j.adversario); });
    sofr+=j.gc||0;
    if(j.estadio){ cnt(est,j.estadio); estPrim[j.estadio] ||= j; }
    if(j.cidade){ cnt(cid,j.cidade); cidPrim[j.cidade] ||= j; }
    const a=(adv[j.adversario_id] ||= {n:j.adversario,id:j.adversario_id,l:[]}); a.l.push(j);
    cnt(comp,j.grupo||j.competicao); cnt(anos,j.temporada);
    if(j.publico){ pub+=j.publico; pubN++; }
  });
  const top=(o,n=10)=>Object.entries(o).sort((a,b)=>b[1]-a[1]).slice(0,n);
  const ap=aprov(r), p=pct(r);
  const big=[...L].filter(j=>j.resultado==='V').sort((a,b)=>(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp)[0];
  const pior=[...L].filter(j=>j.resultado==='D').sort((a,b)=>(b.gc-b.gp)-(a.gc-a.gp))[0];
  const maiorPub=[...L].filter(j=>j.publico).sort((a,b)=>b.publico-a.publico)[0];
  let seq=0, best=0; L.forEach(j=>{ if(j.resultado&&j.resultado!=='D'){ seq++; best=Math.max(best,seq); } else if(j.resultado) seq=0; });
  const vivo=Object.keys(G.vivo||{}).filter(n=>G.owned[n]);
  const ufs=new Set(Object.keys(cid).map(c=>(geoC(c)||{}).uf).filter(Boolean)), paises=new Set(Object.keys(cid).map(c=>(geoC(c)||{}).pais).filter(Boolean));
  const mx=Math.max(...Object.values(anos));
  const M=D.geo;
  const mapa = M ? `<svg class="mapa mini" viewBox="0 0 ${M.br.w} ${M.br.h}" role="img" aria-label="Cidades onde você viu o Galo">${Object.entries(M.br.uf).map(([u,d])=>`<path d="${d}" class="${ufs.has(u)?'on':''}"/>`).join('')}${Object.keys(cid).map(c=>{ const g=geoC(c); return g&&g.pais==='Brasil'?`<circle cx="${g.bx}" cy="${g.by}" r="${Math.min(14,4+2*Math.sqrt(cid[c]))}" class="pin"><title>${esc(c)}: ${cid[c]}</title></circle>`:''; }).join('')}</svg>` : '';
  const carimbo=(nome,n,j,href)=>`<a class="carimbo" href="${href}"><b>${esc(nome)}</b><span>${n} ${n===1?'jogo':'jogos'}</span><small>desde ${fmtD(j.data)}</small></a>`;
  return `<h2>Fui ao estádio</h2>
  <div class="tiles"><div class="tile"><b>${L.length}</b><span>Jogos no estádio</span></div><div class="tile"><b style="color:var(--v)">${r.V}</b><span>Vitórias</span></div><div class="tile"><b style="color:var(--e)">${r.E}</b><span>Empates</span></div><div class="tile"><b style="color:var(--d)">${r.D}</b><span>Derrotas</span></div>
  <div class="tile"><b>${ap}</b><span>${L.length>=5?(p>=0.6?'Pé-quente':p<0.4?'Pé-frio':'Aproveitamento'):'Aproveitamento'}</span></div></div>${resultBar(r)}
  <div class="tiles"><div class="tile"><b>${r.gp}</b><span>Gols do Galo vistos</span></div><div class="tile"><b>${sofr}</b><span>Gols sofridos vistos</span></div><div class="tile"><b>${N(pub)}</b><span>Pessoas viram junto com você</span></div>
  <div class="tile"><b>${Object.keys(est).length}</b><span>Estádios</span></div><div class="tile"><b>${Object.keys(cid).length}</b><span>Cidades</span></div><div class="tile"><b>${Object.keys(adv).length}</b><span>Adversários</span></div></div>
  <p class="count">Público somado das fichas em ${pubN} dos seus ${L.length} jogos${pubN<L.length?' (os outros não têm público registrado)':''}.${best>1?` Maior sequência sem derrota que você viu: <b>${best} jogos</b>.`:''}${pen||falta?` Você viu ${pen} gol${pen===1?'':'s'} de pênalti e ${falta} de falta do Galo.`:''}</p>
  <div class="grid2"><div><h3>Jogadores do Galo que você mais viu em campo</h3><table><tbody>${top(galo).map(([n,v])=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td>${esc(nomeV(n))}${G.vivo&&G.vivo[n]?' <span class="tag light">figurinha</span>':''}</td><td class="n"><b>${v}</b></td></tr>`).join('')||'<tr><td>Os jogos que você marcou não têm escalação.</td></tr>'}</tbody></table>
  <h3>Quem você mais viu marcar</h3><table><tbody>${top(golsG,8).map(([n,v])=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td>${esc(nomeV(n))}</td><td class="n"><b>${v}</b></td></tr>`).join('')||'<tr><td>Nenhum gol com autor.</td></tr>'}</tbody></table></div>
  <div><h3>Adversários que você mais viu em campo</h3><table><tbody>${top(advJ).map(([k,v])=>{ const [n,t]=k.split('|'); return `<tr><td>${esc(n)} <small class="uf">${esc(t)}</small></td><td class="n"><b>${v}</b></td></tr>`; }).join('')||'<tr><td>Sem escalação dos adversários.</td></tr>'}</tbody></table>
  <h3>Algozes que você viu marcar</h3><table><tbody>${top(golsA,6).map(([k,v])=>{ const [n,t]=k.split('|'); return `<tr><td>${esc(n)} <small class="uf">${esc(t)}</small></td><td class="n"><b>${v}</b></td></tr>`; }).join('')||'<tr><td>Ninguém marcou contra o Galo na sua frente.</td></tr>'}</tbody></table></div></div>
  <h3>Passaporte: estádios</h3><div class="carimbos">${top(est,60).map(([e,n])=>carimbo(e,n,estPrim[e],linkJogos({est:e}))).join('')}</div>
  <div class="grid2"><div><h3>Passaporte: cidades</h3><div class="carimbos">${top(cid,60).map(([c,n])=>carimbo(c.split(',')[0],n,cidPrim[c],'#cidade-'+slug(c))).join('')}</div>
  <p class="count">${ufs.size} ${ufs.size===1?'estado':'estados'}${paises.size>1?' e '+paises.size+' países':''}.</p></div><div>${mapa}</div></div>
  <div class="grid2"><div><h3>Adversários</h3><table><thead><tr><th>Adversário</th><th class="n">J</th><th class="n">V</th><th class="n">E</th><th class="n">D</th></tr></thead><tbody>${Object.values(adv).sort((a,b)=>b.l.length-a.l.length).map(a=>{ const x=rec(a.l); return `<tr class="click" onclick="location.hash='adversario-${slug(a.id)}'"><td>${cr(a.id)}${esc(a.n)}</td><td class="n">${a.l.length}</td><td class="n">${x.V}</td><td class="n">${x.E}</td><td class="n">${x.D}</td></tr>`; }).join('')}</tbody></table></div>
  <div><h3>Competições</h3><table><tbody>${top(comp).map(([c,n])=>`<tr><td>${esc(c)}</td><td class="n">${n}</td></tr>`).join('')}</tbody></table>
  <h3>Por ano</h3><table class="seas"><tbody>${Object.keys(anos).sort().map(y=>`<tr><td class="mono">${y}</td><td class="n">${anos[y]}</td><td style="width:60%"><div class="hb"><i style="width:${100*anos[y]/mx}%"></i></div></td></tr>`).join('')}</tbody></table></div></div>
  <div class="note">Primeiro jogo: <a href="#jogo-${L[0].id}">${esc(resumoJogo(L[0]))}</a>${L.length>1?` · Último: <a href="#jogo-${L[L.length-1].id}">${esc(resumoJogo(L[L.length-1]))}</a>`:''}${big?`<br>Maior vitória que você viu: <a href="#jogo-${big.id}">Atlético ${placar(big)} ${esc(big.adversario)}</a>`:''}${pior?` · Pior derrota: <a href="#jogo-${pior.id}">Atlético ${placar(pior)} ${esc(pior.adversario)}</a>`:''}${maiorPub?`<br>Maior público com você: <a href="#jogo-${maiorPub.id}">${N(maiorPub.publico)} pessoas, ${esc(maiorPub.adversario)} (${fmtD(maiorPub.data)})</a>`:''}</div>
  <h3>Figurinhas ganhas ao vivo</h3>${vivo.length?`<p class="count">${vivo.length} jogadores que você viu em campo já estão colados no seu <a href="#album">álbum</a>.</p><div class="pq-ex">${vivo.slice(0,80).map(n=>`<a class="chip" href="#jogador-${slug(n)}">${esc(nomeV(n))}</a>`).join('')}</div>`:'<p class="count">Quando você marca um jogo com escalação, os jogadores do Galo que entraram em campo viram figurinha no seu álbum.</p>'}
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">${tw(`Já fui a ${L.length} ${L.length===1?'jogo':'jogos'} do Galo no estádio: ${r.V}V ${r.E}E ${r.D}D (${ap}). Vi ${r.gp} gols do Galo, em ${Object.keys(est).length} estádios e ${Object.keys(cid).length} cidades, com ${N(pub)} pessoas ao meu lado.`)}${artBtn({t:'estadio'})}</div>
  <h3>Jogos em que você esteve</h3>${matchTable([...L].reverse())}`;
}

/* ---------- Avisos de confiabilidade ---------- */
function cartaArquivo(p){
  const ini=p.primeiro||'', msgs=[];
  if (ini && ini<ERA_AMADORA) msgs.push('Boa parte da carreira foi na <b>era amadora</b> (até 1932). As fichas dessa época muitas vezes não têm escalação, minuto nem autor de todos os gols, então os números deste perfil são <b>inconclusivos</b>: servem de referência, não de contagem oficial.');
  if (ini && ini<'2000-01-01') msgs.push('Para jogos <b>antes de 2000</b>, gols de <b>pênalti</b> e de <b>falta</b> e <b>pênaltis defendidos</b> dependem do que cada ficha anota. Muitas não dizem como o gol saiu, então esses números tendem a ficar abaixo do real.');
  if (ini && ini<D.meta.escalacoes_desde) msgs.push(`Jogos e titularidades só contam a partir de ${fmtD(D.meta.escalacoes_desde)}, quando as escalações ficam completas.`);
  return msgs.length?`<div class="carta dots"><span class="osw">Carta do arquivo</span>${msgs.map(m=>`<p>${m}</p>`).join('')}</div>`:'';
}
function blocoBolaParada(){
  const ev=eventos(), c=(f)=>{ const m={}; ev.filter(f).forEach(e=>{ m[e.nome]=(m[e.nome]||0)+1; }); return Object.entries(m).sort((a,b)=>b[1]-a[1]).slice(0,10); };
  const tab=l=>`<table><tbody>${l.map(([n,v],i)=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td class="mono">${i+1}</td><td>${esc(nomeV(n))}</td><td class="n"><b>${v}</b></td></tr>`).join('')}</tbody></table>`;
  return `<div class="grid2"><div><h2>Gols de falta</h2>${tab(c(e=>e.falta))}</div><div><h2>Gols de pênalti</h2>${tab(c(e=>e.pen))}</div></div>
  <div class="grid2"><div><h2>Gols em finais</h2>${tab(c(e=>ehFinal(e.j)))}</div><div><h2>Gols em mata-mata</h2>${tab(c(e=>ehMata(e.j)))}</div></div>
  ${(()=>{ const F=J.filter(j=>j.resultado&&ehFinal(j)), M=J.filter(j=>j.resultado&&ehMata(j)), rf=rec(F), rm=rec(M); return `<p class="count">Finais: <b>${F.length} jogos</b>, ${rf.V}V ${rf.E}E ${rf.D}D · Mata-mata: <b>${M.length} jogos</b>, ${rm.V}V ${rm.E}E ${rm.D}D. <a href="#pergunte?${new URLSearchParams({q:'Finais do Galo'})}">Ver as finais →</a> ${avisoFases()}</p>`; })()}
  ${(()=>{ const F=D.finais_mineiro||[]; if(!F.length) return ''; const t=F.filter(x=>x.titulo).length;
    return `<h2>Finais do Campeonato Mineiro</h2><p class="classico-num"><b>${F.length}</b> finais · <b>${t}</b> títulos · <b>${F.length-t}</b> vices</p>
    <table><thead><tr><th>Ano</th><th>Adversário</th><th>Jogos da final</th><th class="n"></th></tr></thead><tbody>${[...F].reverse().map(x=>`<tr><td class="mono">${x.ano}</td><td>${cr(x.adversario_id)}${esc((advRows().find(a=>a.id===x.adversario_id)||{}).nome||x.adversario)}</td><td>${x.ids.map(id=>byId[id]).filter(Boolean).map(j=>`<a href="#jogo-${j.id}" class="mono">${placar(j)}</a>`).join(' · ')}</td><td class="n">${x.titulo?'<span class="tag">★ Campeão</span>':'<span class="tag light">Vice</span>'}</td></tr>`).join('')}</tbody></table>
    <p class="count">Jogos da final: os marcados como final na ficha mais a sequência final contra o mesmo adversário no fim do campeonato. Placar pela visão do Galo.</p>`; })()}
  <div class="grid2"><div><h2>Gols da vitória</h2>${tab(c(e=>e.decisivo))}</div><div><h2>Gols em viradas</h2>${tab(c(e=>e.virada))}</div></div>
  ${(()=>{ const V=[...VIR].sort((a,b)=>b.def-a.def||b.j.data.localeCompare(a.j.data)); const anos={}; VIR.forEach(v=>{ const d=Math.floor(v.j.temporada/10)*10; anos[d]=(anos[d]||0)+1; });
    return `<h2>Viradas</h2><p class="classico-num"><b>${N(VIR.length)}</b> vitórias de virada registradas · <a href="#viradas">ver todas, com filtros →</a></p>
    <div class="grid2"><div><h3>Maiores viradas</h3><table><tbody>${V.slice(0,12).map(v=>`<tr class="click" onclick="location.hash='jogo-${v.j.id}'"><td class="mono">${fmtD(v.j.data)}</td><td>${linha(v.j)}</td><td class="n uf" style="white-space:nowrap">perdia por ${v.def}${v.ate!=null?`, empatou aos ${v.ate}'`:''}</td></tr>`).join('')}</tbody></table></div>
    <div><h3>Viradas por década</h3><table class="seas"><tbody>${Object.keys(anos).sort().map(d=>`<tr><td class="mono">${d}s</td><td class="n">${anos[d]}</td><td style="width:60%"><div class="hb"><i style="width:${100*anos[d]/Math.max(...Object.values(anos))}%"></i></div></td></tr>`).join('')}</tbody></table></div></div>`; })()}
  <p class="count">${avisoBolaParada()} "Gol da vitória" é o gol que deixou o Galo na frente de vez, contado só quando a ordem dos gols é conhecida. Virada conta só jogos com o minuto de todos os gols registrado, então os números antigos ficam abaixo do real. <a href="#pergunte">Faça sua própria pergunta →</a></p>`;
}

/* ---------- Capa (visual de revista) ---------- */

function capa(){
  const h=new Date(), m=D.meta;
  return `<div class="masthead osw"><span>Ano I · Edição nº ${N(m.total)} · ${MESES[h.getMonth()][0].toUpperCase()+MESES[h.getMonth()].slice(1)} de ${h.getFullYear()}</span><span>O almanaque do Clube Atlético Mineiro</span><span>Belo Horizonte · alvinegro desde 1908</span></div>
  <div class="capa-top"><h1 class="capa-t">Galo Metrics</h1><div class="capa-selo" aria-hidden="true">${cr('galo','')}</div></div>
  <div class="stripe"></div>`;
}
function tambemNesta(){
  const top=[...D.jogadores].sort((a,b)=>golsBest(b)-golsBest(a))[0];
  const pub=[...J].filter(j=>j.publico).sort((a,b)=>b.publico-a.publico)[0];
  const ev=eventos(); const f={}; ev.filter(e=>e.falta).forEach(e=>{ f[e.nome]=(f[e.nome]||0)+1; }); const fa=Object.entries(f).sort((a,b)=>b[1]-a[1])[0];
  const cids=Object.keys(cidadesAll()).length;
  const it=(num,tit,txt,href)=>`<a class="tn-it" href="${href}"><span class="tn-n">${num}</span><span><b class="osw">${tit}</b><span>${txt}</span></span></a>`;
  return `<div class="tambem"><span class="osw tn-h">★ Também nesta edição</span>
  ${it(N(golsBest(top)), `Os gols de ${esc(nomeV(top.nome))}`, `O maior artilheiro da história, de ${(top.primeiro||'').slice(0,4)} a ${(top.ultimo||'').slice(0,4)}.`, '#jogador-'+slug(top.nome))}
  ${pub?it(N(pub.publico),'O maior público',`${esc(pub.adversario)}, ${esc(pub.estadio||'')}, ${fmtD(pub.data)}.`,'#jogo-'+pub.id):''}
  ${fa?it(fa[1],'O rei da bola parada',`${esc(nomeV(fa[0]))} lidera os gols de falta da base.`,'#recordes'):''}
  ${it(N(cids),'O mapa do Galo',`Cidades onde o Galo já jogou, no Brasil e no mundo.`,'#mapa')}</div>`;
}
function indiceEdicao(){
  const S=[['Jogos','#jogos',N(J.length)+' partidas'],['Jogadores','#jogadores','os perfis'],['Adversários','#adversarios','o duelo'],['Competições','#competicoes','os campeões'],['Temporadas','#temporadas','ano a ano'],['Técnicos','#tecnicos','os comandantes'],['Recordes','#recordes','o almanaque'],['Mapa do Galo','#mapa','cidades e países'],['Pergunte ao Galo','#pergunte','busca por palavras'],['Álbum','#album','colecione'],['Desafios','#desafios','jogue todo dia'],['Meu diário','#diario','jogos que eu fui']];
  return `<h2>★ Nesta edição</h2><nav class="indice" aria-label="Seções">${S.map(([t,h,s],i)=>`<a href="${h}"><span class="idx-n">${String(i+1).padStart(2,'0')}</span><span class="osw">${t}</span><em>${s}</em></a>`).join('')}</nav>`;
}

/* ---------- busca no topo ---------- */
(function(){ const f=document.getElementById('hq'); if(f) f.addEventListener('submit',e=>{ e.preventDefault(); const v=document.getElementById('hqi').value.trim(); if(v) location.hash='pergunte?'+new URLSearchParams({q:v}); }); })();

/* ---------- Página de viradas ---------- */
function vViradas(params){
  eventos(); const P=new URLSearchParams(params||''), fa=P.get('adv')||'', fc=P.get('comp')||'', fd=P.get('dec')||'';
  const L=VIR.filter(v=>(!fa||v.j.adversario_id===fa)&&(!fc||v.j.grupo===fc)&&(!fd||Math.floor(v.j.temporada/10)*10===+fd)).sort((a,b)=>b.j.data.localeCompare(a.j.data));
  const cnt=(l,k)=>{ const m={}; l.forEach(v=>{ const x=k(v); m[x]=(m[x]||0)+1; }); return Object.entries(m).sort((a,b)=>b[1]-a[1]); };
  const advs=cnt(VIR,v=>v.j.adversario_id), comps=cnt(VIR,v=>v.j.grupo), decs=cnt(VIR,v=>Math.floor(v.j.temporada/10)*10).sort((a,b)=>a[0]-b[0]);
  const nomeAdv=id=>(advRows().find(a=>a.id===id)||{}).nome||id;
  const gols={}; eventos().filter(e=>e.virada && L.some(v=>v.j===e.j)).forEach(e=>{ gols[e.nome]=(gols[e.nome]||0)+1; });
  const go=(k,v)=>{ const o={adv:fa,comp:fc,dec:fd,[k]:v}; Object.keys(o).forEach(x=>{ if(!o[x]) delete o[x]; }); return '#viradas?'+new URLSearchParams(o); };
  setTimeout(()=>{ ['adv','comp','dec'].forEach(k=>{ const el=document.getElementById('vf_'+k); if(el) el.onchange=()=>{ location.hash=go(k,el.value).replace(/\?$/,''); }; }); });
  const sel=(k,lista,val,rot)=>`<label>${rot}<select id="vf_${k}"><option value="">Todos</option>${lista.map(([x,n])=>`<option value="${esc(x)}"${String(x)===String(val)?' selected':''}>${esc(k==='adv'?nomeAdv(x):k==='dec'?x+'s':x)} (${n})</option>`).join('')}</select></label>`;
  return `<a class="back" href="#recordes">← Recordes</a><div class="kicker">Almanaque · de trás para a frente</div><h1>As viradas do Galo</h1>
  <div class="tiles"><div class="tile"><b>${N(L.length)}</b><span>Vitórias de virada</span></div><div class="tile"><b>${L.filter(v=>v.def>=2).length}</b><span>Perdendo por 2 ou mais</span></div><div class="tile"><b>${L.filter(v=>v.ate!=null&&v.ate>=70).length}</b><span>Ainda perdia aos 70'</span></div><div class="tile"><b>${new Set(L.map(v=>v.j.adversario_id)).size}</b><span>Adversários</span></div></div>
  <div class="dono"><div class="dgrid">${sel('adv',advs,fa,'Adversário')}${sel('comp',comps,fc,'Competição')}${sel('dec',decs,fd,'Década')}</div>${fa||fc||fd?`<p class="count"><a href="#viradas">Limpar filtros</a></p>`:''}</div>
  <div class="grid2"><div><h2>Quem mais marcou nas viradas</h2><table><tbody>${Object.entries(gols).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([n,v],i)=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td class="mono">${i+1}</td><td>${esc(nomeV(n))}</td><td class="n"><b>${v}</b></td></tr>`).join('')}</tbody></table></div>
  <div><h2>Vítimas das viradas</h2><table><tbody>${cnt(L,v=>v.j.adversario_id).slice(0,10).map(([id,n])=>`<tr class="click" onclick="location.hash='${go('adv',id)}'"><td>${cr(id)}${esc(nomeAdv(id))}</td><td class="n"><b>${n}</b></td></tr>`).join('')}</tbody></table></div></div>
  <h2>Todas as viradas${fa||fc||fd?' do filtro':''}</h2>
  <table><thead><tr><th>Data</th><th>Partida</th><th class="hide-s">Competição</th><th class="n">Situação</th></tr></thead><tbody>${L.map(v=>`<tr class="click" onclick="location.hash='jogo-${v.j.id}'"><td class="mono">${fmtD(v.j.data)}</td><td>${linha(v.j)}</td><td class="hide-s">${esc(v.j.competicao||'')}</td><td class="n uf" style="white-space:nowrap">perdia por ${v.def}${v.ate!=null?`, empatou aos ${v.ate}'`:''}</td></tr>`).join('')}</tbody></table>
  <p class="count">Virada é vitória em que o Galo esteve atrás no placar em algum momento. Só entram jogos com o minuto de todos os gols registrado, então os anos antigos ficam abaixo do real.</p>`;
}

/* ---------- Sugestões e correções ---------- */
const TIPOS_SUG = [['sugestao','Sugestão'],['correcao','Correção de dado'],['escudo','Enviar escudo'],['foto','Enviar foto']];
let SUG_TODAS = null;
function vSugestoes(params){
  const P=new URLSearchParams(params||''), sobre=P.get('sobre')||'', tipo0=P.get('tipo')||(sobre?'correcao':'sugestao');
  const rot = h => { if(!h) return ''; const m=h.match(/^jogo-(\d+)/); if(m&&byId[m[1]]) return `${resumoJogo(byId[m[1]])}`; const p=h.match(/^jogador-(.+)/); if(p){ const x=D.jogadores.find(q=>slug(q.nome)===p[1]); if(x) return 'Jogador: '+x.nome; } const a=h.match(/^adversario-(.+)/); if(a){ const x=advRows().find(r=>slug(r.id)===a[1]); if(x) return 'Adversário: '+x.nome; } return h; };
  setTimeout(ligaSugestoes);
  if (DONO) setTimeout(()=>{ SUG_TODAS ? desenhaSugDono() : carregaSugestoes(); });
  return `<div class="kicker">Galo Metrics · colabore</div><h1>Sugestões e correções</h1>
  <p class="lede">Achou um placar errado, falta um gol, tem o escudo de um adversário antigo ou uma foto de jogador? Mande aqui. Tudo chega só para o dono do site, que confere antes de entrar na base. Contribuição aceita vale pontos e selo no <a href="#colaboradores">ranking de colaboradores</a>.</p>
  <form id="sugform" class="dono sugform">
   <div class="tipos-sug" role="radiogroup" aria-label="Tipo de envio">${TIPOS_SUG.map(([k,l])=>`<label class="chip"><input type="radio" name="tipo" value="${k}"${k===tipo0?' checked':''}> ${l}</label>`).join('')}</div>
   <div class="dgrid"><label>Sobre o quê<input name="sobre" value="${esc(rot(sobre))}" placeholder="Ex.: Atlético 2x1 Cruzeiro, 1977; jogador Dario; escudo do Sete de Setembro"></label>
   <label>Seu nome ou @ (opcional)<input name="quem" maxlength="80" placeholder="Para darmos o crédito"></label></div>
   <input type="hidden" name="pagina" value="${esc(sobre)}">
   <label>Mensagem<textarea name="msg" rows="4" maxlength="2000" style="width:100%" placeholder="Explique o que está errado ou o que você sugere. Se puder, diga a fonte (jornal, livro, site)."></textarea></label>
   <label id="sugarq">Imagem<input type="file" name="arq" accept="image/*"><small class="uf">Escudo ou foto, até 10 MB. Envie só imagens que você pode compartilhar.</small></label>
   <p id="sugmsg" class="count" role="status"></p><button class="more" type="submit">Enviar</button>
  </form>
  <div id="minhassug"></div>
  ${DONO?`<h2>Recebidas (só você vê)</h2><div id="sugdono"><p class="count">Carregando…</p></div>`:''}`;
}
async function ligaSugestoes(){
  const f=$('#sugform'); if(!f) return;
  const arq=$('#sugarq'), sync=()=>{ const t=f.tipo.value; arq.style.display=['escudo','foto'].includes(t)?'':'none'; }; f.querySelectorAll('input[name=tipo]').forEach(r=>r.onchange=sync); sync();
  mostraMinhas();
  f.onsubmit=async e=>{ e.preventDefault(); const msg=$('#sugmsg'), btn=f.querySelector('button');
    const item={tipo:f.tipo.value, sobre:f.sobre.value.trim().slice(0,200), pagina:f.pagina.value, quem:f.quem.value.trim().slice(0,80), apelido:(G.perfil&&G.perfil.apelido)||'', msg:f.msg.value.trim().slice(0,2000), quando:new Date().toISOString()};
    const file=f.arq.files&&f.arq.files[0];
    if(!item.msg && !file){ msg.textContent='Escreva uma mensagem ou anexe uma imagem.'; return; }
    if(['escudo','foto'].includes(item.tipo) && !file){ msg.textContent='Anexe a imagem do '+(item.tipo==='escudo'?'escudo':'jogador')+'.'; return; }
    if(file && file.size>10*1024*1024){ msg.textContent='A imagem passa de 10 MB.'; return; }
    if(!GDB||!GUID){ msg.textContent='Para enviar, abra o site entrando com sua conta do Claude. Sem isso não dá para guardar o envio.'; return; }
    btn.disabled=true; msg.textContent='Enviando…';
    try{
      if(file){ const A=await window.claude.use('assets'); if(!A) throw new Error('upload indisponível para você'); const up=await A.upload(file); item.asset=up.id; item.url=up.url; item.tipoArq=up.contentType; }
      const ref=GDB.doc('sugestoes/'+GUID); const s=await ref.get(); const atual=s.exists?(s.data().itens||[]):[];
      await ref.set({itens:[...atual, item].slice(-100), atualizado:item.quando});
      f.reset(); sync(); msg.textContent='Recebido, obrigado! O dono do site vai conferir.'; toast('Envio recebido. Valeu!'); mostraMinhas(); if(DONO) carregaSugestoes();
    }catch(err){ console.error(err); msg.textContent='Não foi possível enviar agora ('+(err&&err.message||'erro')+'). Tente de novo mais tarde.'; }
    btn.disabled=false; };
}
async function mostraMinhas(){
  const box=$('#minhassug'); if(!box||!GDB||!GUID) return;
  try{ const s=await GDB.doc('sugestoes/'+GUID).get(); const L=s.exists?(s.data().itens||[]):[]; if(!L.length) return;
    box.innerHTML=`<h2>Seus envios</h2>${L.slice().reverse().map(x=>`<div class="sug-it"><span class="tag light">${esc((TIPOS_SUG.find(t=>t[0]===x.tipo)||[,''])[1])}</span> <b>${esc(x.sobre||'')}</b> <small class="uf">${fmtD(x.quando.slice(0,10))}</small>${x.msg?`<p>${esc(x.msg)}</p>`:''}${x.asset?`<img src="/_blob/${esc(x.asset)}" alt="Imagem enviada" class="sug-img">`:''}</div>`).join('')}`; }catch(e){}
}
async function carregaSugestoes(){
  if(!GDB) return; SUG_TODAS=[];
  try{ const s=await GDB.collection('sugestoes').limit(500).get(); (s.docs||[]).forEach(d=>{ (d.data().itens||[]).forEach((x,i)=>SUG_TODAS.push({...x, uid:d.id, k:d.id+'_'+i})); }); }catch(e){ console.error(e); }
  SUG_TODAS.sort((a,b)=>String(b.quando).localeCompare(String(a.quando)));
  desenhaSugDono();
}
function desenhaSugDono(){
  const box=$('#sugdono'); if(!box||!SUG_TODAS) return;
  let vistas={}; try{ vistas=JSON.parse(localStorage.getItem('gm-sug-vistas')||'{}'); }catch(e){}
  const T=k=>(TIPOS_SUG.find(t=>t[0]===k)||[,''])[1];
  box.innerHTML=SUG_TODAS.length?`<p class="count">${SUG_TODAS.length} envios · ${SUG_TODAS.filter(x=>!vistas[x.k]).length} novos</p>${SUG_TODAS.map(x=>`<div class="sug-it${vistas[x.k]?' vista':''}"><span class="tag${x.tipo==='correcao'?'':' light'}">${esc(T(x.tipo))}</span> <b>${esc(x.sobre||'(sem assunto)')}</b> <small class="uf">${fmtD(String(x.quando).slice(0,10))}${x.quem?' · '+esc(x.quem):''}</small>${x.pagina?` · <a href="#${esc(x.pagina)}">abrir página</a>`:''}${x.msg?`<p>${esc(x.msg)}</p>`:''}${x.asset?`<a href="/_blob/${esc(x.asset)}" target="_blank" rel="noopener"><img src="/_blob/${esc(x.asset)}" alt="Imagem enviada" class="sug-img"></a>`:''}${(COLAB.itens||[]).some(c=>c.k===x.k)?`<span class="tag">✓ Aceita (+${(COLAB.itens.find(c=>c.k===x.k)||{}).pts} pts)</span> <button type="button" class="ghost" data-desfaz="${esc(x.k)}">Desfazer</button> `:`<span class="aceita"><input type="number" min="0" max="500" value="${PTS_COLAB[x.tipo]||20}" aria-label="Pontos" data-pts="${esc(x.k)}"> <button type="button" class="more" data-aceita="${esc(x.k)}">Aceitar e dar pontos</button></span> `}<button type="button" class="ghost" data-vista="${esc(x.k)}">${vistas[x.k]?'Marcar como nova':'Marcar como vista'}</button></div>`).join('')}`:'<p class="empty">Nenhum envio ainda.</p>';
  const salvaColab=async(novo)=>{ try{ const r=GDB.doc('colab/aceitos'); const c=await r.get(); const at=c.exists?(c.data().itens||[]):[]; const it=novo(at); await r.set({itens:it, atualizado:new Date().toISOString()}); COLAB={itens:it}; desenhaSugDono(); }catch(e){ console.error(e); toast('Não foi possível salvar agora.'); } };
  box.querySelectorAll('[data-aceita]').forEach(b=>b.onclick=()=>{ const k=b.dataset.aceita, x=SUG_TODAS.find(y=>y.k===k); const pts=Math.max(0,Math.min(500,+box.querySelector(`[data-pts="${k}"]`).value||0)); vistas[k]=1; try{ localStorage.setItem('gm-sug-vistas',JSON.stringify(vistas)); }catch(e){}
    salvaColab(at=>at.some(c=>c.k===k)?at:[...at,{k, uid:x.uid, nome:(x.quem||x.apelido||'').slice(0,80), tipo:x.tipo, sobre:(x.sobre||'').slice(0,200), pts, quando:new Date().toISOString()}]).then(()=>toast(`Aceita, +${pts} pontos para ${x.quem||x.apelido||'o colaborador'}.`)); });
  box.querySelectorAll('[data-desfaz]').forEach(b=>b.onclick=()=>{ const k=b.dataset.desfaz; salvaColab(at=>at.filter(c=>c.k!==k)); });
  box.querySelectorAll('[data-vista]').forEach(b=>b.onclick=()=>{ const k=b.dataset.vista; if(vistas[k]) delete vistas[k]; else vistas[k]=1; try{ localStorage.setItem('gm-sug-vistas',JSON.stringify(vistas)); }catch(e){} desenhaSugDono(); });
}

/* ---------- Colaboradores: pontos, selos e ranking ---------- */
const PTS_COLAB = {sugestao:20, correcao:40, escudo:60, foto:50};
const NIVEIS_COLAB = [[15,'Ouro','◆'],[5,'Prata','◆'],[1,'Bronze','◆']];
let COLAB = {itens:[]}, APOIE = {}, COLAB_MEU = null;
async function carregaColab(){
  if(!GDB) return;
  try{ const s=await GDB.doc('colab/aceitos').get(); if(s.exists) COLAB={itens:[], ...s.data()}; }catch(e){}
  try{ const s=await GDB.doc('site/apoie').get(); if(s.exists) APOIE=s.data()||{}; }catch(e){}
  pagaColab();
}
function colabRows(){
  const m={}; (COLAB.itens||[]).forEach(x=>{ const r=(m[x.uid] ||= {uid:x.uid, nome:'', pts:0, n:0, tipos:{}, ult:''}); r.pts+=+x.pts||0; r.n++; r.tipos[x.tipo]=(r.tipos[x.tipo]||0)+1; if(x.nome) r.nome=x.nome; if(String(x.quando)>r.ult) r.ult=String(x.quando); });
  return Object.values(m).map(r=>({...r, nome:r.nome||'Torcedor anônimo'})).sort((a,b)=>b.pts-a.pts||b.n-a.n);
}
function nivelColab(n){ const x=NIVEIS_COLAB.find(([min])=>n>=min); return x?{nome:x[1], ic:x[2], cls:'colab-'+x[1].toLowerCase()}:null; }
function seloColab(n, txt){ const v=nivelColab(n); return v?`<span class="selo-colab ${v.cls}" title="Colaborador ${v.nome}">${v.ic}${txt?' Colaborador '+v.nome:''}</span>`:''; }
function apoiadorSelo(){ return '<span class="selo-apoio" title="Apoiador">♥</span>'; }
function ehApoiador(nome){ return !!nome && (APOIE.apoiadores||'').split('\n').map(s=>nrm(s.trim())).filter(Boolean).includes(nrm(nome)); }
function pagaColab(){
  if(!GUID||!G) return; G.colabPago ||= {}; let ganhou=0;
  const meus=(COLAB.itens||[]).filter(x=>x.uid===GUID);
  meus.forEach(x=>{ if(G.colabPago[x.k]) return; G.colabPago[x.k]=1; const p=+x.pts||0; if(p){ G.pts+=p; G.total+=p; G.hist.unshift({d:Date.now(), n:p, m:'colaboração aceita: '+(x.sobre||x.tipo)}); ganhou+=p; } });
  COLAB_MEU = meus.length ? {n:meus.length, pts:meus.reduce((s,x)=>s+(+x.pts||0),0)} : null;
  if(ganhou){ gSave(); setTimeout(()=>toast(`Sua colaboração foi aceita! +${ganhou} pontos.`),400); }
  atualizaChip();
}
function vColaboradores(){
  const L=colabRows(), rec=(COLAB.itens||[]).slice().sort((a,b)=>String(b.quando).localeCompare(String(a.quando))).slice(0,15);
  const T=k=>(TIPOS_SUG.find(t=>t[0]===k)||[,k])[1];
  return `<div class="kicker">Galo Metrics · feito pela torcida</div><h1>Colaboradores</h1>
  <p class="lede">Cada placar corrigido, gol encontrado, escudo antigo ou foto que chega aqui deixa a história do Galo mais completa. Quem colabora ganha pontos para o álbum e um selo ao lado do nome.</p>
  <div class="tiles"><div class="tile"><b>${N(L.length)}</b><span>Colaboradores</span></div><div class="tile"><b>${N((COLAB.itens||[]).length)}</b><span>Contribuições aceitas</span></div>${Object.keys(PTS_COLAB).map(k=>`<div class="tile"><b>${N((COLAB.itens||[]).filter(x=>x.tipo===k).length)}</b><span>${({sugestao:'Sugestões',correcao:'Correções',escudo:'Escudos',foto:'Fotos'})[k]}</span></div>`).join('')}</div>
  ${COLAB_MEU?`<p class="carta">Você já tem <b>${COLAB_MEU.n}</b> contribuição(ões) aceita(s) e ${N(COLAB_MEU.pts)} pontos por colaborar. ${seloColab(COLAB_MEU.n,true)}</p>`:''}
  <h2>Ranking de colaboradores</h2>
  ${L.length?`<table><thead><tr><th>#</th><th>Colaborador</th><th class="n">Aceitas</th><th>Tipos</th><th class="n">Pontos</th></tr></thead><tbody>${L.map((r,i)=>`<tr${r.uid===GUID?' class="eu"':''}><td class="mono">${i+1}</td><td>${seloColab(r.n)} ${esc(r.nome)}${ehApoiador(r.nome)?' '+apoiadorSelo():''}</td><td class="n">${r.n}</td><td><small>${Object.entries(r.tipos).map(([k,v])=>`${esc(T(k).replace('Enviar ','').replace(' de dado',''))} ${v}`).join(' · ')}</small></td><td class="n"><b>${N(r.pts)}</b></td></tr>`).join('')}</tbody></table>`:'<p class="empty">O ranking começa com a primeira contribuição aceita. Pode ser a sua.</p>'}
  <h2>Como ganhar pontos e selo</h2>
  <div class="tiles">${Object.entries(PTS_COLAB).map(([k,p])=>`<div class="tile"><b>+${p}</b><span>${esc(T(k))}</span></div>`).join('')}</div>
  <p class="count">Os pontos entram quando a contribuição é conferida e aceita, e caem direto no seu saldo do álbum na próxima visita. Selos por contribuições aceitas: ${NIVEIS_COLAB.slice().reverse().map(([n,nome])=>`${seloColab(n)} ${nome} a partir de ${n}`).join(' · ')}.</p>
  ${rec.length?`<h2>Últimas contribuições</h2><ul class="lista-colab">${rec.map(x=>`<li><span class="tag light">${esc(T(x.tipo))}</span> ${esc(x.sobre||'')} <small class="uf">por ${esc(x.nome||'Torcedor anônimo')} · ${fmtD(String(x.quando).slice(0,10))}</small></li>`).join('')}</ul>`:''}
  <p><a class="more" href="#sugestoes">Quero colaborar →</a> <a class="ghost" href="#apoie">Apoie o Galo Metrics</a></p>`;
}

/* ---------- Apoie ---------- */
function vApoie(){
  const A=APOIE||{}, ap=(A.apoiadores||'').split('\n').map(s=>s.trim()).filter(Boolean);
  setTimeout(()=>{ if($('#apcopia')) $('#apcopia').onclick=()=>{ try{ navigator.clipboard.writeText(A.pix).then(()=>toast('Chave Pix copiada.'),()=>toast('Selecione a chave e copie.')); }catch(e){ toast('Selecione a chave e copie.'); } }; const b=$('#apsalva'); if(!b) return;
    b.onclick=async()=>{ const f=$('#apform'), o={texto:f.texto.value.trim(), pix:f.pix.value.trim(), link:f.link.value.trim(), linkNome:f.linkNome.value.trim(), insta:f.insta.value.trim().replace(/^@/,''), apoiadores:f.apoiadores.value}; try{ await GDB.doc('site/apoie').set(o); APOIE=o; toast('Página Apoie salva.'); route.keep=true; route(); }catch(e){ $('#apmsg').textContent='Não foi possível salvar agora.'; } }; });
  const temDin = A.pix||A.link;
  return `<div class="kicker">Galo Metrics · apoie</div><h1>Apoie o Galo Metrics</h1>
  <p class="lede">${esc(A.texto||'O Galo Metrics é um projeto independente, feito por torcedor para torcedor, com horas de pesquisa em jornais, livros e arquivos para reunir toda a história do Atlético em números. Se o site te ajuda, dá para apoiar de várias formas.')}</p>
  <div class="apoie-grid">
   <div class="apoie-c"><div class="kicker">Com uma contribuição</div>${temDin?`${A.pix?`<p><b>Pix</b></p><p class="mono pixk">${esc(A.pix)}</p><button type="button" class="more" id="apcopia">Copiar chave Pix</button>`:''}${A.link?`<p style="margin-top:14px"><a class="more" href="${esc(A.link)}" target="_blank" rel="noopener">${esc(A.linkNome||'Apoiar pelo link')} ↗</a></p>`:''}<p class="count">Apoiadores ganham o selo ${apoiadorSelo()} ao lado do nome no site.</p>`:'<p class="count">As formas de apoio em dinheiro chegam em breve.</p>'}</div>
   <div class="apoie-c"><div class="kicker">Com informação</div><p>Mande correções, escudos e fotos. Cada contribuição aceita vale pontos e selo de colaborador.</p><a class="more" href="#sugestoes">Enviar contribuição</a> <a class="ghost" href="#colaboradores">Ver colaboradores</a></div>
   <div class="apoie-c"><div class="kicker">Espalhando</div><p>Compartilhe o site, um recorde ou um jogo com outros atleticanos.${A.insta?` E siga <a href="https://instagram.com/${esc(A.insta)}" target="_blank" rel="noopener">@${esc(A.insta)}</a>.`:''}</p>${tw('Toda a história do Galo em números, jogo a jogo, no Galo Metrics.','Compartilhar no X')}</div>
  </div>
  ${ap.length?`<h2>Apoiadores</h2><p class="apoiadores">${ap.map(n=>`${apoiadorSelo()} ${esc(n)}`).join(' · ')}</p>`:''}
  ${DONO?`<details class="dono-ed"><summary>✎ Editar página Apoie (só você vê)</summary><form id="apform" class="dono" onsubmit="return false">
   <label>Texto de abertura<textarea name="texto" rows="3" style="width:100%">${esc(A.texto||'')}</textarea></label>
   <div class="dgrid"><label>Chave Pix<input name="pix" value="${esc(A.pix||'')}" placeholder="e-mail, celular ou chave aleatória"></label><label>Instagram (sem @)<input name="insta" value="${esc(A.insta||'')}"></label>
   <label>Link de apoio (Apoia.se, LivePix, etc.)<input name="link" value="${esc(A.link||'')}" placeholder="https://"></label><label>Texto do botão do link<input name="linkNome" value="${esc(A.linkNome||'')}" placeholder="Apoiar pelo Apoia.se"></label></div>
   <label>Apoiadores (um nome por linha, igual ao apelido no site para ganhar o selo)<textarea name="apoiadores" rows="4" style="width:100%">${esc(A.apoiadores||'')}</textarea></label>
   <p id="apmsg" class="count" role="status"></p><button type="button" class="more" id="apsalva">Salvar</button></form></details>`:''}`;
}
