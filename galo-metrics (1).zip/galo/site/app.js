let D, J, byId = {};
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const slug = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const fmtD = (d, aprox) => { if(!d) return '–'; const [y,m,dd]=d.split('-'); return aprox ? `${m}/${y}` : `${dd}/${m}/${y}`; };
const isGoal = g => g.lado==='galo' && !(g.tipo||'').includes('contra') && g.jogador!=='Não identificado';
const aprov = r => { const n=r.V+r.E+r.D; return n ? Math.round(100*(3*r.V+r.E)/(3*n)) + '%' : '–'; };
const resBox = j => j.resultado ? `<span class="res ${j.resultado}">${j.resultado}</span>` : `<span class="res A" title="Sem resultado">·</span>`;
const placar = j => j.gp==null ? (j.wo ? 'WO' : 'x') : `${j.gp} x ${j.gc}`;
const mandoTxt = {C:'Casa', F:'Fora', N:'Neutro'};
const mandoLbl = j => j.mando==='N' && !j.tem_ficha && !j.cidade ? '' : (mandoTxt[j.mando]||'');
let ESC={};
const cr = (id, cls='cr') => { const f = id==='galo' ? ESC.__galo : ESC[id]; return f ? `<img class="${cls}" src="${f}" alt="" loading="lazy">` : `<span class="${cls} nocr"></span>`; };
const advNome = j => { const w=String(j.adversario||'').split(' '), u=w.pop(); return `${w.length?esc(w.join(' '))+' ':''}<span class="an">${esc(u)}${j.adversario_uf?` <small class="uf">${esc(j.adversario_uf)}</small>`:''}${cr(j.adversario_id,'cr cra')}</span>`; };
const linha = j => `<span class="ln">${cr('galo','crg')}<b>Atlético</b> <span class="score">${placar(j)}</span> ${advNome(j)}</span>`;
function rec(list){ const r={V:0,E:0,D:0,gp:0,gc:0,n:0}; list.forEach(j=>{ if(!j.resultado) return; r[j.resultado]++; r.gp+=j.gp||0; r.gc+=j.gc||0; r.n++; }); return r; }
function resultBar(r){ const n=r.V+r.E+r.D||1; return `<div class="bar"><div style="width:${100*r.V/n}%;background:var(--v)"></div><div style="width:${100*r.E/n}%;background:var(--e)"></div><div style="width:${100*r.D/n}%;background:var(--d)"></div></div><div class="legend"><span><i style="background:var(--v)"></i>${r.V.toLocaleString('pt-BR')} ${r.V===1?'vitória':'vitórias'}</span><span><i style="background:var(--e)"></i>${r.E.toLocaleString('pt-BR')} ${r.E===1?'empate':'empates'}</span><span><i style="background:var(--d)"></i>${r.D.toLocaleString('pt-BR')} ${r.D===1?'derrota':'derrotas'}</span></div>`; }
const N = x => x.toLocaleString('pt-BR');
function tiles(r){ return `<div class="tiles">
  <div class="tile"><b>${N(r.n)}</b><span>Jogos</span></div><div class="tile"><b>${N(r.V)}</b><span>Vitórias</span></div>
  <div class="tile"><b>${N(r.E)}</b><span>Empates</span></div><div class="tile"><b>${N(r.D)}</b><span>Derrotas</span></div>
  <div class="tile"><b>${N(r.gp)}</b><span>Gols pró</span></div><div class="tile"><b>${N(r.gc)}</b><span>Gols contra</span></div>
  <div class="tile"><b>${aprov(r)}</b><span>Aproveitamento</span></div></div>`; }

function matchTable(list, limit=200, opts={}){
  if(!list.length) return '<p class="empty">Nenhum jogo encontrado.</p>';
  const id = 'mt'+Math.random().toString(36).slice(2,8);
  const rows = (n) => list.slice(0,n).map(j=>`<tr class="click" onclick="location.hash='jogo-${j.id}'"><td class="mono">${fmtD(j.data,j.data_aprox)}</td><td>${resBox(j)}</td>
    <td>${linha(j)}</td><td class="hide-s">${mandoLbl(j)?`<span class="tag light">${mandoLbl(j)}</span>`:'<span class="uf" title="Mando não informado na fonte">–</span>'}</td><td class="hide-s">${esc(j.competicao||'')}${j.fase?` <small class="uf">· ${esc(j.fase)}</small>`:''}${opts.pub&&j.publico?` <small class="uf">· ${N(j.publico)} ${esc(j.publico_tipo||'')}</small>`:''}</td><td class="hide-s">${j.tem_ficha?'<span class="tag" title="Ficha completa">Ficha</span>':''}</td></tr>`).join('');
  setTimeout(()=>{ const b=document.getElementById(id+'-more'); if(b) b.onclick=()=>{ limit+=500; document.getElementById(id).innerHTML=rows(limit); if(limit>=list.length) b.remove(); else b.textContent=`Mostrar mais (${N(list.length-limit)} restantes)`; }; });
  return `<table><thead><tr><th>Data</th><th></th><th>Partida</th><th class="hide-s">Mando</th><th class="hide-s">Competição</th><th class="hide-s"></th></tr></thead><tbody id="${id}">${rows(limit)}</tbody></table>
  ${list.length>limit?`<button class="more" id="${id}-more">Mostrar mais (${N(list.length-limit)} restantes)</button>`:''}`;
}

function sortable(id, cols, rows, initial, max=300){
  let st = {k: initial, dir: -1};
  const draw = () => {
    const r = [...rows].sort((a,b)=>{ const x=a[st.k], y=b[st.k]; return (typeof x==='string' ? x.localeCompare(y) : (x-y)) * st.dir; }).slice(0,max);
    $('#'+id).innerHTML = `<table><thead><tr>${cols.map(c=>`<th class="s ${c.n?'n':''}" data-k="${c.k}">${c.t}${st.k===c.k?(st.dir<0?' ↓':' ↑'):''}</th>`).join('')}</tr></thead><tbody>${
      r.map(o=>`<tr class="${o._href?'click':''}" ${o._href?`onclick="location.hash='${o._href}'"`:''}>${cols.map(c=>`<td class="${c.n?'n':''}">${c.f?c.f(o):esc(o[c.k])}</td>`).join('')}</tr>`).join('')}</tbody></table>
      ${rows.length>max?`<p class="count">Mostrando os ${max} primeiros de ${N(rows.length)}. Use a busca para achar os demais.</p>`:''}`;
    $('#'+id).querySelectorAll('th').forEach(th=>th.onclick=()=>{ const k=th.dataset.k; st.dir = st.k===k ? -st.dir : (typeof rows[0]?.[k]==='string'?1:-1); st.k=k; draw(); });
  };
  draw();
}


let ACC={p:{},h2h:{},vs:{}};
function buildAcc(){
  (D.aceitos||[]).forEach(a=>{ const f=a.fonte, c=a.calculo;
    if(c.tipo==='h2h') ACC.h2h[c.adversario_id]={...a.aceito, ate:a.ate, fonte:f, explicacao:a.explicacao};
    else if(c.tipo==='gols_jogador'){ const o=(ACC.p[c.nome] ||= {}); o.gols={v:a.aceito.gols, de:c.de, ano:9999, dataAte:a.ate, fonte:f}; if(a.aceito.jogos) o.jogos={v:a.aceito.jogos, dataAte:a.ate, fonte:f}; }
    else if(c.tipo==='gols_ranking' && c.adversario_id) a.ranking.forEach(r=>{ (ACC.vs[c.adversario_id] ||= {})[r.nome]={v:r.aceito, de:r.de, ano:r.ate, dataAte:a.ate, fonte:f}; });
    else if(c.tipo==='gols_ranking') a.ranking.forEach(r=>{ const o=(ACC.p[r.nome] ||= {}); o.gols ||= {v:r.aceito, de:r.de, ano:r.ate, dataAte:null, fonte:f}; });
    else if(c.tipo==='sem_base') a.ranking.forEach(r=>{ const o=(ACC.p[r.nome] ||= {}); o.jogos={v:r.aceito, de:r.de, ano:r.ate, dataAte:null, fonte:f};
      if(!D.jogadores.some(x=>x.nome===r.nome)) D.jogadores.push({nome:r.nome, jogos:0, titular:0, gols:0, gols_penalti:0, primeiro:null, ultimo:null, por_comp:{}, gols_comp:{}, soAceito:true, periodo_aceito:`${r.de}–${r.ate}`}); });
  });
}
// número aceito de gols, somado aos gols registrados na base depois da data de corte
function accG(acc, nome, advId){
  if(!acc) return null;
  const base = golsDe(nome, acc.de, acc.ano, null, advId);
  const extra = acc.dataAte ? golsDe(nome, acc.de, acc.ano, null, advId) - golsDe(nome, acc.de, acc.ano, acc.dataAte, advId) : 0;
  return {atual: acc.v + extra, v: acc.v, extra, base, dataAte: acc.dataAte, fonte: acc.fonte};
}
function jogosApos(nome, dt){ return J.filter(j=>j.data>dt && j.escalacao_galo && (j.escalacao_galo.titulares.includes(nome)||j.escalacao_galo.substituicoes.some(s=>s.entrou===nome))).length; }
const golsBest = p => { const g=accG(ACC.p[p.nome]?.gols, p.nome); return g ? g.atual : p.gols; };
const fonteLink = f => f ? `<a href="${esc(f.url)}" target="_blank" rel="noopener">${esc(f.nome)}</a>` : '';
const duplo = (big, small) => `${big}`; // em listas, só o número; o detalhe fica na página do jogador

/* ---------- Início ---------- */
const DIAS=['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
function proxJogo(j, hoje){
  const X=(D.proximo||{})[j.id]||{}, a=j.adversario_id;
  const dt=new Date(j.data+'T12:00:00'), dias=Math.round((dt-new Date(hoje+'T12:00:00'))/864e5);
  const quando = dias===0?'Hoje':dias===1?'Amanhã':`Em ${dias} dias`;
  const vs=J.filter(x=>x.adversario_id===a&&x.resultado), rv=rec(vs);
  const H=ACC.h2h[a]; let rr=rv; if(H){ const pos=rec(vs.filter(x=>x.data>H.ate)); rr={n:H.jogos+pos.n,V:H.V+pos.V,E:H.E+pos.E,D:H.D+pos.D,gp:rv.gp,gc:rv.gc}; }
  const sc={}; vs.forEach(x=>x.gols.forEach(g=>{ if(isGoal(g)&&g.lado==='galo'&&g.jogador!=='Não identificado') sc[g.jogador]=(sc[g.jogador]||0)+1; }));
  const art=Object.entries(sc).sort((p,q)=>q[1]-p[1]).slice(0,3);
  const comp=J.filter(x=>x.competicao===j.competicao&&x.resultado), rc=rec(comp);
  const ed=comp.filter(x=>x.temporada===j.temporada);
  const forma=J.filter(x=>x.resultado&&x.data<j.data).slice(-5);
  const box = x => `<a href="#jogo-${x.id}" class="res ${x.resultado}" title="${esc(fmtD(x.data))} · ${esc(placar(x))} ${esc(x.adversario)}">${x.resultado}</a>`;
  const local=[j.estadio, j.cidade].filter(Boolean).join(', ');
  const fase=j.fase?j.fase[0].toUpperCase()+j.fase.slice(1):'';
  return `<section class="prox">
   <div class="prox-top"><span class="kicker" style="margin:0">Próximo jogo</span><span class="chip">${quando}</span></div>
   <div class="prox-vs">${cr('galo','crb')}<b>Atlético</b><span class="vs">×</span><b>${esc(j.adversario)}</b>${cr(a,'crb crb2')}</div>
   <div class="prox-when">${esc(j.competicao||'')}${fase?' · '+esc(fase):''} · ${DIAS[dt.getDay()]}, ${fmtD(j.data)}${X.hora?' · '+esc(X.hora):''}</div>
   <div class="meta">
     <div><span>Local</span>${esc(local||'a definir')}</div>
     <div><span>Transmissão</span>${esc(X.transmissao||'a definir')}</div>
     <div><span>Mando</span>${esc(X.obs||mandoLbl(j)||'–')}</div>
   </div>
   <div class="prox-grid">
     <div><h3>Retrospecto contra ${esc(j.adversario)}</h3>
       ${rr.n?`<p class="classico-num"><b>${N(rr.n)}</b> jogos · ${rr.V}V ${rr.E}E ${rr.D}D · ${aprov(rr)}</p>${resultBar(rr)}
       <p class="count">Último confronto: <a href="#jogo-${vs[vs.length-1].id}">${esc(placar(vs[vs.length-1]))} em ${fmtD(vs[vs.length-1].data)}</a>${vs.length>1?` · primeiro: ${fmtD(vs[0].data)}`:''}</p>
       <div class="boxes">${vs.slice(-8).map(box).join('')}</div>
       ${art.length?`<p class="count">Artilheiros do Galo no confronto: ${art.map(([n,g])=>`${esc(nomeV(n))} (${g})`).join(', ')}</p>`:''}`
       :`<p class="classico-num"><b>Primeiro encontro</b> da história contra o ${esc(j.adversario)}.</p>`}
     </div>
     <div><h3>Galo na ${esc(j.competicao||'competição')}</h3>
       <p class="classico-num"><b>${N(rc.n)}</b> jogos · ${aprov(rc)} de aproveitamento</p>${rc.n?resultBar(rc):''}
       ${ed.length?`<p class="count">Campanha em ${j.temporada}: ${rec(ed).V}V ${rec(ed).E}E ${rec(ed).D}D</p><div class="boxes">${ed.map(box).join('')}</div>`:''}
       <h3 style="margin-top:18px">Últimos 5 jogos</h3><div class="boxes">${forma.map(box).join('')}</div>
     </div>
   </div>
   <p class="count" style="margin-top:14px"><a href="#adversario-${slug(a)}">Retrospecto completo contra ${esc(j.adversario)} →</a> · <a href="#jogo-${j.id}"><b>Dar meu palpite →</b></a></p>
  </section>`;
}
function vInicio(){
  const played = J.filter(j=>j.resultado), r = rec(played), m = D.meta;
  const hoje = (()=>{ const t=new Date(); return `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`; })();
  const next = J.find(j=>!j.resultado && j.data >= hoje);
  const top = [...D.jogadores].sort((a,b)=>golsBest(b)-golsBest(a)).slice(0,15);
  const most = [...D.jogadores].sort((a,b)=>b.jogos-a.jogos).slice(0,10);
  const years = {}; played.forEach(j=>{ (years[j.temporada] ||= {V:0,E:0,D:0})[j.resultado]++; });
  const maxY = Math.max(...Object.values(years).map(y=>y.V+y.E+y.D));
  const big = [...played].filter(j=>j.gp!=null).sort((a,b)=>(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp)[0];
  const cz = rec(J.filter(j=>j.adversario_id==='cruzeiro mg'));
  const vs=(CFG.vocesabia||[]); const vsx=vs.length?vs[Math.floor(Math.random()*vs.length)]:'';
  return `${CFG.manchete?`<div class="manchete">★ ${CFG.mancheteLink?`<a href="${esc(CFG.mancheteLink)}">${esc(CFG.manchete)}</a>`:esc(CFG.manchete)}</div>`:''}${capa()}<p class="capa-sub">A história do Galo em números, jogo a jogo, desde 1909.</p>
  <p class="lede">${N(m.total)} partidas, de ${fmtD(m.primeiro)} a ${fmtD(m.ultimo)}. Placar e goleadores de toda a história; ficha completa (escalação, estádio, público, minuto dos gols) em ${N(m.fichas)} jogos.</p>
  ${tiles(r)}${resultBar(r)}
  ${next?proxJogo(next,hoje):''}
  ${blocoPublico(false)}
  <div class="capa-grid"><div>${tambemNesta()}</div>${vsx?`<div class="vsabia-c"><span class="osw">Você sabia?</span><span>${esc(vsx)}</span></div>`:''}</div>
  <div class="alb-cta"><a href="#album" class="more">★ Álbum dos imortais: ${N(G?Object.keys(G.owned).length:0)} de ${N(D.jogadores.length)} figurinhas coladas →</a> <a href="#desafios" class="more">★ Desafios do dia →</a></div>
  ${indiceEdicao()}
  <h2>Jogos por temporada</h2>
  <div class="yearbars">${Object.entries(years).map(([y,v])=>`<a href="#temporada-${y}" title="${y}: ${v.V}V ${v.E}E ${v.D}D"><div style="height:${110*v.D/maxY}px;background:var(--d)"></div><div style="height:${110*v.E/maxY}px;background:var(--e)"></div><div style="height:${110*v.V/maxY}px;background:var(--v)"></div></a>`).join('')}</div>
  <div class="yearaxis"><span>${Object.keys(years)[0]}</span><span>1950</span><span>2000</span><span>${Object.keys(years).slice(-1)[0]}</span></div>
  <div class="grid2">
    <div><h2>Maiores artilheiros</h2><table><thead><tr><th>#</th><th>Jogador</th><th class="n">Gols</th><th>Período</th></tr></thead><tbody>${top.map((p,i)=>`<tr class="click" onclick="location.hash='jogador-${slug(p.nome)}'"><td class="mono">${i+1}</td><td>${esc(p.nome)}</td><td class="n">${(()=>{const g=accG(ACC.p[p.nome]?.gols,p.nome); return g?g.atual:p.gols;})()}</td><td class="mono uf">${(()=>{const g=ACC.p[p.nome]?.gols; return g&&g.ano<9999?g.de+'–'+g.ano:(p.primeiro||'').slice(0,4)+'–'+(p.ultimo||'').slice(0,4);})()}</td></tr>`).join('')}</tbody></table>
    <p class="count">Pelo número aceito pelo clube e pela imprensa, quando existe; os demais, pela base.</p></div>
    <div>${next?'':`<h2>Clássico ${cr('cruzeiro mg','cr2')}</h2>${(()=>{const H=ACC.h2h['cruzeiro mg']; if(!H) return `<p class="mono">${N(cz.n)} jogos</p>${resultBar(cz)}`;
      const pos=rec(J.filter(j=>j.adversario_id==='cruzeiro mg'&&j.data>H.ate)); const ac={n:H.jogos+pos.n,V:H.V+pos.V,E:H.E+pos.E,D:H.D+pos.D};
      return `<p class="classico-num"><b>${N(ac.n)}</b> jogos contra o Cruzeiro · ${aprov(ac)} de aproveitamento</p>${resultBar(ac)}`;})()}<p class="count" style="margin-top:10px"><a href="#adversario-${slug('cruzeiro mg')}">Ver retrospecto completo →</a></p>`}
    <h2>Mais jogos <small class="uf">desde ${fmtD(m.escalacoes_desde)}</small></h2><table><thead><tr><th>#</th><th>Jogador</th><th class="n">Jogos</th><th class="n">Gols</th></tr></thead><tbody>${most.map((p,i)=>`<tr class="click" onclick="location.hash='jogador-${slug(p.nome)}'"><td class="mono">${i+1}</td><td>${esc(p.nome)}</td><td class="n">${p.jogos}</td><td class="n">${p.gols}</td></tr>`).join('')}</tbody></table></div>
  </div>
  ${(()=>{const t=new Date(), md=String(t.getMonth()+1).padStart(2,'0')+'-'+String(t.getDate()).padStart(2,'0'); const l=played.filter(j=>!j.data_aprox&&j.data.slice(5)===md);
    return l.length?`<h2>Neste dia <small class="uf">${t.getDate()}/${t.getMonth()+1} na história</small></h2>${matchTable([...l].reverse(),6)}`:'';})()}
  <h2>Últimos jogos</h2>${matchTable([...played].reverse().slice(0,10),10)}
  ${big?`<div class="note">Maior vitória da história na base: <a href="#jogo-${big.id}"><b>${linha(big)}</b></a> (${fmtD(big.data)}, ${esc(big.competicao)}).</div>`:''}`;
}

/* ---------- Jogos ---------- */
const F0 = {dec:'',temp:'',de:'',ate:'',grupo:'',comp:'',adv:'',uf:'',res:'',mando:'',tec:'',est:'',jog:'',ficha:'',plac:'',ord:'rec',q:''};
let F = {...F0};
const PLAC = {g3:'Goleadas aplicadas (3+ de saldo)', s3:'Goleadas sofridas (3+ de saldo)', cs:'Sem sofrer gols', ns:'Sem marcar gols', z:'0 x 0', m5:'5 ou mais gols no jogo', g5:'Galo marcou 5 ou mais'};
const ORD = {rec:'Mais recentes', ant:'Mais antigos', saldo:'Maior saldo', pior:'Pior saldo', gols:'Mais gols no jogo', pub:'Maior público'};
const noGol = (j,n) => { const e=j.escalacao_galo; if(!e||!e.titulares.length) return 0; const g=e.titulares[0]; if(g===n) return 1; return e.substituicoes.some(s=>s.saiu===g&&s.entrou===n) ? 2 : 0; };
const penDef = nome => { const r=[]; J.forEach(j=>(j.pen_defendidos||[]).forEach(x=>{ if(x.goleiro===nome) r.push({j,x}); })); return r; };
const penResumo = nome => { const l=penDef(nome); return {l, jogo:l.filter(o=>o.x.tipo==='jogo').length, disputa:l.filter(o=>o.x.tipo==='disputa').length}; };
function goleiro(p, list){ if(!p.jogos) return null; const gj=list.filter(j=>noGol(j,p.nome)); if(gj.length<3 || gj.length<0.5*p.jogos) return null;
  const tit=gj.filter(j=>noGol(j,p.nome)===1 && j.gp!=null), cs=gj.filter(j=>j.gp!=null && j.gc===0);
  return {gj, cs, csSet:new Set(cs.map(j=>j.id)), tit:tit.length, sofr:tit.reduce((s,j)=>s+j.gc,0)}; }
const jogouOuMarcou = (j,n) => { const e=j.escalacao_galo; return (e&&(e.titulares.includes(n)||e.substituicoes.some(s=>s.entrou===n))) || j.gols.some(g=>isGoal(g)&&g.jogador===n); };
function filtraJogos(f){
  const q=(f.q||'').toLowerCase(), jog=(f.jog||'').trim();
  return J.filter(j=>(!f.temp||String(j.temporada)===f.temp)&&(!f.dec||Math.floor(j.temporada/10)*10==f.dec)
    &&(!f.de||j.temporada>=+f.de)&&(!f.ate||j.temporada<=+f.ate)
    &&(!f.grupo||j.grupo===f.grupo)&&(!f.comp||j.competicao===f.comp)&&(!f.adv||j.adversario_id===f.adv)&&(!f.uf||j.adversario_uf===f.uf)
    &&(!f.res||j.resultado===f.res)&&(!f.mando||j.mando===f.mando)&&(!f.tec||j.tecnico_galo===f.tec)&&(!f.est||j.estadio===f.est)
    &&(!f.ficha||j.tem_ficha)&&(!jog||jogouOuMarcou(j,jog))
    &&(!f.plac||(j.gp!=null&&({g3:j.gp-j.gc>=3, s3:j.gc-j.gp>=3, cs:j.gc===0, ns:j.gp===0, z:j.gp===0&&j.gc===0, m5:j.gp+j.gc>=5, g5:j.gp>=5})[f.plac]))
    &&(!q||[j.estadio,j.arbitro,j.obs,j.cidade,j.tecnico_galo,j.competicao,j.adversario,...j.gols.map(g=>g.jogador)].join(' ').toLowerCase().includes(q)));
}
function ordena(l, o){
  const d=[...l], sd=j=>j.gp==null?-99:j.gp-j.gc;
  if(o==='ant') return d;
  if(o==='saldo') return d.sort((a,b)=>sd(b)-sd(a)||(b.gp||0)-(a.gp||0));
  if(o==='pior') return d.filter(j=>j.gp!=null).sort((a,b)=>sd(a)-sd(b)||(b.gc||0)-(a.gc||0));
  if(o==='gols') return d.filter(j=>j.gp!=null).sort((a,b)=>(b.gp+b.gc)-(a.gp+a.gc));
  if(o==='pub') return d.filter(j=>j.publico).sort((a,b)=>b.publico-a.publico);
  return d.reverse();
}
const linkJogos = o => '#jogos?'+new URLSearchParams(o).toString();
function vJogos(params){
  if(params){ F={...F0}; for(const [k,v] of new URLSearchParams(params)) if(k in F) F[k]=v; }
  const uniq=(arr)=>[...new Set(arr.filter(Boolean))];
  const temps=uniq(J.map(j=>j.temporada)).sort((a,b)=>b-a);
  const decs=uniq(J.map(j=>Math.floor(j.temporada/10)*10)).sort((a,b)=>b-a);
  const grupos=uniq(J.map(j=>j.grupo)).sort();
  const advs=[...new Map(J.map(j=>[j.adversario_id, j])).values()].sort((a,b)=>a.adversario.localeCompare(b.adversario));
  const ufs=uniq(J.map(j=>j.adversario_uf)).sort();
  const cnt=k=>{const c={}; J.forEach(j=>{ if(j[k]) c[j[k]]=(c[j[k]]||0)+1; }); return Object.entries(c).sort((a,b)=>b[1]-a[1]).map(x=>x[0]);};
  const tecs=cnt('tecnico_galo'), ests=cnt('estadio');
  const opt=(arr,v,lab=x=>x,val=x=>x)=>arr.map(x=>`<option value="${esc(val(x))}" ${String(val(x))===String(v)?'selected':''}>${esc(lab(x))}</option>`).join('');
  const sel=(k,lab,html,todos='Todos')=>`<label>${lab}<select id="f-${k}"><option value="">${todos}</option>${html}</select></label>`;
  const adv = ['de','ate','comp','uf','tec','est','jog','ficha','plac'].some(k=>F[k]);
  setTimeout(()=>{
    Object.keys(F).forEach(k=>{ const el=$('#f-'+k); if(!el) return; el.oninput=()=>{ F[k]=el.type==='checkbox'?(el.checked?'1':''):el.value; if(k==='grupo'){F.comp=''; fillComp();} drawJogos(); }; });
    const fillComp=()=>{ const cs=uniq(J.filter(j=>!F.grupo||j.grupo===F.grupo).map(j=>j.competicao)).sort(); $('#f-comp').innerHTML=`<option value="">Todas</option>${opt(cs,F.comp)}`; };
    fillComp();
    $('#f-clear').onclick=()=>{ F={...F0}; route(); };
    drawJogos();
  });
  return `<div class="kicker">Arquivo · ${N(J.length)} partidas</div><h1>Jogos</h1>${DONO?'<p><a class="more" href="#novo-jogo">+ Novo jogo (só você vê)</a></p>':''}
  <div class="filters">
   ${sel('dec','Década',opt(decs,F.dec,d=>d+'s'),'Todas')}
   ${sel('temp','Temporada',opt(temps,F.temp),'Todas')}
   ${sel('grupo','Competição',opt(grupos,F.grupo),'Todas')}
   ${sel('adv','Adversário',opt(advs,F.adv,j=>j.adversario+(j.adversario_uf?' ('+j.adversario_uf+')':''),j=>j.adversario_id))}
   ${sel('res','Resultado',opt(['V','E','D'],F.res,x=>({V:'Vitória',E:'Empate',D:'Derrota'})[x]))}
   ${sel('mando','Mando',opt(['C','F','N'],F.mando,x=>x==='N'?'Neutro ou sem informação':mandoTxt[x]))}
   <label>Busca livre<input id="f-q" placeholder="goleador, estádio, árbitro…" value="${esc(F.q)}"></label>
  </div>
  <details class="adv" ${adv?'open':''}><summary>Filtros avançados</summary><div class="filters">
   <label>De (ano)<input id="f-de" type="number" min="1909" max="2030" placeholder="1909" value="${esc(F.de)}" style="min-width:90px;width:90px"></label>
   <label>Até (ano)<input id="f-ate" type="number" min="1909" max="2030" placeholder="2026" value="${esc(F.ate)}" style="min-width:90px;width:90px"></label>
   ${sel('comp','Torneio exato','','Todas')}
   ${sel('uf','Estado / país',opt(ufs,F.uf))}
   ${sel('plac','Placar',opt(Object.keys(PLAC),F.plac,x=>PLAC[x]),'Qualquer')}
   ${sel('tec','Técnico*',opt(tecs,F.tec))}
   ${sel('est','Estádio*',opt(ests,F.est))}
   <label>Jogador (jogou ou marcou)<input id="f-jog" list="dl-jog" placeholder="nome…" value="${esc(F.jog)}"></label>
   <datalist id="dl-jog">${D.jogadores.filter(p=>p.jogos||p.gols).map(p=>`<option value="${esc(p.nome)}">`).join('')}</datalist>
   <label class="chk"><input id="f-ficha" type="checkbox" ${F.ficha?'checked':''}> Só com ficha completa</label>
  </div><p class="count">*Técnico e estádio só nos jogos com ficha (desde ${fmtD(D.meta.escalacoes_desde)}). Jogador: escalações desde a mesma data; gols em toda a história.</p></details>
  <div class="filters" style="margin-top:6px">${sel('ord','Ordenar',opt(Object.keys(ORD),F.ord,x=>ORD[x]),'Mais recentes').replace('<option value="">Mais recentes</option>','')}<button class="ghost" id="f-clear">Limpar filtros</button></div>
  <div id="jsum"></div><div id="jlist"></div>`;
}
function drawJogos(){
  const l=filtraJogos(F); const r=rec(l);
  const top=scorersOf(l).slice(0,6);
  $('#jsum').innerHTML=`<div class="sumbox"><div class="sumnum"><b>${N(l.length)}</b> jogos</div><div class="mono">${r.V}V ${r.E}E ${r.D}D · ${N(r.gp)} gols pró, ${N(r.gc)} contra · <b>${aprov(r)}</b> de aproveitamento</div>${l.length?resultBar(r):''}
   ${top.length?`<p class="count" style="margin-top:8px">Artilheiros no recorte: ${top.map(([n,g])=>`<a href="#jogador-${slug(n)}">${esc(n)}</a> ${g}`).join(' · ')}</p>`:''}</div>`;
  $('#jlist').innerHTML=matchTable(ordena(l,F.ord),200,{pub:F.ord==='pub'});
}

/* ---------- Jogo ---------- */
function vJogo(id){
  const j=byId[id]; if(!j) return '<p class="empty">Jogo não encontrado.</p>';
  const nav = `<a class="back" href="#jogos">← Jogos</a>`;
  const prev = byId[id-1], nxt = byId[id+1];
  const pager = `<p class="count pager">${prev?`<a href="#jogo-${prev.id}">← jogo anterior</a>`:''}${nxt?`<a href="#jogo-${nxt.id}">próximo jogo →</a>`:''}</p>`;
  const galoLeft = j.tem_ficha && j.galo_mandante!=null ? j.galo_mandante : j.mando!=='F';
  const L = galoLeft ? {n:'Atlético',uf:'MG',g:j.gp} : {n:j.adversario,uf:j.adversario_uf,g:j.gc};
  const R = galoLeft ? {n:j.adversario,uf:j.adversario_uf,g:j.gc} : {n:'Atlético',uf:'MG',g:j.gp};
  const g=[...j.gols].sort((a,b)=>(a.minuto??999)-(b.minuto??999));
  const goalList = g.length?`<h2>Gols</h2><ul class="goal-list">${g.map(x=>`<li><span class="mono">${x.minuto!=null?x.minuto+"'":'–'}</span><span>${isGoal(x)?`<a href="#jogador-${slug(x.jogador)}">${esc(x.jogador)}</a>`:esc(x.jogador)} ${x.tipo?`<span class="tag light">${esc(x.tipo)}</span>`:''}</span><span class="tag" style="${x.lado==='galo'?'background:var(--ink);color:var(--paper)':''}">${x.lado==='galo'?'Galo':esc(j.adversario)}</span></li>`).join('')}</ul>`:'';
  const ladoG = galoLeft ? 'galo' : 'adv';
  const ehContra = x => /contra/i.test(x.tipo||'');
  const marc = lado => { const m=new Map(); g.filter(x=>x.lado===lado).forEach(x=>{ const k=x.jogador+(ehContra(x)?' (contra)':''); if(!m.has(k)) m.set(k,{x,min:[]}); m.get(k).min.push((x.minuto!=null?x.minuto+"'":'')+(/p[eê]nal/i.test(x.tipo||'')?' pên.':'')); });
    return m.size?`<div class="scorers">${[...m.entries()].map(([k,v])=>`<div>${lado==='galo'&&isGoal(v.x)&&D.jogadores.some(p=>p.nome===v.x.jogador)?`<a href="#jogador-${slug(v.x.jogador)}">${esc(k)}</a>`:esc(k)} <span class="mono">${v.min.filter(Boolean).join(', ')}</span></div>`).join('')}</div>`:''; };
  const golsDe = (lado) => { const c={}; g.filter(x=>x.lado===lado&&!ehContra(x)).forEach(x=>{ c[x.jogador]=(c[x.jogador]||0)+1; }); return c; };
  const bola = n => n ? `<span class="gb" title="${n} ${n>1?'gols':'gol'}">${n>3?'⚽×'+n:'⚽'.repeat(n)}</span>` : '';
  let ficha = '';
  if (j.tem_ficha){
    const eg=j.escalacao_galo, ea=j.escalacao_adv;
    const nomeJ=(p,galo)=>galo&&D.jogadores.some(x=>x.nome===p)?`<a href="#jogador-${slug(p)}">${esc(p)}</a>`:esc(p);
    const lineup=(e,tec,galo)=>{ if(!e||!e.titulares.length) return '<p class="empty">Escalação não registrada.</p>';
      const gc=golsDe(galo?'galo':'adv'), subs=[...new Set(e.substituicoes.map(s=>s.entrou).filter(Boolean))];
      return `<ul class="lineup">${e.titulares.map(p=>`<li><span>${nomeJ(p,galo)} ${bola(gc[p])}</span></li>`).join('')}</ul>
      ${subs.length?`<div class="subhead">Substitutos</div><ul class="lineup">${subs.map(p=>`<li><span>${nomeJ(p,galo)} ${bola(gc[p])}</span></li>`).join('')}</ul>`:''}
      ${tec?`<p class="count">Técnico: <b>${galo?`<a href="${linkJogos({tec})}">${esc(tec)}</a>`:esc(tec)}</b></p>`:''}`; };
    ficha = `<div class="meta">
      <div><span>Local</span>${esc(j.cidade||'–')}</div><div><span>Estádio</span>${j.estadio?`<a href="${linkJogos({est:j.estadio})}">${esc(j.estadio)}</a>`:'–'}</div>
      <div><span>Público</span>${j.publico!=null?N(j.publico)+' '+esc(j.publico_tipo||''):'–'}</div><div><span>Renda</span>${esc(j.renda||'–')}</div>
      <div><span>Árbitro</span>${esc(j.arbitro||'–')}</div>${j.expulsoes?`<div><span>Expulsões</span>${esc(j.expulsoes)}</div>`:''}</div>
      ${eg&&eg.titulares&&eg.titulares.length>=7?`<h2>O Galo em campo</h2>${campoHTML(eg.titulares,{form:j.data<'1960'&&eg.titulares.length===11?'2-3-5':null, gols:golsDe('galo'), notas:(diario()[j.id]||{}).nj, craque:(diario()[j.id]||{}).cr})}`:''}
      <div class="grid2"><div><h2>${esc(L.n)}</h2>${lineup(galoLeft?eg:ea, galoLeft?j.tecnico_galo:j.tecnico_adv, galoLeft)}</div>
      <div><h2>${esc(R.n)}</h2>${lineup(galoLeft?ea:eg, galoLeft?j.tecnico_adv:j.tecnico_galo, !galoLeft)}</div></div>
      ${j.obs?`<div class="note"><b>Obs.</b> ${esc(j.obs)}</div>`:''}`;
  } else {
    const mt=[j.cidade?`<div><span>Local</span>${esc(j.cidade)}</div>`:'', j.estadio?`<div><span>Estádio</span><a href="${linkJogos({est:j.estadio})}">${esc(j.estadio)}</a></div>`:'', j.publico!=null?`<div><span>Público</span>${N(j.publico)} ${esc(j.publico_tipo||'')}</div>`:''].join('');
    ficha = `${mt?`<div class="meta">${mt}</div>`:''}<div class="note">Ficha completa (escalação${j.estadio?'':', estádio'}${j.publico!=null?'':', público'}) ainda não cadastrada para este jogo.${j.cidade_fonte?' Local e público: RSSSF Brasil (Jackass Molibidenio).':''}</div>`;
  }
  return `${nav}<div class="kicker">${esc(j.competicao||'')}${j.fase?' · '+esc(j.fase):''} · ${fmtD(j.data,j.data_aprox)} ${mandoLbl(j)?' · '+mandoLbl(j):''}</div>
  <div class="match-head"><div class="t">${cr(galoLeft?'galo':j.adversario_id,'crb')}<div><span>${esc(L.n)} <span class="uf">${esc(L.uf||'')}</span></span>${marc(ladoG)}</div></div><div class="sc">${j.gp==null?(j.wo?'WO':'×'):L.g+'–'+R.g}</div><div class="t r"><div><span>${esc(R.n)} <span class="uf">${esc(R.uf||'')}</span></span>${marc(ladoG==='galo'?'adv':'galo')}</div>${cr(galoLeft?j.adversario_id:'galo','crb')}</div></div>
  ${j.nota?`<div class="note">${esc(j.nota)}</div>`:''}
  ${blocoDonoJogo(j)}
  ${ficha}
  ${j.resultado?blocoDiario(j):''}${blocoPalpite(j)}
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0">${tw(resumoJogo(j))}${j.resultado?artBtn({t:'jogo',id:j.id}):''}</div>
  ${j.correcoes?`<div class="note"><b>Correção Galo Metrics.</b> ${j.correcoes.map(esc).join(' ')}</div>`:''}
  <p class="count" style="margin-top:20px"><a href="#adversario-${slug(j.adversario_id)}">Retrospecto contra ${esc(j.adversario)} →</a></p>${pager}`;
}

/* ---------- Jogadores ---------- */
function vJogadores(){
  setTimeout(()=>{
    const rows=D.jogadores.map(p=>({...p,pos:posTxt(p.nome),_href:'jogador-'+slug(p.nome),gb:golsBest(p),periodo:p.periodo_aceito||((p.primeiro||'').slice(0,4)+'–'+(p.ultimo||'').slice(0,4))}));
    const draw=()=>{ const q=$('#pq').value.toLowerCase(); sortable('ptab',[
      {k:'nome',t:'Jogador'},{k:'pos',t:'Posição'},{k:'gb',t:'Gols',n:1,f:o=>{const g=accG(ACC.p[o.nome]?.gols,o.nome); return g?g.atual:o.gols;}},{k:'jogos',t:'Jogos*',n:1,f:o=>{const j=ACC.p[o.nome]?.jogos; return j?j.v+(j.dataAte?jogosApos(o.nome,j.dataAte):0):o.jogos;}},{k:'gols_penalti',t:'Pên.*',n:1},{k:'periodo',t:'Período'}],
      rows.filter(r=>r.nome.toLowerCase().includes(q)),'gb'); };
    $('#pq').oninput=draw; draw();
  });
  return `<div class="kicker">Elenco histórico</div><h1>Jogadores</h1>
  <div class="filters"><label>Buscar jogador<input id="pq" placeholder="nome…"></label></div>
  <p class="cmp-cta"><a class="more" href="#comparar">Comparar jogadores →</a></p>
  <p class="count">Quando existe número aceito pelo clube e pela imprensa, é ele que aparece (a comparação com a base fica na página do jogador). Gols cobrem toda a história. *Jogos e pênaltis só a partir de ${fmtD(D.meta.escalacoes_desde)}, quando as escalações entram na base.</p><div id="ptab"></div>`;
}
function vJogador(s){
  const p=D.jogadores.find(x=>slug(x.nome)===s); if(!p) return '<p class="empty">Jogador não encontrado.</p>';
  const list=J.filter(j=>{const e=j.escalacao_galo; return (e&&(e.titulares.includes(p.nome)||e.substituicoes.some(x=>x.entrou===p.nome)))||j.gols.some(g=>isGoal(g)&&g.jogador===p.nome);});
  const gpj=j=>j.gols.filter(g=>isGoal(g)&&g.jogador===p.nome).length;
  const comps=[...new Set([...Object.keys(p.por_comp),...Object.keys(p.gols_comp)])].sort((a,b)=>(p.gols_comp[b]||0)-(p.gols_comp[a]||0));
  const r=rec(list.filter(j=>j.escalacao_galo));
  const GK=goleiro(p,list);
  const ag=accG(ACC.p[p.nome]?.gols,p.nome), aj=ACC.p[p.nome]?.jogos;
  const ajAtual = aj ? aj.v + (aj.dataAte?jogosApos(p.nome,aj.dataAte):0) : null;
  const notaAcc = (ag||aj) ? `<div class="note acc-note"><b>Número aceito.</b> ${ag?`Gols: ${ag.v}${ag.dataAte?` até ${fmtD(ag.dataAte)}`:''} (${fonteLink(ag.fonte)})${ag.extra?`, mais ${ag.extra} registrados na base depois disso`:''}. `:''}${aj?`Jogos: ${aj.v}${aj.dataAte?` até ${fmtD(aj.dataAte)}`:''} (${fonteLink(aj.fonte)})${ajAtual>aj.v?`, mais ${ajAtual-aj.v} registrados na base depois disso`:''}. `:''}${((ag&&ag.base!==ag.atual)||(aj&&p.jogos&&p.jogos!==ajAtual))?`Em cinza, o que a base Galo Metrics registra jogo a jogo${ag&&ACC.p[p.nome].gols.ano<9999?` entre ${ACC.p[p.nome].gols.de} e ${ACC.p[p.nome].gols.ano}`:''}.`:(ag||(aj&&p.jogos))?`A base Galo Metrics registra o mesmo número${ag&&ACC.p[p.nome].gols.ano<9999?` entre ${ACC.p[p.nome].gols.de} e ${ACC.p[p.nome].gols.ano}`:''}.`:''}</div>` : '';
  if (p.soAceito) return `<a class="back" href="#jogadores">← Jogadores</a><div class="kicker">Jogador · ${esc(p.periodo_aceito)}</div><h1>${esc(p.nome)}</h1>
    <div class="tiles"><div class="tile"><b>${N(ajAtual)}</b><small class="basesm">ainda sem escalações na base</small><span>Jogos</span></div></div>${notaAcc.replace(/Em cinza,[^<]*/,'')}
    <p class="count">A base tem escalações a partir de ${fmtD(D.meta.escalacoes_desde)}; os jogos deste período serão conferidos quando as fichas antigas entrarem.</p>`;
  return `<a class="back" href="#jogadores">← Jogadores</a><div class="kicker">${(()=>{ const x=posicaoDe(p.nome); return x?esc(x.pos)+(x.est?' (estimada)':'')+' · ':'Jogador · '; })()}${fmtD(p.primeiro)} a ${fmtD(p.ultimo)}</div><h1>${esc(p.nome)}</h1>
  <div class="tiles">${GK&&!(ag?ag.atual:p.gols)?'':`<div class="tile"><b>${ag?ag.atual:p.gols}</b>${ag&&ag.base!==ag.atual?`<small class="basesm">base ${ag.base}</small>`:''}<span>Gols</span></div>`}${aj&&!p.jogos?`<div class="tile"><b>${N(ajAtual)}</b><small class="basesm">sem escalações na base</small><span>Jogos</span></div>`:''}${p.jogos?`<div class="tile"><b>${aj?N(ajAtual):p.jogos}</b>${aj&&p.jogos!==ajAtual?`<small class="basesm">base ${p.jogos}*</small>`:''}<span>Jogos${aj?'':'*'}</span></div>${GK?`<div class="tile"><b>${N(GK.cs.length)}</b><small class="basesm">${Math.round(100*GK.cs.length/GK.gj.length)}% dos ${GK.gj.length} jogos no gol</small><span>Sem sofrer gols*</span></div><div class="tile"><b>${(GK.sofr/Math.max(1,GK.tit)).toFixed(2).replace('.',',')}</b><span>Gols sofridos por jogo*</span></div>${(()=>{ const pr=penResumo(p.nome); return pr.l.length?`<div class="tile"><b>${pr.l.length}</b><small class="basesm">${pr.jogo} no jogo · ${pr.disputa} em disputas</small><span>Pênaltis defendidos*</span></div>`:''; })()}`:`<div class="tile"><b>${p.gols_penalti}</b><span>De pênalti*</span></div>${(()=>{ const f=golsDeTipo(p.nome,e=>e.falta); return f?`<div class="tile"><b>${f}</b><span>De falta</span></div>`:''; })()}${(()=>{ const d=golsDeTipo(p.nome,e=>e.decisivo); return d?`<div class="tile"><b>${d}</b><span>Gols da vitória</span></div>`:''; })()}`}<div class="tile"><b>${aprov(r)}</b><span>Aproveit. do time*</span></div>`:''}</div>
  ${blocoDonoJogador(p)}
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0">${tw(`${nomeV(p.nome)} pelo Galo: ${N(ag?ag.atual:p.gols)} gols${p.jogos?`, ${N(aj?ajAtual:p.jogos)} jogos`:''}, de ${(p.primeiro||'').slice(0,4)} a ${(p.ultimo||'').slice(0,4)}.`)}</div>
  ${cartaArquivo(p)}${notaAcc}${p.jogos?`<p class="count">*Na base, a partir de ${fmtD(D.meta.escalacoes_desde)}, período com escalações.</p>`:''}
  ${perfilJogador(p,list,gpj,comps,GK)}
  ${(()=>{ const pr=penResumo(p.nome); if(!pr.l.length) return '';
    return `<h2>Pênaltis defendidos</h2><div class="grid2"><div><p class="classico-num"><b>${pr.jogo}</b> durante os jogos</p></div><div><p class="classico-num"><b>${pr.disputa}</b> em disputas de pênaltis</p></div></div>
    <table><thead><tr><th>Data</th><th>Partida</th><th>Situação</th><th class="hide-s">Cobrador</th></tr></thead><tbody>${(()=>{ const g=[]; pr.l.forEach(o=>{ const k=o.j.id+o.x.tipo; const last=g[g.length-1]; if(last&&last.k===k){ last.n++; if(o.x.cobrador) last.c.push(o.x.cobrador); } else g.push({k,j:o.j,t:o.x.tipo,n:1,c:o.x.cobrador?[o.x.cobrador]:[]}); }); return g.reverse(); })().map(o=>`<tr class="click" onclick="location.hash='jogo-${o.j.id}'"><td class="mono">${fmtD(o.j.data)}</td><td>${linha(o.j)}</td><td>${o.t==='jogo'?'No jogo':'Disputa de pênaltis'}${o.n>1?` · <b>${o.n} defesas</b>`:''}</td><td class="hide-s">${esc(o.c.join(', ')||'–')}</td></tr>`).join('')}</tbody></table>
    <p class="count">Levantado das observações das fichas, a partir de ${D.meta.escalacoes_desde.slice(0,4)}, e conferido com a Galo Digital nos casos de Victor e Everson. Defesas que nenhuma das fontes cita ficam de fora.</p>`; })()}
  <h2>Jogos</h2><p class="count"><a href="${linkJogos({jog:p.nome})}">Abrir no arquivo de jogos, com filtros →</a> · <a href="#comparar?${new URLSearchParams({a:p.nome})}">Comparar com outro jogador →</a></p><table><thead><tr><th>Data</th><th></th><th>Partida</th><th class="hide-s">Competição</th><th class="n">Gols</th></tr></thead><tbody>${[...list].reverse().map(j=>`<tr class="click" onclick="location.hash='jogo-${j.id}'"><td class="mono">${fmtD(j.data,j.data_aprox)}</td><td>${resBox(j)}</td><td>${linha(j)}</td><td class="hide-s">${esc(j.competicao)}</td><td class="n">${gpj(j)||''}</td></tr>`).join('')}</tbody></table>`;
}

function perfilJogador(p,list,gpj,comps,GK){
  const val = GK ? (j=>GK.csSet.has(j.id)?1:0) : gpj;
  const anos={}; list.forEach(j=>{ const a=(anos[j.temporada] ||= {j:0,g:0}); if(j.escalacao_galo&&jogouOuMarcou(j,p.nome)&&(j.escalacao_galo.titulares.includes(p.nome)||j.escalacao_galo.substituicoes.some(s=>s.entrou===p.nome))) a.j++; a.g+=val(j); });
  const ys=Object.keys(anos).sort(), mx=Math.max(1,...ys.map(y=>Math.max(anos[y].g, anos[y].j)));
  const csComp={}; if(GK) GK.cs.forEach(j=>{ csComp[j.grupo]=(csComp[j.grupo]||0)+1; });
  const vit={}; list.forEach(j=>{ const g=val(j); if(g){ const v=(vit[j.adversario_id] ||= {n:j.adversario,id:j.adversario_id,g:0}); v.g+=g; } });
  const vits=Object.values(vit).sort((a,b)=>b.g-a.g).slice(0,8);
  const marc=list.filter(j=>gpj(j)), hat=marc.filter(j=>gpj(j)>=3), maxg=marc.length?Math.max(...marc.map(gpj)):0, best=marc.find(j=>gpj(j)===maxg);
  return `<div class="grid2"><div><h2>Por temporada</h2><table class="seas"><thead><tr><th>Ano</th>${p.jogos?'<th class="n">J*</th>':''}<th class="n">${GK?'Sem sofrer':'Gols'}</th><th></th></tr></thead><tbody>${ys.map(y=>`<tr class="click" onclick="location.hash='${'jogos?'+new URLSearchParams({jog:p.nome,temp:y})}'"><td class="mono">${y}</td>${p.jogos?`<td class="n">${anos[y].j||''}</td>`:''}<td class="n">${anos[y].g||''}</td><td style="width:45%"><div class="hb"><i style="width:${100*anos[y].g/mx}%"></i>${p.jogos?`<i class="j" style="width:${100*anos[y].j/mx}%"></i>`:''}</div></td></tr>`).join('')}</tbody></table>
   <p class="count">Barra preta: ${GK?'jogos sem sofrer gols':'gols'}. ${p.jogos?'Amarela: jogos (desde '+fmtD(D.meta.escalacoes_desde)+').':''}</p></div>
  <div><h2>Por competição</h2><table><thead><tr><th>Competição</th><th class="n">${GK?'Sem sofrer':'Gols'}</th>${p.jogos?'<th class="n">Jogos*</th>':''}</tr></thead><tbody>${comps.map(c=>`<tr><td>${esc(c)}</td><td class="n">${GK?(csComp[c]||0):(p.gols_comp[c]||0)}</td>${p.jogos?`<td class="n">${p.por_comp[c]||0}</td>`:''}</tr>`).join('')}</tbody></table>
  ${vits.length?`<h2>${GK?'Mais jogos sem sofrer gols contra':'Vítimas preferidas'}</h2><table><tbody>${vits.map(v=>`<tr class="click" onclick="location.hash='adversario-${slug(v.id)}'"><td>${cr(v.id)}${esc(v.n)}</td><td class="n">${v.g}</td></tr>`).join('')}</tbody></table>`:''}
  ${marc.length?`<div class="note">${marc.length} jogos com gol${hat.length?` · ${hat.length} com 3 ou mais`:''}${best&&maxg>1?` · recorde: ${maxg} gols contra <a href="#jogo-${best.id}">${esc(best.adversario)}</a> (${fmtD(best.data,best.data_aprox)})`:''}. Primeiro gol na base: <a href="#jogo-${marc[0].id}">${fmtD(marc[0].data,marc[0].data_aprox)}</a>.</div>`:''}</div></div>`;
}

/* ---------- Adversários ---------- */
let ADV;
function advRows(){
  if (ADV) return ADV;
  const m={}; J.forEach(j=>{ const a=(m[j.adversario_id] ||= {id:j.adversario_id,jogos:[]}); a.nome=j.adversario; a.uf=j.adversario_uf||''; a.jogos.push(j); }); // nome atual do clube
  return ADV = Object.values(m).map(a=>{const r=rec(a.jogos); return {...a,...r,J:a.jogos.length,saldo:r.gp-r.gc,ap:r.n?Math.round(100*(3*r.V+r.E)/(3*r.n)):0,_href:'adversario-'+slug(a.id)};});
}
function vAdversarios(){
  setTimeout(()=>{ const rows=advRows(); const draw=()=>{const q=$('#aq').value.toLowerCase(); sortable('atab',[
    {k:'nome',t:'Adversário',f:o=>`${cr(o.id)}${esc(o.nome)} <small class="uf">${esc(o.uf)}</small>`},{k:'J',t:'J',n:1},{k:'V',t:'V',n:1},{k:'E',t:'E',n:1},{k:'D',t:'D',n:1},{k:'gp',t:'GP',n:1},{k:'gc',t:'GC',n:1},{k:'saldo',t:'SG',n:1},{k:'ap',t:'Aprov.',n:1,f:o=>o.ap+'%'}],
    rows.filter(r=>(r.nome+' '+r.uf).toLowerCase().includes(q)),'J',150);}; $('#aq').oninput=draw; draw(); });
  return `<div class="kicker">Confrontos</div><h1>Adversários</h1><div class="filters"><label>Buscar clube<input id="aq" placeholder="nome ou estado…"></label></div><div id="atab"></div>`;
}
function vAdversario(s){
  const a=advRows().find(x=>slug(x.id)===s); if(!a) return '<p class="empty">Adversário não encontrado.</p>';
  const played=a.jogos.filter(j=>j.resultado&&j.gp!=null);
  const best=[...played].sort((x,y)=>(y.gp-y.gc)-(x.gp-x.gc))[0], worst=[...played].sort((x,y)=>(x.gp-x.gc)-(y.gp-y.gc))[0];
  const casa=rec(a.jogos.filter(j=>j.mando==='C')), fora=rec(a.jogos.filter(j=>j.mando==='F')), neu=rec(a.jogos.filter(j=>j.mando==='N'));
  const sc={}; a.jogos.forEach(j=>j.gols.forEach(g=>{ if(isGoal(g)) sc[g.jogador]=(sc[g.jogador]||0)+1; }));
  const VS=ACC.vs[a.id]||{};
  const linhasArt=Object.entries(sc).map(([n,g])=>{ const x=accG(VS[n],n,a.id); return {n, best:x?x.atual:g, base:x?x.base:g, acc:!!x}; });
  Object.keys(VS).forEach(n=>{ if(!sc[n]){ const x=accG(VS[n],n,a.id); linhasArt.push({n,best:x.atual,base:x.base,acc:true}); } });
  const tops=linhasArt.sort((x,y)=>y.best-x.best).slice(0,10);
  const fonteVS=Object.values(VS)[0]?.fonte;
  const H=ACC.h2h[a.id]; let topo;
  if(H){
    const pos=rec(a.jogos.filter(j=>j.data>H.ate)), base=rec(a.jogos);
    const ac={n:H.jogos+pos.n, V:H.V+pos.V, E:H.E+pos.E, D:H.D+pos.D};
    const t=(big,small,lab)=>`<div class="tile"><b>${N(big)}</b>${small!=null&&small!==big?`<small class="basesm">base ${N(small)}</small>`:''}<span>${lab}</span></div>`;
    topo=`<div class="tiles">${t(ac.n,base.n,'Jogos')}${t(ac.V,base.V,'Vitórias')}${t(ac.E,base.E,'Empates')}${t(ac.D,base.D,'Derrotas')}${t(base.gp,null,'Gols pró*')}${t(base.gc,null,'Gols contra*')}<div class="tile"><b>${aprov(ac)}</b>${aprov(base)!==aprov(ac)?`<small class="basesm">base ${aprov(base)}</small>`:''}<span>Aproveitamento</span></div></div>
    ${resultBar(ac)}
    <div class="note acc-note"><b>Número aceito.</b> Contagem do Atlético até ${fmtD(H.ate)} (${H.jogos} jogos, ${H.V}V ${H.E}E ${H.D}D; ${fonteLink(H.fonte)})${pos.n?`, somada aos ${pos.n} jogos disputados depois, registrados na base`:''}. Em cinza, o que a base Galo Metrics registra jogo a jogo, incluindo a era Palestra Itália. ${esc(H.explicacao)} *Gols só pela base.</div>`;
  } else topo = tiles(a)+resultBar(a);
  return `<a class="back" href="#adversarios">← Adversários</a><div class="kicker">Retrospecto do Galo contra</div><div class="advhead">${cr('galo','crh')}<span class="vs">×</span>${cr(a.id,'crh crh2')}<h1>${esc(a.nome)} <span class="uf">${esc(a.uf)}</span></h1></div>
  ${topo}
  <div class="grid2"><div><h2>Em casa</h2><p class="mono">${casa.n} jogos · ${casa.V}V ${casa.E}E ${casa.D}D · ${casa.gp}-${casa.gc}</p><h2>Fora</h2><p class="mono">${fora.n} jogos · ${fora.V}V ${fora.E}E ${fora.D}D · ${fora.gp}-${fora.gc}</p>${neu.n?`<h2>Neutro ou sem mando informado</h2><p class="mono">${neu.n} jogos · ${neu.V}V ${neu.E}E ${neu.D}D · ${neu.gp}-${neu.gc}</p>`:''}
  ${best&&best.resultado==='V'?`<div class="note">Maior vitória: <a href="#jogo-${best.id}">${linha(best)}</a> (${fmtD(best.data)})</div>`:''}
  ${worst&&worst.resultado==='D'?`<div class="note">Pior derrota: <a href="#jogo-${worst.id}">${linha(worst)}</a> (${fmtD(worst.data)})</div>`:''}</div>
  <div><h2>Artilheiros do Galo no confronto</h2>${tops.length?`<table><tbody>${tops.map(r=>`<tr class="click" onclick="location.hash='jogador-${slug(r.n)}'"><td>${esc(r.n)}</td><td class="n">${r.best}</td></tr>`).join('')}</tbody></table>${fonteVS?`<p class="count">Gols pelo número aceito (${fonteLink(fonteVS)}) quando existe; os demais, pela base.</p>`:''}`:'<p class="empty">Sem gols registrados.</p>'}</div></div>
  <h2>Sequência</h2><div class="spark">${a.jogos.map(j=>j.resultado?`<a href="#jogo-${j.id}" class="res ${j.resultado}" title="${fmtD(j.data)}"></a>`:'').join('')}</div>
  <h2>Todos os jogos</h2><p class="count"><a href="${linkJogos({adv:a.id})}">Abrir no arquivo de jogos, com filtros →</a></p>${matchTable([...a.jogos].reverse())}`;
}

/* ---------- Temporadas ---------- */
function scorersOf(list){ const sc={}; list.forEach(j=>j.gols.forEach(g=>{ if(isGoal(g)) sc[g.jogador]=(sc[g.jogador]||0)+1; })); return Object.entries(sc).sort((a,b)=>b[1]-a[1]); }
function vTemporadas(){
  const t={}; J.forEach(j=>(t[j.temporada] ||= []).push(j));
  return `<div class="kicker">Ano a ano</div><h1>Temporadas</h1><table style="margin-top:20px"><thead><tr><th>Ano</th><th class="n">J</th><th class="n">V</th><th class="n">E</th><th class="n">D</th><th class="n hide-s">GP</th><th class="n hide-s">GC</th><th class="n">Aprov.</th><th>Artilheiro</th></tr></thead><tbody>${
   Object.entries(t).sort((a,b)=>b[0]-a[0]).map(([y,l])=>{const r=rec(l); const top=scorersOf(l)[0];
    return `<tr class="click" onclick="location.hash='temporada-${y}'"><td class="mono"><b>${y}</b></td><td class="n">${r.n}</td><td class="n">${r.V}</td><td class="n">${r.E}</td><td class="n">${r.D}</td><td class="n hide-s">${r.gp}</td><td class="n hide-s">${r.gc}</td><td class="n">${aprov(r)}</td><td>${top?esc(top[0])+' ('+top[1]+')':'–'}</td></tr>`;}).join('')}</tbody></table>`;
}
function vTemporada(y){
  const l=J.filter(j=>String(j.temporada)===y); const r=rec(l);
  const byC={}; l.forEach(j=>(byC[j.competicao] ||= []).push(j));
  return `<a class="back" href="#temporadas">← Temporadas</a><div class="kicker">Temporada</div><h1>${y}</h1>${tiles(r)}${resultBar(r)}
  <p class="count pager">${byId && J.some(j=>j.temporada==y-1)?`<a href="#temporada-${y-1}">← ${y-1}</a>`:''}${J.some(j=>j.temporada==+y+1)?`<a href="#temporada-${+y+1}">${+y+1} →</a>`:''}</p>
  <div class="grid2"><div><h2>Por competição</h2><table><thead><tr><th>Competição</th><th class="n">J</th><th class="n">V</th><th class="n">E</th><th class="n">D</th><th class="n">Aprov.</th></tr></thead><tbody>${Object.entries(byC).map(([c,x])=>{const q=rec(x);return `<tr><td>${esc(c)}</td><td class="n">${q.n}</td><td class="n">${q.V}</td><td class="n">${q.E}</td><td class="n">${q.D}</td><td class="n">${aprov(q)}</td></tr>`}).join('')}</tbody></table></div>
  <div><h2>Artilharia</h2><table><thead><tr><th>Jogador</th><th class="n">Gols</th></tr></thead><tbody>${scorersOf(l).slice(0,12).map(([n,g])=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td>${esc(n)}</td><td class="n">${g}</td></tr>`).join('')}</tbody></table></div></div>
  <h2>Jogos</h2>${matchTable([...l].reverse(),500)}`;
}


/* ---------- Números aceitos ---------- */
const sinal = d => d===0 ? '<span class="dif zero">igual</span>' : `<span class="dif">${d>0?'+':'−'}${N(Math.abs(d))}</span>`;
function golsDe(nome, de, ate, dataMax, advId){
  let n=0; J.forEach(j=>{ if(j.temporada<de||j.temporada>ate) return; if(dataMax&&j.data>dataMax) return; if(advId&&j.adversario_id!==advId) return;
    j.gols.forEach(g=>{ if(isGoal(g)&&g.jogador===nome) n++; }); }); return n;
}
/* ---------- Recordes ---------- */
function streaks(list, ok){ let best={n:0}, cur={n:0}; list.forEach(j=>{ if(ok(j)){ if(!cur.n) cur={n:0,a:j}; cur.n++; cur.b=j; if(cur.n>best.n) best={...cur}; } else cur={n:0}; }); return best; }
function vRecordes(){
  const pl=J.filter(j=>j.resultado&&j.gp!=null);
  const mini=(l,extra=()=> '')=>`<table><tbody>${l.map(j=>`<tr class="click" onclick="location.hash='jogo-${j.id}'"><td class="mono">${fmtD(j.data,j.data_aprox)}</td><td>${linha(j)}</td><td class="hide-s uf">${esc(j.competicao||'')}${extra(j)}</td></tr>`).join('')}</tbody></table>`;
  const top=(arr,f,n=10)=>[...arr].sort(f).slice(0,n);
  const vit=top(pl,(a,b)=>(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp), der=top(pl,(a,b)=>(a.gp-a.gc)-(b.gp-b.gc)||b.gc-a.gc);
  const gols=top(pl,(a,b)=>(b.gp+b.gc)-(a.gp+a.gc)), pub=top(J.filter(j=>j.publico),(a,b)=>b.publico-a.publico);
  const sk=[['Vitórias seguidas',j=>j.resultado==='V'],['Jogos sem perder',j=>j.resultado!=='D'],['Jogos marcando',j=>j.gp>0],['Jogos sem sofrer gols',j=>j.gc===0],['Derrotas seguidas',j=>j.resultado==='D'],['Jogos sem vencer',j=>j.resultado!=='V']].map(([t,f])=>[t,streaks(pl,f)]);
  const pg=[]; J.forEach(j=>{ const c={}; j.gols.forEach(g=>{ if(isGoal(g)) c[g.jogador]=(c[g.jogador]||0)+1; }); Object.entries(c).forEach(([n,g])=>{ if(g>=4) pg.push({n,g,j}); }); });
  pg.sort((a,b)=>b.g-a.g||a.j.data.localeCompare(b.j.data));
  const hat={}; J.forEach(j=>{ const c={}; j.gols.forEach(g=>{ if(isGoal(g)) c[g.jogador]=(c[g.jogador]||0)+1; }); Object.entries(c).forEach(([n,g])=>{ if(g>=3) hat[n]=(hat[n]||0)+1; }); });
  const hats=Object.entries(hat).sort((a,b)=>b[1]-a[1]).slice(0,10);
  const decs={}; J.forEach(j=>(decs[Math.floor(j.temporada/10)*10] ||= []).push(j));
  return `<div class="kicker">Marcas da história</div><h1>Recordes</h1>
  <h2>Sequências</h2><div class="tiles">${sk.map(([t,s])=>`<div class="tile"><b>${s.n}</b><span>${t}</span>${s.n?`<small class="basesm"><a href="#jogo-${s.a.id}">${fmtD(s.a.data)}</a> a <a href="#jogo-${s.b.id}">${fmtD(s.b.data)}</a></small>`:''}</div>`).join('')}</div>
  <div class="grid2"><div><h2>Maiores vitórias</h2>${mini(vit)}</div><div><h2>Piores derrotas</h2>${mini(der)}</div></div>
  ${blocoPublico(true)}<div class="grid2"><div><h2>Maiores públicos</h2>${mini(pub,j=>` · <b>${N(j.publico)}</b>`)}</div><div><h2>Maiores públicos como mandante</h2>${mini(publicoTot().topCasa,j=>` · <b>${N(j.publico)}</b>`)}</div></div><h2>Jogos com mais gols</h2>${mini(gols)}${blocoBolaParada()}
  <div class="grid2"><div><h2>4 gols ou mais num jogo</h2><table><tbody>${pg.slice(0,15).map(x=>`<tr class="click" onclick="location.hash='jogo-${x.j.id}'"><td><b>${esc(x.n)}</b></td><td class="n">${x.g}</td><td class="hide-s">${cr(x.j.adversario_id)}${esc(x.j.adversario)}</td><td class="mono uf">${fmtD(x.j.data,x.j.data_aprox)}</td></tr>`).join('')}</tbody></table></div>
   <div><h2>Mais jogos com 3+ gols</h2><table><tbody>${hats.map(([n,c])=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td>${esc(n)}</td><td class="n">${c}</td></tr>`).join('')}</tbody></table></div></div>
  ${(()=>{ const m={}; J.forEach(j=>(j.pen_defendidos||[]).forEach(x=>{ const r=(m[x.goleiro] ||= {jogo:0,disputa:0}); r[x.tipo]++; }));
    const l=Object.entries(m).sort((a,b)=>(b[1].jogo+b[1].disputa)-(a[1].jogo+a[1].disputa)||b[1].jogo-a[1].jogo);
    return l.length?`<h2>Pênaltis defendidos <small class="uf">desde ${D.meta.escalacoes_desde.slice(0,4)}</small></h2><table><thead><tr><th>#</th><th>Goleiro</th><th class="n">No jogo</th><th class="n">Em disputas</th><th class="n">Total</th></tr></thead><tbody>${l.map(([n,r],i)=>`<tr class="click" onclick="location.hash='jogador-${slug(n)}'"><td class="mono">${i+1}</td><td>${esc(nomeV(n))}</td><td class="n">${r.jogo}</td><td class="n">${r.disputa}</td><td class="n"><b>${r.jogo+r.disputa}</b></td></tr>`).join('')}</tbody></table><p class="count">Levantado das observações das fichas e conferido com a Galo Digital (Victor e Everson). Defesas que as fontes não citam ficam de fora.</p>`:''; })()}
  <h2>Por década</h2><table><thead><tr><th>Década</th><th class="n">J</th><th class="n">V</th><th class="n">E</th><th class="n">D</th><th class="n">Aprov.</th><th>Artilheiro</th></tr></thead><tbody>${Object.entries(decs).sort((a,b)=>b[0]-a[0]).map(([d,l])=>{const r=rec(l), t=scorersOf(l)[0]; return `<tr class="click" onclick="location.hash='${'jogos?'+new URLSearchParams({dec:d})}'"><td class="mono"><b>${d}s</b></td><td class="n">${r.n}</td><td class="n">${r.V}</td><td class="n">${r.E}</td><td class="n">${r.D}</td><td class="n">${aprov(r)}</td><td>${t?esc(t[0])+' ('+t[1]+')':'–'}</td></tr>`;}).join('')}</tbody></table>`;
}

/* ---------- Técnicos ---------- */
function vTecnicos(){
  setTimeout(()=>sortable('ttab',[{k:'nome',t:'Técnico'},{k:'jogos',t:'J',n:1},{k:'V',t:'V',n:1},{k:'E',t:'E',n:1},{k:'D',t:'D',n:1},{k:'ap',t:'Aprov.',n:1,f:o=>o.ap+'%'},{k:'periodo',t:'Período'}],
    D.tecnicos.map(t=>({...t,_href:'jogos?'+new URLSearchParams({tec:t.nome}),ap:t.jogos?Math.round(100*(3*t.V+t.E)/(3*t.jogos)):0,periodo:fmtD(t.primeiro)+' a '+fmtD(t.ultimo)})),'jogos'));
  return `<div class="kicker">Comando</div><h1>Técnicos</h1><p class="count" style="margin-top:14px">A partir de ${fmtD(D.meta.escalacoes_desde)}, quando as fichas entram na base. Inclui interinos. Clique num técnico para ver todos os jogos dele.</p><div id="ttab"></div>`;
}

/* ---------- Comparativo de jogadores ---------- */
function statsJog(nome){
  const p=D.jogadores.find(x=>x.nome===nome); if(!p) return null;
  const list=J.filter(j=>jogouOuMarcou(j,p.nome));
  const gpj=j=>j.gols.filter(g=>isGoal(g)&&g.jogador===p.nome).length;
  const ag=accG(ACC.p[p.nome]?.gols,p.nome), aj=ACC.p[p.nome]?.jogos;
  const jogos = aj ? aj.v+(aj.dataAte?jogosApos(p.nome,aj.dataAte):0) : (p.jogos||null);
  const gols = ag ? ag.atual : p.gols;
  const marc=list.filter(gpj), anos={};
  list.forEach(j=>{ anos[j.temporada]=(anos[j.temporada]||0)+gpj(j); });
  const ys=Object.keys(anos).map(Number).sort((a,b)=>a-b);
  const best=ys.length?ys.reduce((m,y)=>anos[y]>anos[m]?y:m,ys[0]):null;
  const vit={}; marc.forEach(j=>{ (vit[j.adversario] ||= 0); vit[j.adversario]+=gpj(j); });
  const vtop=Object.entries(vit).sort((a,b)=>b[1]-a[1])[0];
  const gIn = f => list.filter(f).reduce((s,j)=>s+gpj(j),0);
  const comEsc=list.filter(j=>j.escalacao_galo&&j.resultado), r=rec(comEsc);
  const GK=goleiro(p,list);
  const de = p.periodo_aceito ? +String(p.periodo_aceito).slice(0,4) : (ys[0]||null), ate = ys.length?ys[ys.length-1]:null;
  return {p, nome:p.nome, list, gols, jogos, media: jogos&&gols!=null ? gols/jogos : null,
    pen: p.jogos?p.gols_penalti:null, hat: marc.filter(j=>gpj(j)>=3).length, dois: marc.filter(j=>gpj(j)>=2).length,
    max: marc.length?Math.max(...marc.map(gpj)):0,
    cz: gIn(j=>j.adversario_id==='cruzeiro mg'), am: gIn(j=>j.adversario_id==='america mg'),
    bra: gIn(j=>j.grupo==='Campeonato Brasileiro'), min: gIn(j=>j.grupo==='Campeonato Mineiro'),
    lib: gIn(j=>j.competicao==='Libertadores'), cdb: gIn(j=>j.competicao==='Copa do Brasil'), sula: gIn(j=>['Sul-Americana','CONMEBOL'].includes(j.competicao)),
    aprov: comEsc.length?r:null, temps: ys.length, periodo: de&&ate?(de===ate?String(de):`${de}–${ate}`):(p.periodo_aceito||''),
    best, bestG: best!=null?anos[best]:0, vtop, anos, ys, GK, anosCS: GK?GK.cs.reduce((m,j)=>{ m[j.temporada]=(m[j.temporada]||0)+1; return m; },{}):null};
}
function linhasCmp(A,B){
  const n=v=>v==null?'–':typeof v==='number'?N(v):v;
  const rows=[
    ['Período', A.periodo, B.periodo, null],
    ['Posição', posTxt(A.nome)||null, posTxt(B.nome)||null, null],
    ['Gols', A.gols, B.gols, 'max'],
    ['Jogos', A.jogos, B.jogos, 'max', '*'],
    ['Gols por jogo', A.media, B.media, 'max', '*', v=>v.toFixed(2).replace('.',',')],
    ['Temporadas com jogo ou gol', A.temps, B.temps, 'max'],
    ['Melhor temporada', A.best!=null?`${A.bestG} gols (${A.best})`:null, B.best!=null?`${B.bestG} gols (${B.best})`:null, 'max', '', null, [A.bestG,B.bestG]],
    ['Jogos com 2 gols ou mais', A.dois, B.dois, 'max'],
    ['Hat-tricks (3 ou mais)', A.hat, B.hat, 'max'],
    ['Mais gols num jogo', A.max, B.max, 'max'],
    ['Gols de pênalti', A.pen, B.pen, 'max', '*'],
    ['Gols no Brasileiro', A.bra, B.bra, 'max'],
    ['Gols no Mineiro', A.min, B.min, 'max'],
    ['Gols na Libertadores', A.lib, B.lib, 'max'],
    ['Gols na Copa do Brasil', A.cdb, B.cdb, 'max'],
    ['Gols na Sul-Americana e Conmebol', A.sula, B.sula, 'max'],
    ['Gols contra o Cruzeiro', A.cz, B.cz, 'max'],
    ['Gols contra o América', A.am, B.am, 'max'],
    ['Vítima preferida', A.vtop?`${A.vtop[0]} (${A.vtop[1]})`:null, B.vtop?`${B.vtop[0]} (${B.vtop[1]})`:null, null],
    ['Aproveitamento do time com ele', A.aprov?aprov(A.aprov):null, B.aprov?aprov(B.aprov):null, 'max', '*', null, [A.aprov?pct(A.aprov):null, B.aprov?pct(B.aprov):null]],
  ];
  if(A.GK||B.GK) rows.splice(2,0,
    ['Jogos sem sofrer gols', A.GK?A.GK.cs.length:null, B.GK?B.GK.cs.length:null, 'max', '*'],
    ['% de jogos sem sofrer gols', A.GK?Math.round(100*A.GK.cs.length/A.GK.gj.length)+'%':null, B.GK?Math.round(100*B.GK.cs.length/B.GK.gj.length)+'%':null, 'max', '*', null, [A.GK?A.GK.cs.length/A.GK.gj.length:null, B.GK?B.GK.cs.length/B.GK.gj.length:null]],
    ['Gols sofridos por jogo', A.GK?A.GK.sofr/Math.max(1,A.GK.tit):null, B.GK?B.GK.sofr/Math.max(1,B.GK.tit):null, 'min', '*', v=>v.toFixed(2).replace('.',',')],
    ['Pênaltis defendidos no jogo', A.GK?penResumo(A.nome).jogo:null, B.GK?penResumo(B.nome).jogo:null, 'max', '*'],
    ['Pênaltis defendidos em disputas', A.GK?penResumo(A.nome).disputa:null, B.GK?penResumo(B.nome).disputa:null, 'max', '*']);
  return rows.map(([l,a,b,best,ast,fmt,cmp])=>{ const ca=cmp?cmp[0]:a, cb=cmp?cmp[1]:b; let w=0;
    if(best && typeof ca==='number' && typeof cb==='number' && ca!==cb) w = (best==='max'? ca>cb : ca<cb) ? 1 : 2;
    const f=v=>v==null?'–':fmt&&typeof v==='number'?fmt(v):n(v);
    return {l:l+(ast||''), a:f(a), b:f(b), w}; });
}
const pct = r => { const t=r.V+r.E+r.D; return t?(3*r.V+r.E)/(3*t):0; };
function vComparar(params){
  const P=new URLSearchParams(params||'');
  const top=D.jogadores.slice().sort((a,b)=>golsBest(b)-golsBest(a));
  const a=P.get('a')||top[0].nome, b=P.get('b')||top[1].nome;
  const A=statsJog(a), B=statsJog(b);
  setTimeout(()=>{ const go=()=>{ const x=$('#ca').value, y=$('#cb').value; if(D.jogadores.some(p=>p.nome===x)&&D.jogadores.some(p=>p.nome===y)) location.hash='comparar?'+new URLSearchParams({a:x,b:y}); };
    ['#ca','#cb'].forEach(s=>{ const el=$(s); if(el) el.onchange=go; }); });
  const dl=`<datalist id="cjall">${top.map(p=>`<option value="${esc(p.nome)}">`).join('')}</datalist>`;
  const pick=`<div class="filters cmp-pick"><label>Jogador 1<input id="ca" list="cjall" value="${esc(a)}"></label><label>Jogador 2<input id="cb" list="cjall" value="${esc(b)}"></label>${dl}</div>`;
  if(!A||!B) return `<a class="back" href="#jogadores">← Jogadores</a><div class="kicker">Jogadores</div><h1>Comparativo</h1>${pick}<p class="empty">Escolha dois jogadores da lista.</p>`;
  const zero=v=>/^(0([,.]00)?( gols.*)?|–)$/.test(String(v)), GG=A.GK&&B.GK;
  const rows=linhasCmp(A,B).filter(r=>!(GG&&zero(r.a)&&zero(r.b))), wa=rows.filter(r=>r.w===1).length, wb=rows.filter(r=>r.w===2).length;
  // gráfico: gols acumulados por ano de clube
  const serie=S=>{ let s=0; const src=GG?S.anosCS:S.anos; return S.ys.length?Array.from({length:S.ys[S.ys.length-1]-S.ys[0]+1},(_,i)=>{ s+=src[S.ys[0]+i]||0; return s; }):[]; };
  const sa=serie(A), sb=serie(B), n=Math.max(sa.length,sb.length,2), mx=Math.max(1,...sa,...sb), W=640,H=220,pl=40,pb=26;
  const pts=s=>s.map((v,i)=>`${(pl+(W-pl-10)*i/(n-1)).toFixed(1)},${(H-pb-(H-pb-10)*v/mx).toFixed(1)}`).join(' ');
  const svg=`<svg viewBox="0 0 ${W} ${H}" class="cmpchart" role="img" aria-label="Gols acumulados por ano de clube">
    ${[0,.5,1].map(f=>`<line x1="${pl}" x2="${W-10}" y1="${H-pb-(H-pb-10)*f}" y2="${H-pb-(H-pb-10)*f}" class="gl"/><text x="${pl-6}" y="${H-pb-(H-pb-10)*f+4}" text-anchor="end">${Math.round(mx*f)}</text>`).join('')}
    <text x="${pl}" y="${H-6}">1º ano</text><text x="${W-10}" y="${H-6}" text-anchor="end">${n}º ano</text>
    <polyline points="${pts(sb)}" class="lb"/><polyline points="${pts(sa)}" class="la"/></svg>`;
  return `<a class="back" href="#jogadores">← Jogadores</a><div class="kicker">Jogadores</div><h1>Comparativo</h1>${pick}
  <div class="cmp-head"><div><a href="#jogador-${slug(A.nome)}">${esc(nomeV(A.nome))}</a><small>${esc(A.periodo)}</small></div><div class="cmp-x">×</div><div class="r"><a href="#jogador-${slug(B.nome)}">${esc(nomeV(B.nome))}</a><small>${esc(B.periodo)}</small></div></div>
  <table class="cmp"><tbody>${rows.map(r=>`<tr><td class="ca${r.w===1?' win':''}">${esc(String(r.a))}</td><td class="cl">${esc(r.l)}</td><td class="cb${r.w===2?' win':''}">${esc(String(r.b))}</td></tr>`).join('')}
  <tr class="tot"><td class="ca">${wa}</td><td class="cl">Quesitos vencidos</td><td class="cb">${wb}</td></tr></tbody></table>
  <p class="count">Gols pelo número aceito, quando existe; os demais pela base, que cobre toda a história. *Jogos, pênaltis, aproveitamento e números de goleiro só contam a partir de ${fmtD(D.meta.escalacoes_desde)}, quando as escalações entram na base. Comparações entre épocas diferentes devem levar isso em conta.</p>
  <h2>${GG?'Jogos sem sofrer gols acumulados':'Gols acumulados'} por ano de clube</h2>${svg}
  <div class="legend"><span><i style="background:var(--ink)"></i>${esc(nomeV(A.nome))}</span><span><i style="background:var(--cmpb)"></i>${esc(nomeV(B.nome))}</span></div>
  <p class="count" style="margin-top:18px"><a href="#comparar?${new URLSearchParams({a:B.nome,b:A.nome})}">Inverter lados</a></p>`;
}

/* ---------- Cards para posts ---------- */
const CARD = {tipo:'confronto', fmt:'feed', tema:'dark', adv:'', jog:'', ja:'', jb:'', temp:'', id:'', dia:'', k:'', n:'', t:'', s:'', selo:'EM BREVE'};
const nomeV = n => String(n).replace(/\s*\(\d{4}(?:[–-]\d{2,4})?\)$/,'');
const MESES = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
const COLR = {V:'#1f9d55', E:'#e8b923', D:'#d33b3b'};
const RESTXT = {V:'VITÓRIA', E:'EMPATE', D:'DERROTA'};
const IMGC = {};
const loadImg = src => !src ? Promise.resolve(null) : (IMGC[src] ||= new Promise(r=>{ const i=new Image(); i.onload=()=>r(i); i.onerror=()=>r(null); i.src=src; }));
const escSrc = id => id==='galo' ? ESC.__galo : ESC[id];

function cvFont(ctx, w, size, kind='cond'){
  ctx.font = kind==='mono' ? `${w} ${size}px "IBM Plex Mono", monospace` : `${kind==='cond'?'condensed ':''}${w} ${size}px Archivo, sans-serif`;
  ctx.fontStretch = kind==='cond' ? 'condensed' : 'normal';
}
function cvFit(ctx, txt, w, size, maxW, kind='cond', min=20){ let s=size; cvFont(ctx,w,s,kind); while(s>min && ctx.measureText(txt).width>maxW){ s-=2; cvFont(ctx,w,s,kind); } return s; }
function cvText(ctx, txt, x, y, o={}){
  cvFont(ctx, o.w||700, o.size||30, o.kind||'cond'); ctx.fillStyle=o.color; ctx.textAlign=o.align||'left'; ctx.textBaseline=o.base||'alphabetic';
  ctx.letterSpacing = (o.ls||0)+'px'; ctx.fillText(txt, x, y); ctx.letterSpacing='0px';
  return ctx.measureText(txt).width;
}
function cvWrap(ctx, txt, x, y, maxW, lh, o){ cvFont(ctx,o.w||400,o.size||30,o.kind||'normal'); const words=String(txt).split(/\s+/); let line='', yy=y;
  for(const w of words){ const t=line?line+' '+w:w; if(ctx.measureText(t).width>maxW && line){ cvText(ctx,line,x,yy,o); line=w; yy+=lh; } else line=t; }
  if(line){ cvText(ctx,line,x,yy,o); yy+=lh; } return yy; }
function cvImg(ctx, img, x, y, w, h){ if(!img) return; const r=Math.min(w/img.width, h/img.height), iw=img.width*r, ih=img.height*r; ctx.drawImage(img, x+(w-iw)/2, y+(h-ih)/2, iw, ih); }
function cvBar(ctx, r, x, y, w, h, T){
  const n=r.V+r.E+r.D||1; let xx=x;
  ['V','E','D'].forEach(k=>{ const ww=w*r[k]/n; ctx.fillStyle=COLR[k]; ctx.fillRect(xx,y,ww,h);
    if(ww>90) cvText(ctx, Math.round(100*r[k]/n)+'%', xx+14, y+h/2+1, {size:24,w:600,kind:'mono',color:k==='E'?'#1a1a1a':'#fff',base:'middle'}); xx+=ww; });
}
function cvBox(ctx, k, x, y, s){ ctx.fillStyle=COLR[k]||'#777'; ctx.fillRect(x,y,s,s); cvText(ctx, k||'·', x+s/2, y+s/2+2, {size:s*.55,w:600,kind:'mono',color:k==='E'?'#1a1a1a':'#fff',align:'center',base:'middle'}); }
function cvRule(ctx, x, y, w, T, h=4){ ctx.fillStyle=T.ink; ctx.fillRect(x,y,w,h); }

const cardDados = {
  confronto(){
    const a=advRows().find(x=>x.id===CARD.adv) || advRows().slice().sort((x,y)=>y.jogos.length-x.jogos.length)[0]; CARD.adv=a.id;
    const H=ACC.h2h[a.id]; let r=rec(a.jogos);
    if(H){ const pos=rec(a.jogos.filter(j=>j.data>H.ate)); r={n:H.jogos+pos.n, V:H.V+pos.V, E:H.E+pos.E, D:H.D+pos.D, gp:r.gp, gc:r.gc}; }
    else r.n=r.V+r.E+r.D;
    const sc={}; a.jogos.forEach(j=>j.gols.forEach(g=>{ if(isGoal(g)) sc[g.jogador]=(sc[g.jogador]||0)+1; }));
    const VS=ACC.vs[a.id]||{}; const art=Object.entries(sc).map(([n,g])=>{ const x=accG(VS[n],n,a.id); return [n, x?x.atual:g]; });
    Object.keys(VS).forEach(n=>{ if(!sc[n]) art.push([n, accG(VS[n],n,a.id).atual]); });
    art.sort((x,y)=>y[1]-x[1]);
    const played=a.jogos.filter(j=>j.resultado&&j.gp!=null);
    const best=[...played].sort((x,y)=>(y.gp-y.gc)-(x.gp-x.gc)||y.gp-x.gp)[0];
    return {a, r, art:art.slice(0,5), best, prim:a.jogos[0]};
  },
  jogador(){
    const p=D.jogadores.find(x=>x.nome===CARD.jog) || D.jogadores.slice().sort((x,y)=>golsBest(y)-golsBest(x))[0]; CARD.jog=p.nome;
    const list=J.filter(j=>jogouOuMarcou(j,p.nome));
    const gpj=j=>j.gols.filter(g=>isGoal(g)&&g.jogador===p.nome).length;
    const ag=accG(ACC.p[p.nome]?.gols,p.nome), aj=ACC.p[p.nome]?.jogos;
    const jogos = aj ? aj.v+(aj.dataAte?jogosApos(p.nome,aj.dataAte):0) : (p.jogos||null);
    const gols = ag ? ag.atual : p.gols;
    const anos={}; list.forEach(j=>{ anos[j.temporada]=(anos[j.temporada]||0)+gpj(j); });
    const vit={}; list.forEach(j=>{ const g=gpj(j); if(g){ const v=(vit[j.adversario_id] ||= {n:j.adversario,id:j.adversario_id,g:0}); v.g+=g; } });
    const ys=list.map(j=>j.temporada); const per = p.periodo_aceito || (ys.length?(Math.min(...ys)===Math.max(...ys)?Math.min(...ys):Math.min(...ys)+'–'+Math.max(...ys)):'');
    const marc=list.filter(gpj), maxg=marc.length?Math.max(...marc.map(gpj)):0, recd=marc.find(j=>gpj(j)===maxg);
    return {p, gols, jogos, anos, vit:Object.values(vit).sort((a,b)=>b.g-a.g).slice(0,3), per, maxg, recd, hat:marc.filter(j=>gpj(j)>=3).length};
  },
  jogo(){ const j=byId[CARD.id] || [...J].reverse().find(x=>x.resultado); CARD.id=j.id; CARD.temp=String(j.temporada); return {j}; },
  dia(){ if(!CARD.dia){ const d=new Date(); CARD.dia=`${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
    const l=J.filter(j=>!j.data_aprox && j.data.slice(5)===CARD.dia); return {l, r:rec(l)}; },
  comparar(){ const top=D.jogadores.slice().sort((x,y)=>golsBest(y)-golsBest(x)); const A=statsJog(CARD.ja)||statsJog(top[0].nome), B=statsJog(CARD.jb)||statsJog(top[1].nome); CARD.ja=A.nome; CARD.jb=B.nome;
    const ord=['Período','Gols','Jogos sem sofrer gols*','% de jogos sem sofrer gols*','Gols sofridos por jogo*','Pênaltis defendidos no jogo*','Pênaltis defendidos em disputas*','Jogos*','Gols por jogo*','Melhor temporada','Gols contra o Cruzeiro','Hat-tricks (3 ou mais)','Gols no Brasileiro','Gols no Mineiro','Gols na Libertadores','Gols na Copa do Brasil','Mais gols num jogo','Aproveitamento do time com ele*'];
    const all=linhasCmp(A,B).filter(r=>!(r.a==='–'&&r.b==='–')&&!(r.a==='0'&&r.b==='0'));
    return {A,B,rows:ord.map(l=>all.find(r=>r.l===l)).filter(Boolean)}; },
  livre(){ return {}; }
};

async function desenhaCard(){
  const W=1080, H=CARD.fmt==='story'?1920:1350, P=80;
  const cv=document.createElement('canvas'); cv.width=W; cv.height=H; const ctx=cv.getContext('2d');
  const T = CARD.tema==='dark' ? {bg:'#121212',ink:'#ecebe6',mute:'#8f8c85',line:'#2e2d2a',soft:'#1d1d1b'} : {bg:'#f6f5f1',ink:'#0b0b0b',mute:'#6d6b66',line:'#d9d7d0',soft:'#ecebe6'};
  await Promise.all(['condensed 900 80px Archivo','condensed 700 80px Archivo','400 80px Archivo','600 40px "IBM Plex Mono"'].map(f=>document.fonts.load(f).catch(()=>{})));
  ctx.fillStyle=T.bg; ctx.fillRect(0,0,W,H);
  const shadow = CARD.tema==='dark' ? ()=>{ ctx.shadowColor='rgba(255,255,255,.45)'; ctx.shadowBlur=3; } : ()=>{};
  const noShadow = ()=>{ ctx.shadowColor='transparent'; ctx.shadowBlur=0; };
  const crest = async (id,x,y,w,h)=>{ const im=await loadImg(escSrc(id)); shadow(); cvImg(ctx,im,x,y,w,h); noShadow(); };
  let y = CARD.fmt==='story' ? 230 : P;
  const kicker = t => { cvText(ctx, t.toUpperCase(), P, y+26, {size:28,w:600,kind:'mono',color:T.mute,ls:3}); y+=60; };
  const tipo=CARD.tipo, d=cardDados[tipo]();

  if(tipo==='confronto'){
    const {a,r,art,best}=d;
    kicker('Retrospecto histórico');
    await crest('galo', P, y, 160, 160); cvText(ctx,'×',P+215,y+102,{size:60,w:400,kind:'mono',color:T.mute,align:'center'}); await crest(a.id, P+265, y+24, 112, 112);
    y+=200;
    let s=cvFit(ctx,`ATLÉTICO × ${a.nome.toUpperCase()}`,900,118,W-2*P);
    cvText(ctx,`ATLÉTICO × ${a.nome.toUpperCase()}`,P,y+s*.8,{size:s,w:900,color:T.ink}); y+=s*.8+50;
    cvRule(ctx,P,y,W-2*P,T); y+=20;
    const cols=[['JOGOS',r.n,T.ink],['VITÓRIAS',r.V,COLR.V],['EMPATES',r.E,COLR.E],['DERROTAS',r.D,COLR.D]], cw=(W-2*P)/4;
    cols.forEach(([l,v,c],i)=>{ const s=cvFit(ctx,N(v),900,132,cw-24); cvText(ctx,N(v),P+i*cw,y+125,{size:s,w:900,color:c}); cvText(ctx,l,P+i*cw,y+170,{size:24,w:600,kind:'mono',color:T.mute,ls:2}); });
    y+=200; cvBar(ctx,r,P,y,W-2*P,46,T); y+=80;
    const cw2=(W-2*P)/4;
    [[aprov(r),'APROVEITAMENTO'],[N(r.gp),'GOLS PRÓ'],[N(r.gc),'GOLS CONTRA']].forEach(([v,l],i)=>{ const x=P+(i?cw2*(i+1):0); cvText(ctx,v,x,y+80,{size:88,w:900,color:T.ink}); cvText(ctx,l,x,y+120,{size:24,w:600,kind:'mono',color:T.mute,ls:2}); });
    y+=160;
    if(art.length){ cvRule(ctx,P,y,W-2*P,T,2); y+=56; cvText(ctx,'ARTILHEIROS DO GALO NO CONFRONTO',P,y,{size:26,w:600,kind:'mono',color:T.mute,ls:2}); y+=26;
      const lim = Math.max(1,Math.floor((H-(CARD.fmt==='story'?230:150)-40-y)/62)), lim2=Math.min(5,lim);
      art.slice(0,lim2).forEach(([n,g],i)=>{ y+=62; n=nomeV(n); cvText(ctx,n,P,y,{size:46,w:700,color:T.ink}); cvText(ctx,String(g),W-P,y,{size:46,w:900,color:T.ink,align:'right'}); });
      y+=30; }
    if(best && best.resultado==='V' && CARD.fmt==='story' && y+140 < H-240){ y+=50; cvText(ctx,'MAIOR VITÓRIA',P,y,{size:26,w:600,kind:'mono',color:T.mute,ls:2}); y+=72;
      cvText(ctx,`${best.gp} x ${best.gc}`,P,y,{size:76,w:900,color:COLR.V}); cvText(ctx,fmtD(best.data,best.data_aprox),P+260,y,{size:34,w:600,kind:'mono',color:T.mute}); }
  }

  if(tipo==='jogador'){
    const {p,gols,jogos,anos,vit,per,maxg,recd,hat}=d;
    kicker(`Jogador${per?' · '+per:''}`);
    const NM=nomeV(p.nome).toUpperCase(); let s=cvFit(ctx,NM,900,190,W-2*P);
    cvText(ctx,NM,P,y+s*.78,{size:s,w:900,color:T.ink}); y+=s*.78+48;
    cvRule(ctx,P,y,W-2*P,T); y+=20;
    const cols=[['GOLS',gols]]; if(jogos) cols.push(['JOGOS',jogos], ['GOLS POR JOGO',(gols/jogos).toFixed(2).replace('.',',')]); else if(hat) cols.push(['HAT-TRICKS',hat]);
    const cw=(W-2*P)/3;
    cols.forEach(([l,v],i)=>{ const tv=typeof v==='number'?N(v):v, s=cvFit(ctx,tv,900,150,cw-24); cvText(ctx,tv,P+i*cw,y+140,{size:s,w:900,color:i===0?COLR.V:T.ink}); cvText(ctx,l,P+i*cw,y+186,{size:24,w:600,kind:'mono',color:T.mute,ls:2}); });
    y+=240;
    const ys=Object.keys(anos).sort();
    if(ys.length>1){ cvText(ctx,'GOLS POR TEMPORADA',P,y,{size:26,w:600,kind:'mono',color:T.mute,ls:2}); y+=30;
      const ch=CARD.fmt==='story'?380:250, mx=Math.max(1,...ys.map(k=>anos[k])), gap=6, bw=Math.min(70,((W-2*P)-gap*(ys.length-1))/ys.length);
      ys.forEach((k,i)=>{ const h=Math.max(anos[k]?6:2, ch*anos[k]/mx), x=P+i*(bw+gap); ctx.fillStyle=anos[k]===mx?COLR.V:T.ink; ctx.fillRect(x,y+ch-h,bw,h);
        if(bw>=34 && anos[k]) cvText(ctx,String(anos[k]),x+bw/2,y+ch-h-10,{size:Math.min(26,bw*.6),w:600,kind:'mono',color:T.mute,align:'center'}); });
      cvRule(ctx,P,y+ch,W-2*P,T,2);
      cvText(ctx,ys[0],P,y+ch+40,{size:24,w:600,kind:'mono',color:T.mute}); cvText(ctx,ys[ys.length-1],P+(ys.length-1)*(bw+gap)+bw,y+ch+40,{size:24,w:600,kind:'mono',color:T.mute,align:'right'});
      y+=ch+80; }
    if(vit.length){ cvText(ctx,'VÍTIMAS PREFERIDAS',P,y,{size:26,w:600,kind:'mono',color:T.mute,ls:2}); y+=20;
      for(const v of vit){ y+=70; await crest(v.id,P,y-46,52,52); cvText(ctx,v.n,P+72,y,{size:44,w:700,color:T.ink}); cvText(ctx,v.g+' gols',W-P,y,{size:40,w:600,kind:'mono',color:T.ink,align:'right'}); }
      y+=20; }
    if(recd && maxg>1 && CARD.fmt==='story'){ y+=40; cvText(ctx,`Recorde: ${maxg} gols num jogo, contra ${recd.adversario} (${fmtD(recd.data,recd.data_aprox)})`,P,y,{size:32,w:400,kind:'normal',color:T.mute}); }
  }

  if(tipo==='jogo'){
    const {j}=d, galoLeft = j.tem_ficha && j.galo_mandante!=null ? j.galo_mandante : j.mando!=='F';
    kicker(`${j.competicao||''}${j.fase?' · '+j.fase:''}`);
    const dt=j.data_aprox?fmtD(j.data,1):`${+j.data.slice(8)} de ${MESES[+j.data.slice(5,7)-1]} de ${j.data.slice(0,4)}`;
    cvText(ctx,dt,P,y+40,{size:46,w:700,color:T.ink}); y+=110;
    const L=galoLeft?'galo':j.adversario_id, R=galoLeft?j.adversario_id:'galo', sz=s=>s==='galo'?260:200;
    await crest(L, P+(300-sz(L))/2, y+(260-sz(L))/2, sz(L), sz(L)); await crest(R, W-P-300+(300-sz(R))/2, y+(260-sz(R))/2, sz(R), sz(R));
    const sc=j.gp==null?'×':(galoLeft?`${j.gp}–${j.gc}`:`${j.gc}–${j.gp}`);
    cvText(ctx,sc,W/2,y+190,{size:190,w:900,color:T.ink,align:'center'}); y+=300;
    const nm=(s)=>s==='galo'?'ATLÉTICO':j.adversario.toUpperCase();
    let s1=cvFit(ctx,nm(L),900,56,380), s2=cvFit(ctx,nm(R),900,56,380);
    cvText(ctx,nm(L),P+150,y,{size:s1,w:900,color:T.ink,align:'center'}); cvText(ctx,nm(R),W-P-150,y,{size:s2,w:900,color:T.ink,align:'center'}); y+=60;
    if(j.resultado){ const t=RESTXT[j.resultado]; cvFont(ctx,900,40); const tw=ctx.measureText(t).width+60; ctx.fillStyle=COLR[j.resultado]; ctx.fillRect(W/2-tw/2,y,tw,64);
      cvText(ctx,t,W/2,y+34,{size:40,w:900,color:j.resultado==='E'?'#1a1a1a':'#fff',align:'center',base:'middle',ls:2}); }
    y+=120; cvRule(ctx,P,y,W-2*P,T,2); y+=60;
    const gg={}; j.gols.filter(g=>g.lado==='galo').forEach(g=>{ const k=nomeV(g.jogador)+((g.tipo||'').includes('contra')?' (contra)':''); (gg[k] ||= []).push(g.minuto); });
    const ent=Object.entries(gg);
    if(ent.length){ cvText(ctx,'GOLS DO GALO',P,y,{size:26,w:600,kind:'mono',color:T.mute,ls:2});
      ent.slice(0,6).forEach(([n,m])=>{ y+=64; cvText(ctx,n,P,y,{size:44,w:700,color:T.ink}); const mm=m.filter(x=>x!=null); cvText(ctx,mm.length?mm.map(x=>x+"'").join('  '):(m.length>1?m.length+' gols':''),W-P,y,{size:34,w:600,kind:'mono',color:T.mute,align:'right'}); });
      y+=50; }
    const info=[j.estadio, j.publico?N(j.publico)+' '+(j.publico_tipo||'pessoas'):null].filter(Boolean).join(' · ');
    if(info) cvWrap(ctx,info,P,y+20,W-2*P,44,{size:32,w:400,kind:'normal',color:T.mute});
  }

  if(tipo==='dia'){
    const {l,r}=d, [m,dd]=CARD.dia.split('-');
    kicker('Neste dia na história');
    cvText(ctx,`${+dd} DE ${MESES[+m-1].toUpperCase()}`,P,y+130,{size:cvFit(ctx,`${+dd} DE ${MESES[+m-1].toUpperCase()}`,900,160,W-2*P),w:900,color:T.ink}); y+=230;
    cvText(ctx,`${l.length} jogos do Galo nesta data · ${r.V}V ${r.E}E ${r.D}D`,P,y,{size:32,w:600,kind:'mono',color:T.mute}); y+=40;
    cvRule(ctx,P,y,W-2*P,T); y+=10;
    const fy0=H-(CARD.fmt==='story'?230:150)-30; let lim=Math.floor((fy0-y)/82); if(l.length>lim) lim=Math.floor((fy0-y-60)/82);
    const pick = l.length<=lim ? l : [...l].sort((a,b)=>Math.abs(b.gp-b.gc)-Math.abs(a.gp-a.gc)).slice(0,lim).sort((a,b)=>a.data<b.data?-1:1);
    for(const j of pick){ y+=82; cvText(ctx,j.data.slice(0,4),P,y,{size:34,w:600,kind:'mono',color:T.mute}); cvBox(ctx,j.resultado,P+120,y-38,48);
      const t=`Atlético ${j.gp??''} x ${j.gc??''} ${j.adversario}`; const s=cvFit(ctx,t,700,44,W-2*P-270);
      cvText(ctx,t,P+196,y,{size:s,w:700,color:T.ink}); const tw=ctx.measureText(t).width; await crest(j.adversario_id,P+196+tw+16,y-40,48,48);
      ctx.fillStyle=T.line; ctx.fillRect(P,y+26,W-2*P,1); }
    if(l.length>pick.length){ y+=72; cvText(ctx,`e mais ${l.length-pick.length} jogos`,P,y,{size:30,w:400,kind:'normal',color:T.mute}); }
  }

  if(tipo==='comparar'){
    const {A,B,rows}=d; kicker('Comparativo');
    const na=nomeV(A.nome).toUpperCase(), nb=nomeV(B.nome).toUpperCase();
    let s=Math.min(cvFit(ctx,na,900,120,W-2*P), cvFit(ctx,nb,900,120,W-2*P));
    cvText(ctx,na,P,y+s*.8,{size:s,w:900,color:T.ink}); y+=s*.8+14;
    cvText(ctx,'×',W/2,y+40,{size:44,w:400,kind:'mono',color:T.mute,align:'center'}); y+=56;
    cvText(ctx,nb,W-P,y+s*.8,{size:s,w:900,color:T.ink,align:'right'}); y+=s*.8+40;
    cvRule(ctx,P,y,W-2*P,T); y+=8;
    const fy0=H-(CARD.fmt==='story'?230:150)-30, rh=CARD.fmt==='story'?92:76, lim=Math.floor((fy0-y)/rh);
    rows.slice(0,lim).forEach(r=>{ y+=rh;
      const va=r.a.length>14?r.a.replace(/ gols \((\d+)\)/,' ($1)'):r.a, vb=r.b.length>14?r.b.replace(/ gols \((\d+)\)/,' ($1)'):r.b;
      const sz=t=>cvFit(ctx,t,900,52,300);
      cvText(ctx,va,P,y-12,{size:sz(va),w:900,color:r.w===1?COLR.V:T.ink});
      cvText(ctx,vb,W-P,y-12,{size:sz(vb),w:900,color:r.w===2?COLR.V:T.ink,align:'right'});
      cvText(ctx,r.l.replace('*','').toUpperCase(),W/2,y-22,{size:cvFit(ctx,r.l.replace('*','').toUpperCase(),600,22,330,'mono',14),w:600,kind:'mono',color:T.mute,align:'center'});
      ctx.fillStyle=T.line; ctx.fillRect(P,y+6,W-2*P,1); });
  }

  if(tipo==='livre'){
    y = CARD.fmt==='story'?420:170;
    if(CARD.k) kicker(CARD.k);
    if(CARD.n){ const s=cvFit(ctx,CARD.n,900,340,W-2*P); cvText(ctx,CARD.n,P,y+s*.78,{size:s,w:900,color:COLR.V}); y+=s*.78+40; }
    if(CARD.t){ cvFont(ctx,900,84); const words=CARD.t.toUpperCase().split(/\s+/); let line=''; for(const w of words){ const tt=line?line+' '+w:w; cvFont(ctx,900,84); if(ctx.measureText(tt).width>W-2*P && line){ y+=78; cvText(ctx,line,P,y,{size:84,w:900,color:T.ink}); line=w; } else line=tt; } if(line){ y+=78; cvText(ctx,line,P,y,{size:84,w:900,color:T.ink}); } y+=30; }
    if(CARD.s){ cvRule(ctx,P,y,120,T,6); y+=70; cvWrap(ctx,CARD.s,P,y,W-2*P,50,{size:38,w:400,kind:'normal',color:T.mute}); }
  }

  // rodapé
  const fy=H-(CARD.fmt==='story'?230:150);
  cvRule(ctx,P,fy,W-2*P,T,3);
  const logo=await loadImg(CARD.tema==='dark'?'escudos/logo-gm-branco.webp':'escudos/logo-gm-preto.webp');
  if(logo) cvImg(ctx,logo,P,fy+26,52,85);
  cvText(ctx,'GALO METRICS',P+72,fy+92,{size:58,w:900,color:T.ink});
  if(CARD.selo){ cvFont(ctx,700,28); ctx.letterSpacing='3px'; const sw=ctx.measureText(CARD.selo.toUpperCase()).width+44; ctx.letterSpacing='0px';
    ctx.fillStyle=T.ink; ctx.fillRect(W-P-sw,fy+40,sw,58); cvText(ctx,CARD.selo.toUpperCase(),W-P-sw/2,fy+70,{size:28,w:700,color:T.bg,align:'center',base:'middle',ls:3}); }
  return cv;
}

let cardTimer;
function cardCtrl(){
  const t=CARD.tipo, o=(v,l,sel)=>`<option value="${esc(v)}"${String(sel)===String(v)?' selected':''}>${esc(l)}</option>`;
  let h='';
  if(t==='confronto') h=`<label>Adversário<select data-k="adv">${advRows().slice().sort((a,b)=>b.jogos.length-a.jogos.length).map(a=>o(a.id,`${a.nome} ${a.uf||''} (${a.jogos.length})`,CARD.adv)).join('')}</select></label>`;
  if(t==='jogador') h=`<label>Jogador<input data-k="jog" list="cjl" value="${esc(CARD.jog)}" placeholder="nome…"><datalist id="cjl">${D.jogadores.slice().sort((a,b)=>golsBest(b)-golsBest(a)).map(p=>`<option value="${esc(p.nome)}">`).join('')}</datalist></label>`;
  if(t==='jogo'){ const temps=[...new Set(J.map(j=>j.temporada))].sort((a,b)=>b-a); const tp=CARD.temp||String(temps[0]);
    h=`<label>Temporada<select data-k="temp">${temps.map(y=>o(y,y,tp)).join('')}</select></label><label>Jogo<select data-k="id">${J.filter(j=>String(j.temporada)===tp).reverse().map(j=>o(j.id,`${fmtD(j.data,j.data_aprox)} · ${placar(j)} ${j.adversario}`,CARD.id)).join('')}</select></label>`; }
  if(t==='comparar'){ const dl=`<datalist id="cjl2">${D.jogadores.slice().sort((a,b)=>golsBest(b)-golsBest(a)).map(p=>`<option value="${esc(p.nome)}">`).join('')}</datalist>`;
    h=`<label>Jogador 1<input data-k="ja" list="cjl2" value="${esc(CARD.ja)}"></label><label>Jogador 2<input data-k="jb" list="cjl2" value="${esc(CARD.jb)}"></label>${dl}`; }
  if(t==='dia') h=`<label>Dia<input type="date" data-k="diaf" value="2024-${CARD.dia}"></label>`;
  if(t==='livre') h=`<label>Linha de cima<input data-k="k" value="${esc(CARD.k)}" placeholder="ex.: Você sabia?"></label><label>Número grande<input data-k="n" value="${esc(CARD.n)}" placeholder="ex.: 255"></label><label>Título<input data-k="t" value="${esc(CARD.t)}" placeholder="ex.: gols de Reinaldo"></label><label>Texto<input data-k="s" value="${esc(CARD.s)}" placeholder="frase de apoio"></label>`;
  return h;
}
function vCards(params){
  const P=new URLSearchParams(params||''); P.forEach((v,k)=>{ if(k in CARD) CARD[k]=v; });
  if(P.get('tipo')==='jogo' && P.get('id')) CARD.temp='';
  setTimeout(()=>{ cardsUI(); });
  return `<div class="kicker">Para as redes</div><h1>Cards</h1>
  <p class="count" style="margin-top:12px">Monte uma imagem com os números da base e baixe em PNG. O selo do rodapé é editável, para divulgar o site antes do lançamento.</p>
  <div class="cardwrap"><div class="cardctl">
    <label>Tipo<select id="ctipo">${[['confronto','Confronto'],['jogador','Jogador'],['comparar','Jogador × Jogador'],['jogo','Jogo'],['dia','Neste dia'],['livre','Texto livre']].map(([v,l])=>`<option value="${v}"${CARD.tipo===v?' selected':''}>${l}</option>`).join('')}</select></label>
    <div id="cextra"></div>
    <label>Formato<select id="cfmt"><option value="feed"${CARD.fmt==='feed'?' selected':''}>Feed 4:5 (1080×1350)</option><option value="story"${CARD.fmt==='story'?' selected':''}>Story 9:16 (1080×1920)</option></select></label>
    <label>Tema<select id="ctema"><option value="dark"${CARD.tema==='dark'?' selected':''}>Escuro</option><option value="light"${CARD.tema==='light'?' selected':''}>Claro</option></select></label>
    <label>Selo do rodapé<input id="cselo" value="${esc(CARD.selo)}" placeholder="vazio para tirar"></label>
    <button class="more" id="cbaixar" type="button">Baixar PNG</button>
    <p class="count" id="cmsg">Se o download não abrir, clique com o botão direito (ou toque e segure) na imagem para salvar.</p>
  </div><div class="cardprev"><img id="cimg" alt="Prévia do card"></div></div>`;
}
function cardsUI(){
  const ex=$('#cextra'); if(!ex) return;
  cardDados[CARD.tipo]();
  ex.innerHTML=cardCtrl();
  const redraw=()=>{ clearTimeout(cardTimer); cardTimer=setTimeout(async()=>{ const cv=await desenhaCard(); const im=$('#cimg'); if(im){ im.src=cv.toDataURL('image/png'); im.dataset.nome=`galo-metrics-${CARD.tipo}.png`; } },120); };
  ex.querySelectorAll('[data-k]').forEach(el=>{ const ev=el.tagName==='SELECT'?'change':'input'; el[ 'on'+ev ]=()=>{ const k=el.dataset.k;
    if(k==='diaf'){ CARD.dia=el.value.slice(5); }
    else if(k==='jog'||k==='ja'||k==='jb'){ if(!D.jogadores.some(p=>p.nome===el.value)) return; CARD[k]=el.value; }
    else { CARD[k]=el.value; if(k==='temp'){ CARD.id=String(J.filter(j=>String(j.temporada)===el.value).reverse()[0]?.id||''); cardsUI(); return; } }
    redraw(); }; });
  $('#ctipo').onchange=e=>{ CARD.tipo=e.target.value; cardsUI(); };
  $('#cfmt').onchange=e=>{ CARD.fmt=e.target.value; redraw(); };
  $('#ctema').onchange=e=>{ CARD.tema=e.target.value; redraw(); };
  $('#cselo').oninput=e=>{ CARD.selo=e.target.value; redraw(); };
  $('#cbaixar').onclick=async()=>{ const im=$('#cimg'); if(!im.src) return; const msg=$('#cmsg');
    const dl = window.claude && window.claude.use ? await window.claude.use('downloads').catch(()=>null) : null;
    const blob = await (await fetch(im.src)).blob();
    if(dl){ try{ await dl.save({filename:im.dataset.nome||'galo-metrics.png', data:blob}); if(msg) msg.textContent='Imagem salva.'; }
      catch(e){ if(msg) msg.textContent = e&&e.code==='declined' ? 'Download cancelado.' : e&&e.code==='rate_limited' ? 'Aguarde um instante e tente de novo.' : 'Não deu para baixar aqui. Clique com o botão direito (ou toque e segure) na imagem para salvar.'; } }
    else { const a=document.createElement('a'); a.href=im.src; a.download=im.dataset.nome||'galo-metrics.png'; document.body.appendChild(a); a.click(); a.remove(); } };
  redraw();
}

/* ---------- Competições e títulos ---------- */
// Títulos: Wikipédia, "Títulos do Clube Atlético Mineiro" (consultado em nov/2026). Só futebol profissional masculino.
const uniqC = arr => [...new Set(arr.filter(x=>x!=null&&x!==''))];
const cIs = (...cs) => j => cs.includes(j.competicao);
const COMPS = [
  {id:'libertadores', nome:'Copa Libertadores', nivel:'Internacionais', m:cIs('Libertadores'), t:[2013]},
  {id:'recopa', nome:'Recopa Sul-Americana', nivel:'Internacionais', m:cIs('Recopa Sul-Americana'), t:[2014]},
  {id:'conmebol', nome:'Copa Conmebol', nivel:'Internacionais', m:cIs('CONMEBOL'), t:[1992,1997]},
  {id:'sul-americana', nome:'Copa Sul-Americana', nivel:'Internacionais', m:cIs('Sul-Americana'), t:[]},
  {id:'mundial', nome:'Mundial de Clubes', nivel:'Internacionais', m:cIs('Intercontinental'), t:[]},
  {id:'mercosul', nome:'Copa Mercosul', nivel:'Internacionais', m:cIs('Mercosul'), t:[]},
  {id:'master', nome:'Copa Master Conmebol', nivel:'Internacionais', m:cIs('Copa Master CONMEBOL'), t:[]},
  {id:'ouro', nome:'Copa Ouro Conmebol', nivel:'Internacionais', m:cIs('Copa Ouro CONMEBOL'), t:[]},
  {id:'brasileiro', nome:'Campeonato Brasileiro', nivel:'Nacionais', m:j=>j.grupo==='Campeonato Brasileiro', t:[1937,1971,2021], nota:'Inclui o Torneio dos Campeões de 1937, a Taça Brasil, o Robertão e as edições do Brasileiro com outros nomes.'},
  {id:'copa-do-brasil', nome:'Copa do Brasil', nivel:'Nacionais', m:cIs('Copa do Brasil'), t:[2014,2021]},
  {id:'supercopa', nome:'Supercopa do Brasil', nivel:'Nacionais', m:cIs('Supercopa do Brasil'), t:[2022]},
  {id:'copa-dos-campeoes', nome:'Copa dos Campeões do Brasil', nivel:'Nacionais', m:j=>j.competicao==='Torneio dos Campeões'&&j.temporada===1978, t:[1978]},
  {id:'serie-b', nome:'Brasileiro Série B', nivel:'Nacionais', m:cIs('Brasileiro-Série B'), t:[2006]},
  {id:'sul-minas', nome:'Copa Sul-Minas e Sul-Minas-Rio', nivel:'Nacionais', m:cIs('Copa Sul-Minas','Copa Sul-Minas-Rio'), t:[]},
  {id:'copa-dos-campeoes-2002', nome:'Copa dos Campeões', nivel:'Nacionais', m:cIs('Copa dos Campeões'), t:[]},
  {id:'mineiro', nome:'Campeonato Mineiro', nivel:'Estaduais e municipais', m:j=>j.grupo==='Campeonato Mineiro', t:[1915,1926,1927,1931,1932,1936,1938,1939,1941,1942,1946,1947,1949,1950,1952,1953,1954,1955,1956,1958,1962,1963,1970,1976,1978,1979,1980,1981,1982,1983,1985,1986,1988,1989,1991,1995,1999,2000,2007,2010,2012,2013,2015,2017,2020,2021,2022,2023,2024,2025]},
  {id:'taca-minas', nome:'Taça Minas Gerais', nivel:'Estaduais e municipais', m:cIs('Taça Minas Gerais'), t:[1975,1976,1979,1986,1987], nota:'Parte das edições foi disputada como turno do Campeonato Mineiro e está registrada na base dentro do Mineiro.'},
  {id:'taca-bh', nome:'Taça Belo Horizonte', nivel:'Estaduais e municipais', m:cIs('Taça Belo Horizonte-MG'), t:[1970,1971,1972]},
  {id:'torneio-fmf', nome:'Torneio da FMF', nivel:'Estaduais e municipais', m:cIs('Torneio da FMF-MG'), t:[1974]},
  {id:'incentivo', nome:'Torneio Incentivo Mineiro', nivel:'Estaduais e municipais', m:()=>false, t:[1993]},
  {id:'bueno-brandao', nome:'Taça Bueno Brandão', nivel:'Estaduais e municipais', m:cIs('Taça Bueno Brandão-MG'), t:[1914]},
  {id:'copa-bh', nome:'Copa Belo Horizonte', nivel:'Estaduais e municipais', m:cIs('Copa Belo Horizonte-MG'), t:[1959]},
  {id:'supermineiro', nome:'Supermineiro', nivel:'Estaduais e municipais', m:cIs('Supermineiro'), t:[]},
  {id:'gigantes', nome:'Torneio dos Gigantes', nivel:'Torneios e taças', m:cIs('Torneio dos Gigantes'), t:[1969]},
  {id:'jose-guilherme', nome:'Torneio José Guilherme', nivel:'Torneios e taças', m:cIs('Torneio José Guilherme-MG'), t:[1970]},
  {id:'goiania', nome:'Torneio Cidade de Goiânia (Antônio Accioly)', nivel:'Torneios e taças', m:cIs('Torneio Antônio Accioly-GO'), t:[1970]},
  {id:'sjc', nome:'Torneio de São José dos Campos', nivel:'Torneios e taças', m:cIs('Torneio de São José dos Campos-SP'), t:[1970]},
  {id:'leon', nome:'Torneio de León', nivel:'Torneios e taças', m:cIs('Torneio de León-MEX'), t:[1972]},
  {id:'fenosa', nome:'Troféu Conde de Fenosa', nivel:'Torneios e taças', m:cIs('Torneio Conde de Fenosa-ESP'), t:[1976]},
  {id:'vigo', nome:'Torneio Cidade de Vigo', nivel:'Torneios e taças', m:cIs('Torneio de Vigo-ESP'), t:[1977]},
  {id:'aureliano', nome:'Torneio Governador Aureliano Chaves', nivel:'Torneios e taças', m:cIs('Torneio Aureliano Chaves-MG'), t:[1977]},
  {id:'costa-sol', nome:'Torneio da Costa do Sol', nivel:'Torneios e taças', m:cIs('Torneio Costa del Sol-ESP'), t:[1980]},
  {id:'paris', nome:'Torneio de Paris', nivel:'Torneios e taças', m:cIs('Torneio de Paris-FRA'), t:[1982]},
  {id:'bilbao', nome:'Torneio de Bilbao', nivel:'Torneios e taças', m:cIs('Torneio Villa de Bilbao-ESP'), t:[1982]},
  {id:'berna', nome:'Torneio de Berna', nivel:'Torneios e taças', m:cIs('Torneio Philips de Bern-SUI'), t:[1983]},
  {id:'amsterda', nome:'Torneio de Amsterdã', nivel:'Torneios e taças', m:cIs('Torneio de Amsterdam-NED'), t:[1984]},
  {id:'carranza', nome:'Troféu Ramón de Carranza', nivel:'Torneios e taças', m:cIs('Torneio Ramón de Carranza-ESP'), t:[1990]},
  {id:'tres-continentes', nome:'Torneio dos Três Continentes', nivel:'Torneios e taças', m:cIs('Torneio dos Três Continentes-VIE'), t:[1999]},
  {id:'florida', nome:'Florida Cup', nivel:'Torneios e taças', m:cIs('Torneio da Florida-USA'), t:[2016]},
  {id:'colatina', nome:'Torneio Quadrangular de Colatina', nivel:'Torneios e taças', m:cIs('Torneio de Colatina-ES'), t:[1953]},
  {id:'amistosos', nome:'Amistosos', nivel:'Outros', m:j=>j.grupo==='Amistoso', t:[]},
];
const NIVEIS = ['Internacionais','Nacionais','Estaduais e municipais','Torneios e taças','Outros'];
let COMP_INIT=false;
function compInit(){
  if(COMP_INIT) return; COMP_INIT=true;
  COMPS.forEach(c=>{ c.jogos=J.filter(c.m); });
  const usados=new Set(); COMPS.forEach(c=>c.jogos.forEach(j=>usados.add(j.id)));
  COMPS.push({id:'outros-torneios', nome:'Outros torneios', nivel:'Outros', m:j=>!usados.has(j.id), t:[], jogos:J.filter(j=>!usados.has(j.id)), sub:true});
}
const trof = (n, cls='') => n ? `<span class="trof ${cls}">★ ${n}</span>` : '';
function vCompeticoes(){
  compInit();
  const tot = COMPS.filter(c=>c.nivel!=='Torneios e taças').reduce((s,c)=>s+c.t.length,0), totT=COMPS.filter(c=>c.nivel==='Torneios e taças').reduce((s,c)=>s+c.t.length,0);
  const linha = c => { const r=rec(c.jogos), ys=uniqC(c.jogos.map(j=>j.temporada));
    return `<tr><td><a href="#competicao-${c.id}"><b>${esc(c.nome)}</b></a>${c.t.length?`<div class="tyears">${c.t.join(' · ')}</div>`:''}</td>
      <td class="n">${trof(c.t.length)}</td><td class="n">${N(c.jogos.length)}</td><td class="n hide-s">${ys.length||'–'}</td>
      <td class="n hide-s">${r.V}</td><td class="n hide-s">${r.E}</td><td class="n hide-s">${r.D}</td><td class="n">${aprov(r)}</td><td class="hide-s" style="width:150px">${r.n?resultBar(r).replace(/<div class="legen[\s\S]*$/,''):''}</td></tr>`; };
  return `<div class="kicker">Taças e campanhas</div><h1>Competições</h1>
  <div class="tiles"><div class="tile"><b>${tot}</b><span>Títulos oficiais</span></div><div class="tile"><b>${COMPS.find(c=>c.id==='mineiro').t.length}</b><span>Campeonatos Mineiros</span></div><div class="tile"><b>${['brasileiro','copa-do-brasil','supercopa','copa-dos-campeoes','serie-b'].reduce((s,id)=>s+COMPS.find(c=>c.id===id).t.length,0)}</b><span>Títulos nacionais</span></div><div class="tile"><b>${COMPS.filter(c=>c.nivel==='Internacionais').reduce((s,c)=>s+c.t.length,0)}</b><span>Títulos internacionais</span></div><div class="tile"><b>${totT}</b><span>Torneios e taças</span></div></div>
  <p class="count">Títulos do futebol profissional masculino, conforme a lista da Wikipédia "Títulos do Clube Atlético Mineiro". Taças de um jogo só e honrarias ficam de fora.</p>
  ${NIVEIS.map(nv=>{ const cs=COMPS.filter(c=>c.nivel===nv); return `<h2>${nv}</h2><table class="ctab"><thead><tr><th>Competição</th><th class="n">Títulos</th><th class="n">J</th><th class="n hide-s">Edições</th><th class="n hide-s">V</th><th class="n hide-s">E</th><th class="n hide-s">D</th><th class="n">Aprov.</th><th class="hide-s"></th></tr></thead><tbody>${cs.map(linha).join('')}</tbody></table>`; }).join('')}`;
}
function vCompeticao(id){
  compInit();
  const c=COMPS.find(x=>x.id===id); if(!c) return '<p class="empty">Competição não encontrada.</p>';
  const L=c.jogos, r=rec(L), T=new Set(c.t);
  const ed={}; L.forEach(j=>{ (ed[j.temporada] ||= []).push(j); });
  const anos=uniqC([...Object.keys(ed).map(Number), ...c.t]).sort((a,b)=>b-a);
  const comps=uniqC(L.map(j=>j.competicao)); const lk = o => linkJogos(comps.length===1?{comp:comps[0],...o}:(c.id==='brasileiro'||c.id==='mineiro'||c.id==='amistosos')?{grupo:L[0]?.grupo,...o}:o);
  const edRows = anos.map(y=>{ const l=ed[y]||[], rr=rec(l), last=l[l.length-1];
    return `<tr class="${T.has(y)?'campeao':''}"><td>${l.length?`<a href="${lk({temp:y})}">${y}</a>`:y}</td><td>${T.has(y)?'<span class="trof">★ Campeão</span>':''}</td><td class="n">${l.length||'–'}</td><td class="n hide-s">${l.length?rr.V:''}</td><td class="n hide-s">${l.length?rr.E:''}</td><td class="n hide-s">${l.length?rr.D:''}</td><td class="n hide-s">${l.length?rr.gp+'–'+rr.gc:''}</td><td class="n">${l.length?aprov(rr):''}</td><td class="hide-s">${last?`<a href="#jogo-${last.id}">${last.fase?esc(last.fase[0].toUpperCase()+last.fase.slice(1))+' · ':''}${esc(placar(last))} ${esc(last.adversario)}</a>`:'<span class="uf">sem jogos na base</span>'}</td></tr>`; }).join('');
  const sc={}; L.forEach(j=>j.gols.forEach(g=>{ if(isGoal(g)&&g.jogador!=='Não identificado') sc[g.jogador]=(sc[g.jogador]||0)+1; }));
  const art=Object.entries(sc).sort((a,b)=>b[1]-a[1]).slice(0,10);
  const vit=L.filter(j=>j.resultado==='V'&&j.gp!=null).sort((a,b)=>(b.gp-b.gc)-(a.gp-a.gc)||b.gp-a.gp).slice(0,5);
  const advs={}; L.forEach(j=>{ const a=(advs[j.adversario_id] ||= {id:j.adversario_id,n:j.adversario,uf:j.adversario_uf,l:[]}); a.l.push(j); });
  const topAdv=Object.values(advs).sort((a,b)=>b.l.length-a.l.length).slice(0,8);
  const sub = c.sub ? (()=>{ const g={}; L.forEach(j=>{ (g[j.competicao] ||= []).push(j); }); return `<h2>Torneios</h2><table><thead><tr><th>Torneio</th><th class="n">J</th><th class="n">V</th><th class="n">E</th><th class="n">D</th><th class="hide-s">Anos</th></tr></thead><tbody>${Object.entries(g).sort((a,b)=>b[1].length-a[1].length).map(([n,l])=>{ const rr=rec(l); return `<tr><td><a href="${linkJogos({comp:n})}">${esc(n)}</a></td><td class="n">${l.length}</td><td class="n">${rr.V}</td><td class="n">${rr.E}</td><td class="n">${rr.D}</td><td class="hide-s">${uniqC(l.map(j=>j.temporada)).join(', ')}</td></tr>`; }).join('')}</tbody></table>`; })() : '';
  return `<a class="back" href="#competicoes">← Competições</a><div class="kicker">${esc(c.nivel)}</div><h1>${esc(c.nome)}</h1>
  ${c.t.length?`<div class="trofs"><span class="trof big">★ ${c.t.length} ${c.t.length>1?'títulos':'título'}</span> ${c.t.join(' · ')}</div>`:''}
  <div class="tiles"><div class="tile"><b>${N(L.length)}</b><span>Jogos</span></div><div class="tile"><b>${uniqC(L.map(j=>j.temporada)).length}</b><span>Edições na base</span></div><div class="tile"><b style="color:var(--v)">${N(r.V)}</b><span>Vitórias</span></div><div class="tile"><b style="color:var(--e)">${N(r.E)}</b><span>Empates</span></div><div class="tile"><b style="color:var(--d)">${N(r.D)}</b><span>Derrotas</span></div><div class="tile"><b>${aprov(r)}</b><span>Aproveitamento</span></div><div class="tile"><b>${N(r.gp)}</b><span>Gols pró</span></div><div class="tile"><b>${N(r.gc)}</b><span>Gols contra</span></div></div>
  ${r.n?resultBar(r):''}
  ${c.nota?`<p class="count">${esc(c.nota)}</p>`:''}
  ${L.length?`<p class="count"><a href="${c.sub?'#jogos':lk({})}">Abrir no arquivo de jogos, com filtros →</a></p>`:''}
  ${sub}
  ${c.sub?'':`<h2>Edição por edição</h2><table class="edtab"><thead><tr><th>Ano</th><th></th><th class="n">J</th><th class="n hide-s">V</th><th class="n hide-s">E</th><th class="n hide-s">D</th><th class="n hide-s">Gols</th><th class="n">Aprov.</th><th class="hide-s">Último jogo</th></tr></thead><tbody>${edRows}</tbody></table>`}
  <div class="grid2">
   ${art.length?`<div><h2>Artilheiros</h2><table><tbody>${art.map(([n,g],i)=>`<tr><td class="n" style="width:28px">${i+1}</td><td>${D.jogadores.some(x=>x.nome===n)?`<a href="#jogador-${slug(n)}">${esc(n)}</a>`:esc(n)}</td><td class="n"><b>${g}</b></td></tr>`).join('')}</tbody></table><p class="count">Gols registrados na base.</p></div>`:''}
   ${topAdv.length?`<div><h2>Adversários mais frequentes</h2><table><tbody>${topAdv.map(a=>{ const rr=rec(a.l); return `<tr><td>${cr(a.id)}<a href="#adversario-${slug(a.id)}">${esc(a.n)}</a> <small class="uf">${esc(a.uf||'')}</small></td><td class="n">${a.l.length} j</td><td class="n">${rr.V}V ${rr.E}E ${rr.D}D</td></tr>`; }).join('')}</tbody></table></div>`:''}
  </div>
  ${vit.length?`<h2>Maiores vitórias</h2>${matchTable(vit)}`:''}`;
}

/* ---------- Álbum, pontos, conta e página do dono ---------- */
const GMK='gm-album-v1', GMA='gm-anim';
const lsGet=(k)=>{ try{ return localStorage.getItem(k); }catch(e){ return null; } };
const lsSet=(k,v)=>{ try{ localStorage.setItem(k,v); }catch(e){} };
const hojeStr=()=>{ const t=new Date(); return `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,'0')}-${String(t.getDate()).padStart(2,'0')}`; };
const CFG_PADRAO={ pontos:{pagina:1, jogadorNovo:3, diario:10, sugestao:15, pacote:25, tetoDiario:40}, chanceJogador:12, contato:'', manchete:'', mancheteLink:'', vocesabia:[], proximo:{}, raridade:{}, jogos:{} };
let CFG=JSON.parse(JSON.stringify(CFG_PADRAO));
let GDB=null, GUSER=null, GUID=null, DONO=false, NUVEM=false;
let G=null;
function gNovo(){ return {owned:{}, pts:0, total:0, hist:[], dia:'', paginasHoje:[], ptsHoje:0, gratis:true, sugHoje:0, jogVistos:{}, criado:hojeStr()}; }
function gLoad(){ gLoad0(); gExtra(); }
function gLoad0(){ try{ G=JSON.parse(lsGet(GMK)||'null'); }catch(e){ G=null; } if(!G||typeof G!=='object') G=gNovo(); for(const k in gNovo()) if(G[k]===undefined) G[k]=gNovo()[k]; }
let gSaveT=null;
function gSave(){ lsSet(GMK, JSON.stringify(G)); if(NUVEM&&GDB&&GUID){ clearTimeout(gSaveT); gSaveT=setTimeout(()=>{ GDB.doc('data/users/'+GUID+'/album').set({estado:JSON.stringify(G), em:Date.now()}).catch(()=>{ NUVEM=false; lsSet('gm-nuvem','0'); toast('Não deu para salvar na conta. O progresso continua salvo neste aparelho.'); }); }, 1200); } }
const animOn=()=>lsGet(GMA)!=='0' && !(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
function aplicaAnim(){ document.documentElement.classList.toggle('gm-anim', animOn()); }

/* figurinhas: todos os jogadores da base */
let FIG=null, FIGN={};
function figuras(){
  if(FIG) return FIG;
  const lend=new Set(['Ronaldinho Gaúcho','Hulk']);
  (D.aceitos||[]).forEach(a=>{ if(a.id==='artilheiros') (a.ranking||[]).slice(0,10).forEach(r=>lend.add(r.nome)); });
  const pen={}; J.forEach(j=>(j.pen_defendidos||[]).forEach(x=>{ pen[x.goleiro]=(pen[x.goleiro]||0)+1; }));
  const ano=p=>{ const a=(p.primeiro||'').slice(0,4)||String(p.periodo_aceito||'').slice(0,4); return +a||1909; };
  const lista=D.jogadores.slice().sort((a,b)=>ano(a)-ano(b)||(a.primeiro||'').localeCompare(b.primeiro||'')||a.nome.localeCompare(b.nome));
  FIG=lista.map((p,i)=>{
    const g=golsBest(p), jg=(()=>{ const x=ACC.p[p.nome]?.jogos; return x?x.v+(x.dataAte?jogosApos(p.nome,x.dataAte):0):(p.jogos||0); })();
    let r = lend.has(p.nome)||jg>=300||g>=100||(pen[p.nome]||0)>=10 ? 'lendaria' : (g>=30||jg>=120||(pen[p.nome]||0)>=3) ? 'brilhante' : 'comum';
    if(CFG.raridade&&CFG.raridade[p.nome]) r=CFG.raridade[p.nome];
    const a1=ano(p), a2=+(p.ultimo||'').slice(0,4)||+(String(p.periodo_aceito||'').slice(-4))||a1;
    const stat = pen[p.nome]>=3 ? `${pen[p.nome]} pênaltis defendidos` : g ? `${N(g)} ${g===1?'gol':'gols'}` : jg ? `${N(jg)} jogos` : 'elenco';
    const f={num:i+1, nome:p.nome, nomeV:nomeV(p.nome), r, stat, periodo:a1===a2?String(a1):`${a1}–${a2}`, dec:Math.floor(a1/10)*10};
    FIGN[p.nome]=f; return f; });
  return FIG;
}
const ROT={comum:'Comum', brilhante:'Brilhante', lendaria:'Lendária'};
function figHTML(f, extra=''){
  const n=G.owned[f.nome]||0;
  return `<a class="fig ${f.r}${f.r!=='comum'?' foil':''} ${extra}" href="#jogador-${slug(f.nome)}" aria-label="Figurinha ${f.num}, ${esc(f.nomeV)}, ${ROT[f.r]}">
    <span class="fig-top"><span>Nº ${f.num}</span><span>${ROT[f.r]}</span></span>
    <span class="fig-ph"><svg viewBox="0 0 120 140" aria-hidden="true"><circle cx="60" cy="40" r="22"></circle><path d="M14 140 C14 92 34 72 60 72 C86 72 106 92 106 140 Z"></path></svg>${n>1?`<span class="fig-dup">+${n-1}</span>`:''}</span>
    <span class="fig-nome">${esc(f.nomeV)}</span><span class="fig-stat">${esc(f.stat)}</span><span class="fig-per">${esc(f.periodo)}${posTxt(f.nome)?' · '+posTxt(f.nome):''}</span>${(G.vivo||{})[f.nome]?'<span class="fig-vivo">visto ao vivo</span>':''}</a>`;
}
function vazioHTML(f){ return `<div class="fig-vazio" aria-label="Espaço vazio da figurinha ${f.num}"><b>${f.num}</b><span>${esc(f.nomeV)}</span><small>${ROT[f.r]}</small></div>`; }

/* pontos e sorteios */
function novoDia(){ const d=hojeStr(); if(G.dia!==d){ G.dia=d; G.paginasHoje=[]; G.ptsHoje=0; G.gratis=true; G.sugHoje=0; return true; } return false; }
function ganha(n, motivo){ const P=CFG.pontos; const cab=Math.max(0, Math.min(n, (P.tetoDiario||40)-G.ptsHoje)); if(motivo==='sugestão'||motivo==='bônus do dia') { G.pts+=n; G.total+=n; } else { if(!cab) return 0; G.pts+=cab; G.total+=cab; G.ptsHoje+=cab; n=cab; }
  G.hist.unshift({d:Date.now(), n, m:motivo}); G.hist=G.hist.slice(0,40); return n; }
function sorteiaRar(){ const x=Math.random(); return x<0.03?'lendaria':x<0.2?'brilhante':'comum'; }
function sorteiaFig(){ const L=figuras(); const r=sorteiaRar(); const pool=L.filter(f=>f.r===r); const p=pool.length?pool:L; return p[Math.floor(Math.random()*p.length)]; }
function cola(f){ const nova=!G.owned[f.nome]; G.owned[f.nome]=(G.owned[f.nome]||0)+1; return nova; }
function gVisita(h){
  if(!G) return; figuras();
  let msg=[];
  if(novoDia()){ ganha(CFG.pontos.diario,'bônus do dia'); msg.push(`+${CFG.pontos.diario} pontos: bônus do dia`); }
  const chave=h.split('?')[0];
  if(!G.paginasHoje.includes(chave)){ G.paginasHoje.push(chave); const n=ganha(CFG.pontos.pagina,'página visitada'); if(n) msg.push(`+${n} ${n===1?'ponto':'pontos'}`); }
  if(chave.startsWith('jogador-')){
    const p=D.jogadores.find(x=>'jogador-'+slug(x.nome)===chave);
    if(p&&G.jogVistos[p.nome]!==G.dia){
      const primeira=!G.jogVistos[p.nome]; G.jogVistos[p.nome]=G.dia;
      if(primeira){ const n=ganha(CFG.pontos.jogadorNovo,'jogador novo'); if(n) msg.push(`+${n} pontos: jogador novo`); }
      const f=FIGN[p.nome]; const ch=(CFG.chanceJogador||12)/100*(f&&f.r==='lendaria'?0.4:f&&f.r==='brilhante'?0.7:1);
      if(f&&Math.random()<ch){ const nova=cola(f); gSave(); setTimeout(()=>achou(f,nova),600); }
    }
  }
  gSave(); atualizaChip(); if(msg.length) toast(msg.join(' · '));
}
function toast(t){ document.querySelectorAll('.gm-toast').forEach(x=>x.remove()); const el=document.createElement('div'); el.className='gm-toast'; el.setAttribute('role','status'); el.textContent=t; document.body.appendChild(el); setTimeout(()=>el.classList.add('sai'),2600); setTimeout(()=>el.remove(),3200); }
function achou(f,nova){
  const box=document.createElement('div'); box.className='gm-achou'; box.setAttribute('role','dialog'); box.setAttribute('aria-label','Figurinha encontrada');
  box.innerHTML=`<div class="gm-achou-in"><p class="osw">${nova?'Você encontrou uma figurinha!':'Figurinha repetida!'}</p>${figHTML(f,'a-flip')}<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><a class="more" href="#album">Ver álbum</a><button type="button" class="more" id="gmfecha">Fechar</button></div></div>`;
  document.body.appendChild(box); const fecha=()=>box.remove(); box.querySelector('#gmfecha').onclick=fecha; box.onclick=e=>{ if(e.target===box) fecha(); }; box.querySelector('#gmfecha').focus();
}
function atualizaChip(){ const c=document.getElementById('gmchip'); if(c&&G) c.innerHTML=`★ ${G.perfil&&G.perfil.apelido?esc(G.perfil.apelido)+' · ':''}${N(G.pts)} pts${typeof COLAB_MEU!=='undefined'&&COLAB_MEU?' '+seloColab(COLAB_MEU.n):''}${typeof ehApoiador==='function'&&G.perfil&&ehApoiador(G.perfil.apelido)?' '+apoiadorSelo():''}`; }

/* página do álbum */
let ALB={dec:null, filtro:'todas', q:'', pacote:[]};
function vAlbum(){
  const L=figuras(); if(ALB.dec===null) ALB.dec=L[L.length-1].dec;
  const decs=[...new Set(L.map(f=>f.dec))];
  const col=L.filter(f=>G.owned[f.nome]).length, rep=L.reduce((s,f)=>s+Math.max(0,(G.owned[f.nome]||0)-1),0);
  const porR=r=>{ const t=L.filter(f=>f.r===r); return `${t.filter(f=>G.owned[f.nome]).length}/${t.length}`; };
  setTimeout(albumUI);
  return `<div class="kicker">Encarte especial</div><h1>Álbum dos imortais</h1>
  <p class="lede">Todos os ${N(L.length)} jogadores da base viram figurinhas. Ganhe pontos navegando, abra pacotinhos e cole a história do Galo inteira.</p>
  <div class="alb-top">
    <div class="tiles"><div class="tile"><b id="albpts">${N(G.pts)}</b><span>Pontos</span></div><div class="tile"><b>${N(col)}</b><small class="basesm">de ${N(L.length)}</small><span>Coladas</span></div><div class="tile"><b>${N(rep)}</b><span>Repetidas</span></div><div class="tile"><b>${porR('lendaria')}</b><span>Lendárias</span></div><div class="tile"><b>${porR('brilhante')}</b><span>Brilhantes</span></div></div>
    <div class="alb-prog" aria-label="${Math.round(100*col/L.length)}% do álbum"><i style="width:${(100*col/L.length).toFixed(1)}%"></i></div>
    <div class="alb-acoes">
      <button type="button" class="pack" id="pkfree" ${G.gratis?'':'disabled'}>${G.gratis?'Abrir pacotinho grátis do dia':'Pacotinho grátis já aberto hoje'}</button>
      <button type="button" class="pack alt" id="pkpts">Abrir pacotinho · ${CFG.pontos.pacote} pts</button>
      <button type="button" class="ghost" id="anitog">Animações: ${lsGet(GMA)==='0'?'desligadas':'ligadas'}</button>
    </div>
    <p class="count">Como ganhar pontos: +${CFG.pontos.pagina} por página nova visitada no dia, +${CFG.pontos.jogadorNovo} por jogador visitado pela primeira vez, +${CFG.pontos.diario} pela primeira visita do dia e +${CFG.pontos.sugestao} por sugestão enviada (até 2 por dia). Visitando a página de um jogador, você tem chance de achar a figurinha dele.</p>
  </div>
  <div id="pkarea"></div>
  <div class="filters" style="margin-top:22px"><label>Época<select id="albdec">${decs.map(d=>`<option value="${d}"${d===ALB.dec?' selected':''}>${d<1910?'1908–1909':`Anos ${String(d).slice(2)} (${d})`}</option>`).join('')}<option value="-1"${ALB.dec===-1?' selected':''}>Todas as épocas</option></select></label>
  <label>Mostrar<select id="albfil">${[['todas','Todas'],['coladas','Só as coladas'],['faltam','Só as que faltam'],['repetidas','Repetidas']].map(([v,l])=>`<option value="${v}"${ALB.filtro===v?' selected':''}>${l}</option>`).join('')}</select></label>
  <label>Buscar<input id="albq" value="${esc(ALB.q)}" placeholder="nome do jogador"></label>${DONO?`<label class="chk" style="align-self:flex-end"><input type="checkbox" id="albver" ${ALB.verTodas?'checked':''}> Ver todas as figurinhas (só você)</label>`:''}</div>
  <div id="albgrid"></div>
  <h2>Meu progresso</h2>
  <div class="grid2"><div>
    <p class="count">${NUVEM?'Seu álbum está salvo na sua conta e neste aparelho.':'Seu álbum fica salvo neste aparelho, sem precisar de login.'} Para levar para outro aparelho, copie o código de backup e cole lá em "Restaurar".</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="ghost" id="bkcopia">Copiar código de backup</button><button type="button" class="ghost" id="bkrest">Restaurar de um código</button>${GDB&&GUID?`<button type="button" class="ghost" id="nuvem">${NUVEM?'Parar de salvar na conta':'Salvar também na minha conta (opcional)'}</button>`:''}</div>
    <textarea id="bktxt" rows="3" style="width:100%;margin-top:10px;display:none" aria-label="Código de backup"></textarea>
    <h3 style="margin-top:22px">Últimos pontos</h3>
    <table><tbody>${G.hist.slice(0,10).map(x=>`<tr><td class="mono uf">${new Date(x.d).toLocaleDateString('pt-BR')}</td><td>${esc(x.m)}</td><td class="n"><b>+${x.n}</b></td></tr>`).join('')||'<tr><td>Navegue pelo site para ganhar pontos.</td></tr>'}</tbody></table>
  </div><div>
    <h3>Mande uma sugestão (+${CFG.pontos.sugestao} pts)</h3>
    <p class="count">Um dado errado, um jogo que falta, uma ideia para o site.${CFG.contato?` A sugestão é copiada para você enviar a ${esc(CFG.contato)}.`:''}</p>
    <label class="cmp-pick" style="display:block">Sua sugestão<textarea id="sugtxt" rows="4" style="width:100%" placeholder="Ex.: o público do jogo de 12/05/1977 foi 80.000"></textarea></label>
    <p id="sugerr" class="count" style="color:var(--d)" role="alert"></p>
    <button type="button" class="more" id="sugenvia">Enviar sugestão</button>
  </div></div>`;
}
function albumGrid(){
  const L=figuras(), q=ALB.q.trim().toLowerCase();
  let l=L.filter(f=>(ALB.dec===-1||f.dec===ALB.dec)&&(!q||f.nome.toLowerCase().includes(q)));
  if(ALB.filtro==='coladas') l=l.filter(f=>G.owned[f.nome]); if(ALB.filtro==='faltam') l=l.filter(f=>!G.owned[f.nome]); if(ALB.filtro==='repetidas') l=l.filter(f=>(G.owned[f.nome]||0)>1);
  const lim=ALB.dec===-1&&!q?240:2000;
  const ed=f=>DONO?`<select class="rar-ed" data-rar="${esc(f.nome)}" aria-label="Raridade de ${esc(f.nomeV)}">${['comum','brilhante','lendaria'].map(r=>`<option value="${r}"${f.r===r?' selected':''}>${ROT[r]}${CFG.raridade[f.nome]===r?' ✎':''}</option>`).join('')}</select>`:'';
  return `<p class="count">${N(l.length)} figurinhas${l.length>lim?`, mostrando as primeiras ${lim}`:''}${DONO?'. Como dono, você muda a raridade pela lista embaixo de cada figurinha (✎ = escolhida por você).':''}</p><div class="alb-grid">${l.slice(0,lim).map(f=>`<div class="alb-cel">${G.owned[f.nome]||DONO&&ALB.verTodas?figHTML(f):vazioHTML(f)}${ed(f)}</div>`).join('')}</div>`;
}
function albumUI(){
  const g=$('#albgrid'); if(!g) return; g.innerHTML=albumGrid();
  const ligaRar=()=>document.querySelectorAll('[data-rar]').forEach(s=>s.onchange=async()=>{ const c=JSON.parse(JSON.stringify(CFG)); c.raridade[s.dataset.rar]=s.value; try{ await GDB.doc('site/config').set({json:JSON.stringify(c), em:Date.now()}); aplicaCfg(c); toast(`${nomeV(s.dataset.rar)} agora é ${ROT[s.value].toLowerCase()}.`); re(); }catch(e){ toast('Não foi possível salvar agora.'); } });
  const re=()=>{ $('#albgrid').innerHTML=albumGrid(); ligaRar(); }; ligaRar();
  const vt=$('#albver'); if(vt) vt.onchange=()=>{ ALB.verTodas=vt.checked; re(); };
  $('#albdec').onchange=e=>{ ALB.dec=+e.target.value; re(); };
  $('#albfil').onchange=e=>{ ALB.filtro=e.target.value; re(); };
  $('#albq').oninput=e=>{ ALB.q=e.target.value; re(); };
  const abre=(gratis)=>{
    if(gratis){ if(!G.gratis) return; G.gratis=false; } else { if(G.pts<CFG.pontos.pacote){ toast(`Faltam ${CFG.pontos.pacote-G.pts} pontos para um pacotinho.`); return; } G.pts-=CFG.pontos.pacote; G.hist.unshift({d:Date.now(), n:-CFG.pontos.pacote, m:'pacotinho aberto'}); }
    const pac=[]; for(let i=0;i<5;i++){ const f=sorteiaFig(); pac.push({f, nova:cola(f)}); }
    gSave(); atualizaChip(); ALB.pacote=pac; route.keep=true; route(); const pk=$('#pkarea'); if(pk) pk.scrollIntoView({behavior:animOn()?'smooth':'auto',block:'start'});
  };
  $('#pkfree').onclick=()=>abre(true); $('#pkpts').onclick=()=>abre(false);
  $('#anitog').onclick=()=>{ lsSet(GMA, lsGet(GMA)==='0'?'1':'0'); aplicaAnim(); route(); };
  if(ALB.pacote.length){ $('#pkarea').innerHTML=`<section class="pk"><h2 style="margin-top:0">★ Seu pacotinho</h2><div class="pk-row">${ALB.pacote.map((p,i)=>`<div class="pk-it" style="animation-delay:${(0.15*i).toFixed(2)}s">${figHTML(p.f,'a-flip')}<span class="pk-tag ${p.nova?'nova':''}">${p.nova?'Nova!':'Repetida'}</span></div>`).join('')}</div></section>`; ALB.pacote=[]; }
  const bt=$('#bktxt');
  $('#bkcopia').onclick=()=>{ const c='GM1:'+btoa(unescape(encodeURIComponent(JSON.stringify({o:G.owned,p:G.pts,t:G.total,x:{palpites:G.palpites,diario:G.diario,perfil:G.perfil,conq:G.conq,seq:G.seq,jd:G.jd,jdSeq:G.jdSeq,vis:G.vis}})))); bt.style.display='block'; bt.value=c; bt.select(); try{ navigator.clipboard.writeText(c).then(()=>toast('Código copiado.'),()=>toast('Selecione o código e copie.')); }catch(e){ toast('Selecione o código e copie.'); } };
  $('#bkrest').onclick=()=>{ if(bt.style.display!=='block'){ bt.style.display='block'; bt.value=''; bt.placeholder='Cole aqui o código GM1:… e clique de novo em Restaurar'; bt.focus(); return; }
    try{ const o=JSON.parse(decodeURIComponent(escape(atob(bt.value.trim().replace(/^GM1:/,''))))); if(!o||typeof o.o!=='object') throw 0;
      Object.entries(o.o).forEach(([k,v])=>{ if(FIGN[k]) G.owned[k]=Math.max(G.owned[k]||0, +v||0); }); G.pts=Math.max(G.pts, +o.p||0); G.total=Math.max(G.total, +o.t||0); if(o.x&&typeof o.x==='object'){ Object.assign(G.diario, o.x.diario||{}); G.palpites ||= {}; Object.assign(G.palpites, o.x.palpites||{}); Object.assign(G.conq, o.x.conq||{}); if(o.x.perfil&&o.x.perfil.apelido&&!G.perfil.apelido) G.perfil=o.x.perfil; if(o.x.seq&&o.x.seq.max>G.seq.max) G.seq=o.x.seq; Object.assign(G.jd, o.x.jd||{}); if(o.x.vis) Object.keys(G.vis).forEach(k=>Object.assign(G.vis[k], o.x.vis[k]||{})); } gSave(); toast('Tudo restaurado.'); route(); }
    catch(e){ toast('Esse código não é válido.'); } };
  const nv=$('#nuvem'); if(nv) nv.onclick=async()=>{ NUVEM=!NUVEM; lsSet('gm-nuvem',NUVEM?'1':'0'); if(NUVEM){ await nuvemCarrega(); gSave(); } route(); };
  $('#sugenvia').onclick=()=>{ const t=$('#sugtxt').value.trim(); const er=$('#sugerr');
    if(t.length<10){ er.textContent='Escreva a sugestão com pelo menos 10 caracteres.'; return; } er.textContent='';
    try{ navigator.clipboard.writeText(t); }catch(e){}
    let msg='Sugestão copiada'+(CFG.contato?` para enviar a ${CFG.contato}`:'')+'.';
    if(G.sugHoje<2){ G.sugHoje++; ganha(CFG.pontos.sugestao,'sugestão'); msg+=` +${CFG.pontos.sugestao} pontos.`; }
    gSave(); atualizaChip(); toast(msg); $('#sugtxt').value=''; };
  $('#sugtxt').oninput=()=>{ $('#sugerr').textContent=''; };
}
async function nuvemCarrega(){ if(!GDB||!GUID) return; try{ const s=await GDB.doc('data/users/'+GUID+'/album').get(); if(s.exists){ const o=JSON.parse(s.data().estado||'null'); if(o&&o.owned){ Object.entries(o.owned).forEach(([k,v])=>{ G.owned[k]=Math.max(G.owned[k]||0,v); }); G.pts=Math.max(G.pts,o.pts||0); G.total=Math.max(G.total,o.total||0); } } }catch(e){} }

/* página do dono */
function vDono(){
  if(!DONO) return `<div class="kicker">Página do dono</div><h1>Acesso restrito</h1><p class="lede">Esta página só abre para o dono do Galo Metrics, entrando com a conta dele.</p>`;
  setTimeout(donoUI);
  const P=CFG.pontos, px=CFG.proximo||{};
  const ajJ=Object.entries(CFG.jogos||{}), ajR=Object.entries(CFG.raridade||{});
  return `<div class="kicker">Só você vê esta página</div><h1>Página do dono</h1>
  <p class="lede">O que você muda aqui vale para todo mundo que abre o site, na hora. Os dados da base não são apagados: estes ajustes ficam por cima deles.</p>
  <form id="dform" class="dono">
  <h2>Página inicial</h2>
  <label>Manchete (aparece no topo do início)<input name="manchete" value="${esc(CFG.manchete||'')}" placeholder="Ex.: Final em Barranquilla: tudo sobre o Galo contra o Boca"></label>
  <label>Link da manchete (opcional)<input name="mancheteLink" value="${esc(CFG.mancheteLink||'')}" placeholder="#adversario-boca-juniors-arg"></label>
  <label>"Você sabia?" (uma curiosidade por linha; o site sorteia uma por visita)<textarea name="vocesabia" rows="5">${esc((CFG.vocesabia||[]).join('\n'))}</textarea></label>
  <h2>Próximo jogo</h2>
  <p class="count">O site pega o próximo jogo da base sozinho. Preencha só o que quiser mostrar ou corrigir.</p>
  <div class="dgrid">
  <label>Horário<input name="px_hora" value="${esc(px.hora||'')}" placeholder="20h (horário de Brasília)"></label>
  <label>Transmissão<input name="px_transmissao" value="${esc(px.transmissao||'')}" placeholder="SBT, Disney+ e Paramount+"></label>
  <label>Observação<input name="px_obs" value="${esc(px.obs||'')}" placeholder="Final em jogo único"></label>
  </div>
  <h2>Pontos e figurinhas</h2>
  <div class="dgrid">
  <label>Por página visitada<input type="number" min="0" max="50" name="p_pagina" value="${P.pagina}"></label>
  <label>Por jogador novo<input type="number" min="0" max="50" name="p_jogadorNovo" value="${P.jogadorNovo}"></label>
  <label>Bônus do dia<input type="number" min="0" max="200" name="p_diario" value="${P.diario}"></label>
  <label>Por sugestão<input type="number" min="0" max="200" name="p_sugestao" value="${P.sugestao}"></label>
  <label>Preço do pacotinho<input type="number" min="1" max="500" name="p_pacote" value="${P.pacote}"></label>
  <label>Teto de pontos por dia (navegação)<input type="number" min="1" max="500" name="p_tetoDiario" value="${P.tetoDiario}"></label>
  <label>Chance de achar a figurinha na página do jogador (%)<input type="number" min="0" max="100" name="chanceJogador" value="${CFG.chanceJogador}"></label>
  <label>Para onde as sugestões devem ser enviadas<input name="contato" value="${esc(CFG.contato||'')}" placeholder="@galometrics no Instagram"></label>
  </div>
  <h3>Raridade de uma figurinha</h3>
  <div class="dgrid"><label>Jogador<input name="r_nome" list="dnomes" placeholder="nome do jogador"></label><label>Raridade<select name="r_rar"><option value="">Automática</option><option value="comum">Comum</option><option value="brilhante">Brilhante</option><option value="lendaria">Lendária</option></select></label></div>
  <datalist id="dnomes">${D.jogadores.map(p=>`<option value="${esc(p.nome)}">`).join('')}</datalist>
  ${ajR.length?`<p class="count">Ajustadas: ${ajR.map(([n,r])=>`${esc(n)} (${ROT[r]})`).join(', ')}</p>`:''}
  <h2>Corrigir um jogo</h2>
  <div class="dgrid"><label>Número do jogo (está no fim do endereço, #jogo-<b>1234</b>)<input type="number" name="j_id" min="1"></label>
  <label>Estádio<input name="j_estadio"></label><label>Público<input type="number" name="j_publico" min="0"></label><label>Árbitro<input name="j_arbitro"></label></div>
  <label>Nota que aparece na página do jogo<input name="j_nota"></label>
  ${ajJ.length?`<table><thead><tr><th>Jogo</th><th>Ajustes</th><th></th></tr></thead><tbody>${ajJ.map(([id,o])=>`<tr><td><a href="#jogo-${id}">${byId[id]?esc(fmtD(byId[id].data)+' · '+byId[id].adversario):'#'+id}</a></td><td>${esc(Object.entries(o).map(([k,v])=>k+': '+v).join(' · '))}</td><td><button type="button" class="ghost" data-tira="${id}">Desfazer</button></td></tr>`).join('')}</tbody></table>`:''}
  <p id="dmsg" class="count" role="status"></p>
  <button type="submit" class="more">Salvar tudo</button>
  </form>${donoConquistas()}`;
}
function donoUI(){
  const f=$('#dform'); if(!f) return;
  f.querySelectorAll('[data-tira]').forEach(b=>b.onclick=async()=>{ const c=JSON.parse(JSON.stringify(CFG)); delete c.jogos[b.dataset.tira]; await salvaCfg(c); });
  f.onsubmit=async(e)=>{ e.preventDefault(); const v=n=>f.elements[n]?f.elements[n].value.trim():'';
    const c=JSON.parse(JSON.stringify(CFG));
    c.manchete=v('manchete'); c.mancheteLink=v('mancheteLink'); c.vocesabia=v('vocesabia').split('\n').map(s=>s.trim()).filter(Boolean).slice(0,60);
    c.proximo={hora:v('px_hora'), transmissao:v('px_transmissao'), obs:v('px_obs')};
    ['pagina','jogadorNovo','diario','sugestao','pacote','tetoDiario'].forEach(k=>{ const x=+v('p_'+k); if(v('p_'+k)!==''&&x>=0) c.pontos[k]=x; });
    c.chanceJogador=Math.min(100,Math.max(0,+v('chanceJogador')||0)); c.contato=v('contato');
    const rn=v('r_nome'); if(rn){ if(!D.jogadores.some(p=>p.nome===rn)){ $('#dmsg').textContent='Esse jogador não está na base. Escolha um nome da lista.'; return; } if(v('r_rar')) c.raridade[rn]=v('r_rar'); else delete c.raridade[rn]; }
    const jid=v('j_id'); if(jid){ if(!byId[+jid]){ $('#dmsg').textContent='Não existe jogo com esse número.'; return; } const o=c.jogos[jid]||{}; ['estadio','arbitro','nota'].forEach(k=>{ if(v('j_'+k)) o[k]=v('j_'+k); }); if(v('j_publico')) o.publico=+v('j_publico'); c.jogos[jid]=o; }
    await salvaCfg(c); };
}
async function salvaCfg(c){
  const m=$('#dmsg'); if(m) m.textContent='Salvando…';
  try{ await GDB.doc('site/config').set({json:JSON.stringify(c), em:Date.now()}); aplicaCfg(c); if(m) m.textContent='Salvo. Já vale para todo mundo.'; toast('Ajustes salvos.'); route(); }
  catch(e){ if(m) m.textContent='Não foi possível salvar agora. Tente de novo em instantes.'; }
}
const ORIG={};
function aplicaCfg(c){
  CFG=Object.assign(JSON.parse(JSON.stringify(CFG_PADRAO)), c||{}); CFG.pontos=Object.assign({}, CFG_PADRAO.pontos, (c&&c.pontos)||{});
  Object.entries(ORIG).forEach(([id,o])=>Object.assign(byId[id],o));
  Object.entries(CFG.jogos||{}).forEach(([id,o])=>{ const j=byId[id]; if(!j) return; if(!ORIG[id]) ORIG[id]={estadio:j.estadio, publico:j.publico, arbitro:j.arbitro, nota:j.nota}; Object.assign(j,o); });
  const nx=J.find(j=>!j.resultado&&j.data>=hojeStr()); if(nx){ D.proximo=D.proximo||{}; const px=Object.fromEntries(Object.entries(CFG.proximo||{}).filter(([k,v])=>v)); D.proximo[nx.id]=Object.assign({}, D.proximo[nx.id]||{}, px); }
  FIG=null;
}
async function gmInit(){
  gLoad(); aplicaAnim(); atualizaChip();
  if(!window.claude||!window.claude.use) return;
  try{ GUSER=await window.claude.use('user'); }catch(e){ GUSER=null; }
  try{ GDB=await window.claude.use('db'); }catch(e){ GDB=null; }
  try{ DONO=GUSER?!!(await GUSER.isOwner()):false; }catch(e){ DONO=false; }
  try{ GUID=GUSER?await GUSER.id():null; }catch(e){ GUID=null; }
  const nd=document.getElementById('navdono'); if(nd) nd.hidden=!DONO;
  if(GDB){ try{ const s=await GDB.doc('site/config').get(); if(s.exists){ aplicaCfg(JSON.parse(s.data().json||'{}')); } }catch(e){} }
  await carregaEdicoes(); await carregaRanking(); await carregaAval(); try{ await carregaColab(); }catch(e){}
  NUVEM = lsGet('gm-nuvem')==='1' && !!GDB && !!GUID; if(NUVEM){ await nuvemCarrega(); lsSet(GMK, JSON.stringify(G)); }
  atualizaChip(); route();
}

/* ---------- Edição pelo dono: jogos, notas de página, jogadores ---------- */
let EDIC={}, NOTAS={}, JOGX={};
const isPenTxt=t=>/p[eê]n/i.test(t||'');
function contrib(j){
  const m={}; const add=(n,k,v)=>{ (m[n] ||= {g:0,pen:0,jg:0,tit:0,comp:{},gcomp:{},datas:[]}); m[n][k]+=v; };
  (j.gols||[]).forEach(g=>{ if(g.lado==='galo'&&isGoal(g)){ add(g.jogador,'g',1); if(isPenTxt(g.tipo)) add(g.jogador,'pen',1); m[g.jogador].gcomp[j.grupo]=(m[g.jogador].gcomp[j.grupo]||0)+1; m[g.jogador].datas.push(j.data); } });
  const e=j.escalacao_galo; if(e&&j.data>=D.meta.escalacoes_desde){ const ps=new Set([...(e.titulares||[]), ...(e.substituicoes||[]).map(s=>s.entrou).filter(Boolean)]);
    ps.forEach(n=>{ add(n,'jg',1); if((e.titulares||[]).includes(n)) add(n,'tit',1); m[n].comp[j.grupo]=(m[n].comp[j.grupo]||0)+1; m[n].datas.push(j.data); }); }
  return m;
}
function aplicaContrib(m, s){
  Object.entries(m).forEach(([n,c])=>{ let p=D.jogadores.find(x=>x.nome===n);
    if(!p){ if(s<0) return; p={nome:n, jogos:0, titular:0, gols:0, gols_penalti:0, primeiro:null, ultimo:null, por_comp:{}, gols_comp:{}}; D.jogadores.push(p); }
    p.gols+=s*c.g; p.gols_penalti+=s*c.pen; p.jogos+=s*c.jg; p.titular+=s*c.tit;
    Object.entries(c.comp).forEach(([k,v])=>{ p.por_comp[k]=(p.por_comp[k]||0)+s*v; });
    Object.entries(c.gcomp).forEach(([k,v])=>{ p.gols_comp[k]=(p.gols_comp[k]||0)+s*v; });
    if(s>0) c.datas.forEach(d=>{ if(!p.primeiro||d<p.primeiro) p.primeiro=d; if(!p.ultimo||d>p.ultimo) p.ultimo=d; });
  });
}
const resOf=j=>j.gp==null||j.gc==null?null:j.gp>j.gc?'V':j.gp<j.gc?'D':'E';
function aplicaEdicao(id, e){
  let j=byId[id];
  if(!j){ if(!e.novo) return; j={id:+id, gols:[], tem_ficha:true, novo:true}; byId[id]=j; J.push(j); }
  else aplicaContrib(contrib(j),-1);
  Object.entries(e).forEach(([k,v])=>{ if(k!=='novo'&&k!=='em') j[k]=v; });
  j.temporada=+String(j.data||'').slice(0,4)||j.temporada; j.resultado=resOf(j);
  if(j.mando==='C') j.galo_mandante=true; else if(j.mando==='F') j.galo_mandante=false;
  j.tem_ficha = j.tem_ficha || !!(j.escalacao_galo&&j.escalacao_galo.titulares&&j.escalacao_galo.titulares.length);
  aplicaContrib(contrib(j),1);
}
function reordena(){ J.sort((a,b)=>a.data<b.data?-1:a.data>b.data?1:a.id-b.id); ADV=null; COMP_INIT=false; FIG=null; if(typeof COMPS!=='undefined') COMPS.splice(0,COMPS.length, ...COMPS.filter(c=>!c.sub)); }
async function carregaEdicoes(){
  if(!GDB) return;
  try{ const s=await GDB.collection('edicoes').limit(1000).get(); s.docs.forEach(d=>{ EDIC[d.id]=d.data(); }); }catch(e){}
  try{ const s=await GDB.collection('notas').limit(1000).get(); s.docs.forEach(d=>{ NOTAS[d.id]=d.data().texto||''; }); }catch(e){}
  try{ const s=await GDB.collection('jogadoresx').limit(1000).get(); s.docs.forEach(d=>{ JOGX[d.id]=d.data(); }); }catch(e){}
  Object.keys(EDIC).sort((a,b)=>+a-+b).forEach(id=>aplicaEdicao(id, EDIC[id])); reordena();
}
const chaveNota=h=>h.replace(/[^A-Za-z0-9_\-.~:@+]/g,'_').slice(0,180)||'inicio';
function notaPagina(h){
  const k=chaveNota(h), t=NOTAS[k];
  const vis = t?`<div class="nota-gm"><b>Nota do Galo Metrics.</b> ${esc(t)}</div>`:'';
  if(!DONO) return vis;
  return vis+`<details class="dono-ed"><summary>✎ ${t?'Editar':'Escrever'} nota desta página (só você vê este botão)</summary>
    <textarea id="notatxt" rows="3" style="width:100%" aria-label="Nota da página">${esc(t||'')}</textarea>
    <button type="button" class="more" data-nota="${esc(k)}">Salvar nota</button></details>`;
}
function ligaNota(){ const b=document.querySelector('[data-nota]'); if(!b) return; b.onclick=async()=>{ const k=b.dataset.nota, t=$('#notatxt').value.trim();
  try{ if(t) await GDB.doc('notas/'+k).set({texto:t, em:Date.now()}); else await GDB.doc('notas/'+k).delete(); if(t) NOTAS[k]=t; else delete NOTAS[k]; toast('Nota salva.'); route.keep=true; route(); }catch(e){ toast('Não foi possível salvar agora.'); } }; }

/* formulário de jogo */
const golsTxt=(j,lado)=>(j.gols||[]).filter(g=>g.lado===lado).map(g=>`${g.jogador}${g.minuto!=null?' '+g.minuto+"'":''}${g.tipo?' ('+g.tipo+')':''}`).join('\n');
function parseGols(t,lado){ return t.split('\n').map(s=>s.trim()).filter(Boolean).map(s=>{ const tipo=(s.match(/\(([^)]+)\)\s*$/)||[])[1]||null; s=s.replace(/\(([^)]+)\)\s*$/,'').trim(); const mm=s.match(/^(.*?)\s+(\d{1,3})'?$/); return {jogador:(mm?mm[1]:s).trim(), minuto:mm?+mm[2]:null, tipo, lado}; }); }
const escTxt=e=>e?{t:(e.titulares||[]).join('\n'), s:(e.substituicoes||[]).map(x=>`${x.entrou}${x.saiu?' > '+x.saiu:''}`).join('\n')}:{t:'',s:''};
function parseEsc(t,s){ const tit=t.split('\n').map(x=>x.trim()).filter(Boolean); if(!tit.length) return null; return {titulares:tit, substituicoes:s.split('\n').map(x=>x.trim()).filter(Boolean).map(x=>{ const [a,b]=x.split('>').map(y=>y.trim()); return {entrou:a, saiu:b||null}; })}; }
function formJogo(j){
  const eg=escTxt(j.escalacao_galo), ea=escTxt(j.escalacao_adv), novo=!j.id;
  const advs=advRows().slice().sort((a,b)=>b.J-a.J);
  const f=(n,l,v,t='text',ex='')=>`<label>${l}<input name="${n}" type="${t}" value="${esc(v??'')}" ${ex}></label>`;
  return `<form id="jform" class="dono jform"><h2 style="margin-top:0">${novo?'Novo jogo':'Editar este jogo'}</h2>
  <div class="dgrid">${f('data','Data',j.data,'date','required')}${f('competicao','Competição',j.competicao,'text','list="dcomps" required')}${f('fase','Fase',j.fase)}
  <label>Adversário<input name="adversario_id" list="dadvs" value="${esc(j.adversario_id||'')}" placeholder="escolha da lista ou digite um novo" required></label>
  ${f('adversario','Nome do adversário (se for novo)',j.adversario)}${f('adversario_uf','UF ou país (se for novo)',j.adversario_uf)}
  <label>Mando<select name="mando"><option value="C"${j.mando==='C'?' selected':''}>Casa</option><option value="F"${j.mando==='F'?' selected':''}>Fora</option><option value="N"${j.mando==='N'?' selected':''}>Neutro</option></select></label>
  ${f('gp','Gols do Galo',j.gp,'number','min="0"')}${f('gc','Gols do adversário',j.gc,'number','min="0"')}</div>
  <datalist id="dadvs">${advs.map(a=>`<option value="${esc(a.id)}">${esc(a.nome)} ${esc(a.uf)}</option>`).join('')}</datalist>
  <datalist id="dcomps">${[...new Set(J.map(x=>x.competicao).filter(Boolean))].map(c=>`<option value="${esc(c)}">`).join('')}</datalist>
  <div class="dgrid"><label>Gols do Galo (um por linha: Nome 23' (pênalti))<textarea name="golsg" rows="4">${esc(golsTxt(j,'galo'))}</textarea></label>
  <label>Gols do adversário (um por linha)<textarea name="golsa" rows="4">${esc(golsTxt(j,'adv'))}</textarea></label></div>
  <div class="dgrid">${f('estadio','Estádio',j.estadio,'text','list="dests"')}${f('cidade','Cidade',j.cidade)}${f('publico','Público',j.publico,'number','min="0"')}${f('renda','Renda',j.renda)}${f('arbitro','Árbitro',j.arbitro)}${f('tecnico_galo','Técnico do Galo',j.tecnico_galo)}${f('tecnico_adv','Técnico do adversário',j.tecnico_adv)}</div>
  <datalist id="dests">${[...new Set(J.map(x=>x.estadio).filter(Boolean))].map(c=>`<option value="${esc(c)}">`).join('')}</datalist>
  <div class="dgrid"><label>Titulares do Galo (um por linha, goleiro primeiro)<textarea name="eg_t" rows="11">${esc(eg.t)}</textarea></label><label>Substituições do Galo (Entrou > Saiu)<textarea name="eg_s" rows="5">${esc(eg.s)}</textarea></label></div>
  <div class="dgrid"><label>Titulares do adversário<textarea name="ea_t" rows="11">${esc(ea.t)}</textarea></label><label>Substituições do adversário<textarea name="ea_s" rows="5">${esc(ea.s)}</textarea></label></div>
  <label>Observações da ficha<textarea name="obs" rows="3">${esc(j.obs||'')}</textarea></label>
  ${f('nota','Nota curta (aparece em destaque)',j.nota)}
  <p id="jmsg" class="count" role="status"></p>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button type="submit" class="more">Salvar jogo</button>${!novo&&EDIC[j.id]&&!j.novo?'<button type="button" class="ghost" id="jdesfaz">Desfazer minhas edições neste jogo</button>':''}${j.novo?'<button type="button" class="ghost" id="japaga">Apagar este jogo</button>':''}</div></form>`;
}
function ligaFormJogo(j){
  const fm=$('#jform'); if(!fm) return;
  fm.onsubmit=async(ev)=>{ ev.preventDefault(); const v=n=>fm.elements[n]?fm.elements[n].value.trim():''; const msg=$('#jmsg');
    if(!/^\d{4}-\d\d-\d\d$/.test(v('data'))){ msg.textContent='Informe a data.'; return; }
    const aid=v('adversario_id').toLowerCase(); if(!aid){ msg.textContent='Informe o adversário.'; return; }
    const ex=advRows().find(a=>a.id===aid);
    if(!ex&&!v('adversario')){ msg.textContent='Adversário novo: preencha também o nome.'; return; }
    const num=k=>v(k)===''?null:+v(k);
    const e={data:v('data'), competicao:v('competicao'), fase:v('fase')||null, adversario_id:aid, adversario:ex?ex.nome:v('adversario'), adversario_uf:ex?ex.uf:(v('adversario_uf')||null), mando:v('mando'),
      gp:num('gp'), gc:num('gc'), gols:[...parseGols(v('golsg'),'galo'), ...parseGols(v('golsa'),'adv')], estadio:v('estadio')||null, cidade:v('cidade')||null, publico:num('publico'), renda:v('renda')||null, arbitro:v('arbitro')||null,
      tecnico_galo:v('tecnico_galo')||null, tecnico_adv:v('tecnico_adv')||null, escalacao_galo:parseEsc(v('eg_t'),v('eg_s')), escalacao_adv:parseEsc(v('ea_t'),v('ea_s')), obs:v('obs')||null, nota:v('nota')||null, em:Date.now()};
    const grupoDe=c=>{ const x=J.find(y=>y.competicao===c); return x?x.grupo:(/amistos/i.test(c)?'Amistoso':/mineir/i.test(c)?'Campeonato Mineiro':/brasileir/i.test(c)?'Campeonato Brasileiro':'Torneios e outros'); };
    e.grupo=grupoDe(e.competicao);
    if((e.gp!=null)!==(e.gc!=null)){ msg.textContent='Preencha os dois lados do placar, ou deixe os dois em branco.'; return; }
    let id=j.id; if(!id){ id=Math.max(...J.map(x=>x.id))+1; e.novo=true; } else if(j.novo) e.novo=true;
    msg.textContent='Salvando…';
    try{ await GDB.doc('edicoes/'+id).set(e); EDIC[id]=e; aplicaEdicao(id,e); reordena(); toast('Jogo salvo. Já vale para todo mundo.'); location.hash='jogo-'+id; route(); }
    catch(err){ msg.textContent='Não foi possível salvar agora. Tente de novo.'; }
  };
  const dz=$('#jdesfaz'); if(dz) dz.onclick=async()=>{ try{ await GDB.doc('edicoes/'+j.id).delete(); toast('Edições desfeitas. Recarregando…'); setTimeout(()=>location.reload(),800); }catch(e){ toast('Não foi possível agora.'); } };
  const ap=$('#japaga'); if(ap) ap.onclick=async()=>{ try{ await GDB.doc('edicoes/'+j.id).delete(); toast('Jogo apagado. Recarregando…'); location.hash='jogos'; setTimeout(()=>location.reload(),800); }catch(e){ toast('Não foi possível agora.'); } };
}
function vNovoJogo(){ if(!DONO) return vDono(); setTimeout(()=>ligaFormJogo({})); const prox=J.find(j=>!j.resultado&&j.data>=hojeStr());
  return `<a class="back" href="#jogos">← Jogos</a><div class="kicker">Página do dono</div><h1>Novo jogo</h1>${prox?`<p class="count">Para lançar o resultado de um jogo que já está na base, como ${esc(fmtD(prox.data))} contra ${esc(prox.adversario)}, abra <a href="#jogo-${prox.id}">a página dele</a> e use "Editar este jogo".</p>`:''}${formJogo({mando:'C'})}`; }
function blocoDonoJogo(j){ if(!DONO) return ''; setTimeout(()=>ligaFormJogo(j)); return `<details class="dono-ed" ${location.hash.includes('editar')?'open':''}><summary>✎ Editar este jogo (só você vê este botão)</summary>${formJogo(j)}</details>`; }
function blocoDonoJogador(p){
  const x=JOGX[slug(p.nome)]||{};
  const vis=x.bio?`<div class="nota-gm bio"><b>Perfil.</b> ${esc(x.bio)}</div>`:'';
  if(!DONO) return vis;
  setTimeout(()=>{ const b=$('#jxsalva'); if(b) b.onclick=async()=>{ const o={bio:$('#jxbio').value.trim(), posicao:$('#jxpos').value.trim(), em:Date.now()}; const r=$('#jxrar').value;
    try{ await GDB.doc('jogadoresx/'+slug(p.nome)).set(o); JOGX[slug(p.nome)]=o;
      if(r!==(CFG.raridade[p.nome]||'')){ const c=JSON.parse(JSON.stringify(CFG)); if(r) c.raridade[p.nome]=r; else delete c.raridade[p.nome]; await GDB.doc('site/config').set({json:JSON.stringify(c), em:Date.now()}); aplicaCfg(c); }
      toast('Jogador salvo.'); route.keep=true; route(); }catch(e){ toast('Não foi possível salvar agora.'); } }; });
  return vis+`<details class="dono-ed"><summary>✎ Editar perfil do jogador (só você vê este botão)</summary><div class="dono">
    <label>Posição<select id="jxpos"><option value="">Automática (${esc((p.posicao)||'pelas escalações')})</option>${POSS.map(q=>`<option${x.posicao===q?' selected':''}>${q}</option>`).join('')}</select></label>
    <label>Texto de perfil<textarea id="jxbio" rows="4" style="width:100%">${esc(x.bio||'')}</textarea></label>
    <label>Raridade da figurinha<select id="jxrar"><option value="">Automática</option>${['comum','brilhante','lendaria'].map(r=>`<option value="${r}"${CFG.raridade[p.nome]===r?' selected':''}>${ROT[r]}</option>`).join('')}</select></label>
    <p class="count">Para mudar gols e escalações, edite os jogos: os totais do jogador se recalculam sozinhos.</p>
    <button type="button" class="more" id="jxsalva">Salvar</button></div></details>`;
}

/* ---------- Perfil e conquistas ---------- */
function gExtra(){ G.diario ||= {}; G.vis ||= {jogo:{},jogador:{},adversario:{},temporada:{},competicao:{}}; G.seq ||= {ult:'',atual:0,max:0}; G.conq ||= {}; G.jd ||= {}; G.perfil ||= {apelido:'',fav:''}; G.jdSeq ||= {ult:'',atual:0,max:0}; }
function diasEntre(a,b){ return Math.round((new Date(b+'T12:00')-new Date(a+'T12:00'))/864e5); }
function marcaVisita(h){
  gExtra(); const d=hojeStr();
  if(G.seq.ult!==d){ G.seq.atual = G.seq.ult&&diasEntre(G.seq.ult,d)===1 ? G.seq.atual+1 : 1; G.seq.ult=d; G.seq.max=Math.max(G.seq.max,G.seq.atual); }
  const m=h.match(/^(jogo|jogador|adversario|temporada|competicao)-(.+)$/); if(m) G.vis[m[1]][m[2]]=1;
  G.vis.pag ||= {}; if(cnt(G.vis.pag)<6000) G.vis.pag[h]=1;
  G.flags ||= {}; (G.flags.horas ||= {})[new Date().getHours()]=1;
  if(m&&m[1]==='jogo'){ const j=byId[m[2]]; if(j&&!j.data_aprox&&j.data.slice(5)===d.slice(5)&&j.data.slice(0,4)!==d.slice(0,4)) G.flags.hoje=1; }
}
const cnt=o=>Object.keys(o||{}).length;
const CONQ=[
  {id:'bemvindo', nome:'Bem-vindo ao Galo Metrics', desc:'Abriu o site pela primeira vez.', pts:5, p:()=>[1,1]},
  {id:'fichas10', nome:'Leitor de súmula', desc:'Visitou 10 fichas de jogos.', pts:10, p:()=>[cnt(G.vis.jogo),10]},
  {id:'fichas100', nome:'Arquivista', desc:'Visitou 100 fichas de jogos.', pts:40, p:()=>[cnt(G.vis.jogo),100]},
  {id:'fichas1000', nome:'Guardião do arquivo', desc:'Visitou 1.000 fichas de jogos.', pts:150, p:()=>[cnt(G.vis.jogo),1000]},
  {id:'jog25', nome:'Olheiro', desc:'Visitou 25 jogadores.', pts:15, p:()=>[cnt(G.vis.jogador),25]},
  {id:'jog250', nome:'Enciclopédia alvinegra', desc:'Visitou 250 jogadores.', pts:80, p:()=>[cnt(G.vis.jogador),250]},
  {id:'adv20', nome:'Rodou o Brasil', desc:'Visitou 20 adversários.', pts:15, p:()=>[cnt(G.vis.adversario),20]},
  {id:'temp10', nome:'Viajante do tempo', desc:'Visitou 10 temporadas.', pts:15, p:()=>[cnt(G.vis.temporada),10]},
  {id:'comp5', nome:'Galeria dos campeões', desc:'Visitou 5 competições.', pts:10, p:()=>[cnt(G.vis.competicao),5]},
  {id:'rei', nome:'Salve o Rei', desc:'Visitou o perfil de Reinaldo.', pts:5, p:()=>[G.vis.jogador['reinaldo']?1:0,1]},
  {id:'liberta', nome:'Eu estava lá', desc:'Visitou a final da Libertadores de 2013.', pts:10, p:()=>[G.vis.jogo['5239']?1:0,1]},
  {id:'classico', nome:'Dono da cidade', desc:'Visitou o retrospecto contra o Cruzeiro.', pts:5, p:()=>[G.vis.adversario['cruzeiro-mg']?1:0,1]},
  {id:'seq3', nome:'Frequentador', desc:'Entrou 3 dias seguidos.', pts:15, p:()=>[G.seq.max,3]},
  {id:'seq7', nome:'Sócio-torcedor', desc:'Entrou 7 dias seguidos.', pts:40, p:()=>[G.seq.max,7]},
  {id:'seq30', nome:'Cadeira cativa', desc:'Entrou 30 dias seguidos.', pts:150, p:()=>[G.seq.max,30]},
  {id:'fig10', nome:'Primeiras figurinhas', desc:'Colou 10 figurinhas.', pts:10, p:()=>[cnt(G.owned),10]},
  {id:'fig100', nome:'Colecionador', desc:'Colou 100 figurinhas.', pts:60, p:()=>[cnt(G.owned),100]},
  {id:'fig500', nome:'Álbum de respeito', desc:'Colou 500 figurinhas.', pts:200, p:()=>[cnt(G.owned),500]},
  {id:'lend1', nome:'Tirou uma lendária', desc:'Colou a primeira figurinha lendária.', pts:20, p:()=>[figuras().filter(f=>f.r==='lendaria'&&G.owned[f.nome]).length,1]},
  {id:'decada', nome:'Década completa', desc:'Completou todas as figurinhas de uma década.', pts:100, p:()=>{ const L=figuras(); const by={}; L.forEach(f=>{ (by[f.dec] ||= [0,0]); by[f.dec][1]++; if(G.owned[f.nome]) by[f.dec][0]++; }); const best=Object.values(by).reduce((m,x)=>x[0]/x[1]>m[0]/m[1]?x:m,[0,1]); return [best[0],best[1]]; }},
  {id:'jd1', nome:'Primeira vitória', desc:'Venceu um desafio diário.', pts:10, p:()=>[Object.values(G.jd).some(d=>Object.values(d).some(x=>x.ok))?1:0,1]},
  {id:'jd4', nome:'Dia perfeito', desc:'Venceu os 7 desafios no mesmo dia.', pts:80, p:()=>[Math.max(0,...Object.values(G.jd).map(d=>DESAF.map(x=>x[0]).filter(k=>d[k]&&d[k].ok).length)),7]},
  {id:'cx1', nome:'Conectado', desc:'Fechou as Conexões alvinegras.', pts:15, p:()=>[Object.values(G.jd).some(d=>d.conexoes&&d.conexoes.ok)?1:0,1]},
  {id:'imp5', nome:'Faro de olheiro', desc:'Achou os 5 impostores no mesmo dia.', pts:25, p:()=>[Math.max(0,...Object.values(G.jd).map(d=>d.impostor?d.impostor.acertos:0)),5]},
  {id:'jdseq7', nome:'Treino diário', desc:'Jogou os desafios 7 dias seguidos.', pts:50, p:()=>[G.jdSeq.max,7]},
  {id:'aval10', nome:'Crítico de arquibancada', desc:'Avaliou 10 jogos no diário.', pts:25, p:()=>[Object.values(G.diario||{}).filter(y=>y.n||y.t).length,10]},
  {id:'est1', nome:'Eu fui!', desc:'Registrou o primeiro jogo no estádio.', pts:10, p:()=>[Object.values(G.diario||{}).filter(y=>y.est).length,1]},
  {id:'est10', nome:'Arquibancada é minha casa', desc:'Registrou 10 jogos no estádio.', pts:50, p:()=>[Object.values(G.diario||{}).filter(y=>y.est).length,10]},
  {id:'pequente', nome:'Pé-quente', desc:'Tem 70% de aproveitamento em 10 jogos ou mais no estádio.', pts:60, secreta:true, p:()=>{ const S=statsEstadio(); return [S.ids.length>=10&&pct(S.r)>=0.7?1:0,1]; }},
  {id:'palp1', nome:'Palpiteiro', desc:'Deu o primeiro palpite.', pts:5, p:()=>[Object.values(G.palpites||{}).filter(p=>p.gp!=null).length,1]},
  {id:'exato', nome:'Vidente', desc:'Acertou um placar exato.', pts:40, secreta:true, p:()=>[Object.values(G.palpites||{}).some(p=>p.res&&p.res.placar)?1:0,1]},
  {id:'pts1000', nome:'Mil pontos', desc:'Somou 1.000 pontos no total.', pts:50, p:()=>[G.total,1000]},
];
function checaConquistas(){
  gExtra(); const novas=[];
  todasConq().forEach(c=>{ if(G.conq[c.id]) return; const [a,b]=c.p(); if(a>=b){ G.conq[c.id]=hojeStr(); G.pts+=c.pts; G.total+=c.pts; G.hist.unshift({d:Date.now(), n:c.pts, m:'conquista: '+c.nome}); novas.push(c); } });
  if(novas.length){ gSave(); atualizaChip(); setTimeout(()=>toast(`★ Conquista: ${novas.map(c=>c.nome).join(', ')} (+${novas.reduce((s,c)=>s+c.pts,0)} pts)`),900); }
}
function vPerfil(){
  gExtra(); const L=figuras(); const fav=G.perfil.fav&&FIGN[G.perfil.fav];
  setTimeout(()=>{ const b=$('#pfsalva'); if(b) b.onclick=()=>{ const ap=$('#pfap').value.trim().slice(0,30), fv=$('#pffav').value.trim(); if(fv&&!FIGN[fv]){ $('#pferr').textContent='Escolha um jogador da lista.'; return; } const an=$('#pfaniv').value, ano=$('#pfano').value.trim(), nm=$('#pfnome').value.trim().split(/\s+/)[0]||''; if(ano&&!(+ano>1900&&+ano<=new Date().getFullYear())){ $('#pferr').textContent='Ano de nascimento inválido.'; return; } G.perfil={apelido:ap, fav:fv, nome:nm.slice(0,30), aniv:an?an.slice(5):'', ano:ano}; gSave(); toast('Perfil salvo.'); route.keep=true; route(); };
    const t=$('#anitog2'); if(t) t.onclick=()=>{ lsSet(GMA, lsGet(GMA)==='0'?'1':'0'); aplicaAnim(); route.keep=true; route(); }; });
  const TC=todasConq(); const feitas=TC.filter(c=>G.conq[c.id]).length;
  return `<div class="kicker">Ficha do torcedor</div><h1>${esc(G.perfil.apelido||'Meu perfil')}</h1>
  <div class="perfil-top">${fav?figHTML(fav):`<div class="fig-vazio"><b>?</b><span>Escolha seu ídolo</span></div>`}
  <div style="flex:1;min-width:260px"><div class="tiles"><div class="tile"><b>${N(G.pts)}</b><span>Pontos para gastar</span></div><div class="tile"><b>${N(G.total)}</b><span>Pontos no total</span></div><div class="tile"><b>${G.seq.atual}</b><small class="basesm">recorde: ${G.seq.max}</small><span>Dias seguidos</span></div><div class="tile"><b>${N(cnt(G.owned))}</b><small class="basesm">de ${N(L.length)}</small><span>Figurinhas</span></div><div class="tile"><b>${feitas}</b><small class="basesm">de ${TC.length}</small><span>Conquistas</span></div></div>
  <div class="dono" style="margin-top:14px"><div class="dgrid"><label>Apelido<input id="pfap" value="${esc(G.perfil.apelido||'')}" maxlength="30" placeholder="Como você quer ser chamado"></label><label>Ídolo (figurinha de capa)<input id="pffav" list="pfl" value="${esc(G.perfil.fav||'')}" placeholder="nome do jogador"></label></div>
  <details class="pf-extra"><summary>Para conquistas surpresa (opcional)</summary><div class="dgrid"><label>Primeiro nome<input id="pfnome" value="${esc(G.perfil.nome||'')}" maxlength="30" placeholder="Ex.: Rodrigo"></label><label>Aniversário<input id="pfaniv" type="date" value="${G.perfil.aniv?'2000-'+G.perfil.aniv:''}"></label><label>Ano de nascimento<input id="pfano" type="number" min="1900" max="2026" value="${esc(G.perfil.ano||'')}"></label></div><p class="count">Fica só neste aparelho. Serve para conquistas como visitar um jogo do dia do seu aniversário ou um jogador xará.</p></details>
  <datalist id="pfl">${L.map(f=>`<option value="${esc(f.nome)}">`).join('')}</datalist><p id="pferr" class="count" role="alert" style="color:var(--d)"></p>
  <div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="more" id="pfsalva">Salvar perfil</button><button type="button" class="ghost" id="anitog2">Animações: ${lsGet(GMA)==='0'?'desligadas':'ligadas'}</button><a class="ghost" href="#album" style="text-decoration:none">Abrir o álbum</a></div></div></div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">${tw(`Meu perfil no Galo Metrics: ${feitas} conquistas, ${N(cnt(G.owned))} figurinhas e ${G.seq.max} dias seguidos de visita.`)}<a class="ghost" href="#diario" style="text-decoration:none">Meu diário de jogos</a></div>
  <h2>Conquistas</h2><div class="conq-grid">${TC.map(c=>{ const [a,b]=c.p(), ok=!!G.conq[c.id]; if(c.secreta&&!ok) return `<div class="conq secreta"><span class="conq-ic" aria-hidden="true">?</span><div><b>Conquista secreta</b><p>Continue explorando o site para descobrir.</p><small>+${c.pts} pts</small></div></div>`; return `<div class="conq ${ok?'ok':''}"><span class="conq-ic" aria-hidden="true">${ok?'★':'☆'}</span><div><b>${esc(c.nome)}</b><p>${esc(c.desc||'')}</p><small>${ok?`Conquistada em ${fmtD(G.conq[c.id])} · +${c.pts} pts`:`${N(Math.min(a,b))} de ${N(b)} · +${c.pts} pts`}</small>${ok?`<div>${tw(`Conquista desbloqueada no Galo Metrics: ${c.nome}${c.desc?' ('+c.desc+')':''}`,'Tweetar')}</div>`:`<i class="conq-bar"><i style="width:${Math.min(100,100*a/b).toFixed(0)}%"></i></i>`}</div></div>`; }).join('')}</div>
  <p class="count">Seu perfil, pontos e conquistas ficam salvos neste aparelho. Use o código de backup no <a href="#album">álbum</a> para levar tudo para outro aparelho.</p>`;
}

/* ---------- Desafios diários ---------- */
function rngDia(nome){ let h=2166136261; const s=hojeStr()+nome; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } let a=h>>>0; return ()=>{ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const semAc=s=>s.normalize('NFD').replace(/[̀-ͯ]/g,'').toUpperCase();
function jdHoje(){ gExtra(); return (G.jd[hojeStr()] ||= {}); }
function jdFim(jogo, ok, pts){ const d=jdHoje(); d[jogo]=Object.assign(d[jogo]||{}, {ok, fim:true});
  const h=hojeStr(); if(G.jdSeq.ult!==h){ G.jdSeq.atual = G.jdSeq.ult&&diasEntre(G.jdSeq.ult,h)===1 ? G.jdSeq.atual+1 : 1; G.jdSeq.ult=h; G.jdSeq.max=Math.max(G.jdSeq.max,G.jdSeq.atual); }
  if(pts>0){ G.pts+=pts; G.total+=pts; G.hist.unshift({d:Date.now(), n:pts, m:'desafio: '+jogo}); }
  gSave(); atualizaChip(); checaConquistas(); if(pts>0) toast(`+${pts} pontos no desafio`); }
const DESAF=[['conexoes','Conexões alvinegras','Separe 16 jogadores em 4 grupos com algo em comum.'],['impostor','Impostor','Quatro jogadores têm algo em comum. Ache o que não tem.'],['carreira','Adivinhe pela carreira','Descubra o jogador pelos números da passagem dele pelo Galo.'],['galodle','Galodle','Adivinhe o jogador em 6 tentativas, letra por letra.'],['quem','Quem é?','Descubra o jogador do dia pelas pistas: época, gols, jogos e raridade.'],['placar','Placar do dia','Acerte o placar de um jogo histórico em 3 chutes.'],['maismenos','Mais ou menos','Quem fez mais gols pelo Galo? Faça a maior sequência.']];
function vDesafios(){ const d=jdHoje();
  return `<div class="kicker">Todo dia tem jogo</div><h1>Desafios do dia</h1><p class="lede">Sete joguinhos novos a cada dia, iguais para todo mundo. Vencer dá pontos para o álbum, e o resultado copiado vale para o <a href="#ranking">ranking da semana</a>.</p>
  <div class="desaf-grid">${DESAF.map(([k,n,t])=>`<a class="desaf ${d[k]&&d[k].fim?(d[k].ok?'ok':'fim'):''}" href="#desafio-${k}"><span class="osw">${d[k]&&d[k].fim?(d[k].ok?'★ Vencido hoje':'Jogado hoje'):'Disponível'}</span><b>${n}</b><p>${t}</p></a>`).join('')}</div>
  <p class="count">Sequência de dias jogando: ${G.jdSeq.atual} (recorde ${G.jdSeq.max}). Os desafios trocam à meia-noite.</p>`; }
function compartilha(txt){ try{ navigator.clipboard.writeText(txt).then(()=>toast('Resultado copiado. Cole onde quiser.'),()=>toast('Não deu para copiar.')); }catch(e){ toast('Não deu para copiar.'); } }

/* Galodle */
function galodleResp(){ const r=rngDia('galodle'); const l=figuras().filter(f=>{ const s=semAc(f.nomeV).replace(/[^A-Z]/g,''); return s.length===5&&f.nomeV.split(' ').length===1&&(f.r!=='comum'||/gols|jogos/.test(f.stat)); }); return l[Math.floor(r()*l.length)]; }
function vGalodle(){
  const f=galodleResp(), alvo=semAc(f.nomeV).replace(/[^A-Z]/g,''), st=(jdHoje().galodle ||= {t:[], fim:false, ok:false});
  const marca=g=>{ const res=Array(5).fill('x'), sobra={}; [...alvo].forEach((c,i)=>{ if(g[i]===c) res[i]='v'; else sobra[c]=(sobra[c]||0)+1; }); [...g].forEach((c,i)=>{ if(res[i]!=='v'&&sobra[c]){ res[i]='a'; sobra[c]--; } }); return res; };
  const linhas=[...st.t.map(g=>({g, m:marca(g)})), ...Array(Math.max(0,6-st.t.length)).fill(null)];
  setTimeout(()=>{ if(st.fim) return; let cur='';
    const draw=()=>{ const row=document.querySelector('.gd-row.cur'); if(row) [...row.children].forEach((c,i)=>{ c.textContent=cur[i]||''; }); };
    const envia=()=>{ if(cur.length<5){ toast('Faltam letras.'); return; } st.t.push(cur); const ok=cur===alvo; if(ok||st.t.length>=6){ st.fim=true; st.ok=ok; jdFim('galodle', ok, ok?Math.max(8,22-3*st.t.length):0); } else gSave(); route.keep=true; route(); };
    const tecla=k=>{ if(st.fim) return; if(k==='ENTER') return envia(); if(k==='DEL'){ cur=cur.slice(0,-1); return draw(); } if(/^[A-Z]$/.test(k)&&cur.length<5){ cur+=k; draw(); } };
    document.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>tecla(b.dataset.k));
    const kd=e=>{ if(!location.hash.startsWith('#desafio-galodle')){ document.removeEventListener('keydown',kd); return; } if(e.target.closest&&e.target.closest('input,textarea')) return; const k=e.key==='Enter'?'ENTER':e.key==='Backspace'?'DEL':semAc(e.key); if(k==='ENTER'||k==='DEL'||/^[A-Z]$/.test(k)){ e.preventDefault(); tecla(k); } };
    if(window._gdkd) document.removeEventListener('keydown',window._gdkd); window._gdkd=kd; document.addEventListener('keydown',kd); });
  const usadas={}; st.t.forEach(g=>marca(g).forEach((m,i)=>{ const c=g[i]; if(m==='v'||usadas[c]==='v') usadas[c]='v'; else if(m==='a'||usadas[c]==='a') usadas[c]='a'; else usadas[c]='x'; }));
  const kb=['QWERTYUIOP','ASDFGHJKL','ZXCVBNM'];
  const share=()=>`Galodle ${fmtD(hojeStr())} ${st.ok?st.t.length:'X'}/6\n`+st.t.map(g=>marca(g).map(m=>m==='v'?'🟩':m==='a'?'🟨':'⬛').join('')).join('\n')+'\nGalo Metrics';
  setTimeout(()=>{ const s=$('#gdshare'); if(s) { const _t=()=>textoRank('Galodle', (st.ok?st.t.length:'X')+'/6\n'+st.t.map(g=>marca(g).map(m=>m==='v'?'🟩':m==='a'?'🟨':'⬛').join('')).join('\n'), st.ok?7-st.t.length:0); s.onclick=()=>compartilha(_t()); const w=document.getElementById(s.id.replace('share','tw')); if(w) w.href='https://twitter.com/intent/tweet?text='+encodeURIComponent((_t()+'\n#GaloMetrics').slice(0,280)); }; });
  return `<a class="back" href="#desafios">← Desafios</a><div class="kicker">Desafio do dia</div><h1>Galodle</h1><p class="count">Um jogador do Galo com nome de 5 letras (sem acento). Verde: letra no lugar certo. Amarelo: a letra existe em outra posição.</p>
  <div class="gd-board" role="grid" aria-label="Tentativas">${linhas.map((l,i)=>`<div class="gd-row ${!l&&i===st.t.length&&!st.fim?'cur':''}" role="row">${[0,1,2,3,4].map(k=>`<span class="gd-c ${l?l.m[k]:''}" role="gridcell" style="${l?`animation-delay:${k*0.12}s`:''}">${l?l.g[k]:''}</span>`).join('')}</div>`).join('')}</div>
  ${st.fim?`<div class="desaf-fim"><p class="osw">${st.ok?`★ Acertou em ${st.t.length}!`:'Não foi hoje.'} O jogador era:</p>${figHTML(f,'a-flip')}<button type="button" class="more" id="gdshare">Copiar resultado</button><a class="ghost tw" id="gdtw" href="#" target="_blank" rel="noopener">Pronto para tweet ↗</a>${artBtn({t:'desafio',nome:'Galodle',res:(st.ok?st.t.length:'X')+'/6',ok:st.ok,grade:st.t.map(g=>marca(g).join('')).join('\n')})}</div>`
   :`<div class="gd-kb">${kb.map((r,i)=>`<div>${i===2?'<button type="button" class="gd-k wide" data-k="ENTER">Enviar</button>':''}${[...r].map(c=>`<button type="button" class="gd-k ${usadas[c]||''}" data-k="${c}">${c}</button>`).join('')}${i===2?'<button type="button" class="gd-k wide" data-k="DEL" aria-label="Apagar">⌫</button>':''}</div>`).join('')}</div>`}`;
}

/* Quem é? */
function quemResp(){ const r=rngDia('quem'); const l=figuras().filter(f=>f.r!=='comum'); return l[Math.floor(r()*l.length)]; }
function infoJ(nome){ const p=D.jogadores.find(x=>x.nome===nome), f=FIGN[nome]; const jg=(()=>{ const x=ACC.p[nome]?.jogos; return x?x.v+(x.dataAte?jogosApos(nome,x.dataAte):0):(p.jogos||0); })(); return {nome, dec:f.dec, gols:golsBest(p), jogos:jg, r:f.r, pos:posTxt(nome), ini:semAc(f.nomeV)[0]}; }
function vQuem(){
  const alvo=quemResp(), A=infoJ(alvo.nome), st=(jdHoje().quem ||= {t:[], fim:false, ok:false});
  const seta=(a,b)=>a===b?['v','=']:a<b?['a','↑']:['a','↓'];
  setTimeout(()=>{ const b=$('#qmenv'); if(!b) return; const go=()=>{ const v=$('#qmin').value.trim(); if(!FIGN[v]){ $('#qmerr').textContent='Escolha um nome da lista.'; return; } if(st.t.includes(v)){ $('#qmerr').textContent='Você já tentou esse.'; return; }
      st.t.push(v); const ok=v===alvo.nome; if(ok||st.t.length>=8){ st.fim=true; st.ok=ok; jdFim('quem', ok, ok?Math.max(6,24-2*st.t.length):0); } else gSave(); route.keep=true; route(); };
    b.onclick=go; $('#qmin').onkeydown=e=>{ if(e.key==='Enter') go(); }; $('#qmin').oninput=()=>{ $('#qmerr').textContent=''; }; $('#qmin').focus(); });
  setTimeout(()=>{ const s=$('#qmshare'); if(s) { const _t=()=>textoRank('Quem é?', (st.ok?st.t.length:'X')+'/8', st.ok?9-st.t.length:0); s.onclick=()=>compartilha(_t()); const w=document.getElementById(s.id.replace('share','tw')); if(w) w.href='https://twitter.com/intent/tweet?text='+encodeURIComponent((_t()+'\n#GaloMetrics').slice(0,280)); }; });
  const decTxt=d=>d<1910?'1900s':`anos ${String(d).slice(2)}`;
  return `<a class="back" href="#desafios">← Desafios</a><div class="kicker">Desafio do dia</div><h1>Quem é?</h1><p class="count">Chute qualquer jogador da base. As setas dizem se o jogador do dia estreou depois (↑) ou antes (↓), e se tem mais ou menos gols e jogos; verde na posição e na inicial é acerto. Jogos só contam de 2000 em diante. Você tem 8 chutes.</p>
  ${st.fim?'':`<div class="filters"><label>Seu chute<input id="qmin" list="qml" placeholder="nome do jogador" autocomplete="off"></label><button type="button" class="more" id="qmenv" style="align-self:flex-end">Chutar</button></div><datalist id="qml">${figuras().map(f=>`<option value="${esc(f.nome)}">`).join('')}</datalist><p id="qmerr" class="count" role="alert" style="color:var(--d)"></p>`}
  <table class="qm"><thead><tr><th>Jogador</th><th>Época</th><th class="n">Gols</th><th class="n">Jogos*</th><th>Posição</th><th>Inicial</th></tr></thead><tbody>${st.t.slice().reverse().map(n=>{ const B=infoJ(n); const e=seta(B.dec,A.dec), g=seta(B.gols,A.gols), jj=seta(B.jogos,A.jogos);
    return `<tr class="a-flip"><td><b>${esc(nomeV(n))}</b></td><td class="qc ${e[0]}">${decTxt(B.dec)} ${e[1]}</td><td class="qc n ${g[0]}">${B.gols} ${g[1]}</td><td class="qc n ${jj[0]}">${B.jogos} ${jj[1]}</td><td class="qc ${B.pos===A.pos?'v':'x'}">${esc(B.pos||'?')}</td><td class="qc ${B.ini===A.ini?'v':'x'}">${B.ini}</td></tr>`; }).join('')}</tbody></table>
  <p class="count">${st.t.length} de 8 chutes.</p>
  ${st.fim?`<div class="desaf-fim"><p class="osw">${st.ok?`★ Acertou em ${st.t.length}!`:'Não foi hoje.'} O jogador era:</p>${figHTML(alvo,'a-flip')}<button type="button" class="more" id="qmshare">Copiar resultado</button><a class="ghost tw" id="qmtw" href="#" target="_blank" rel="noopener">Pronto para tweet ↗</a>${artBtn({t:'desafio',nome:'Quem é?',res:(st.ok?st.t.length:'X')+'/8',ok:st.ok})}</div>`:''}`;
}

/* Placar do dia */
function placarJogo(){ const r=rngDia('placar'); const l=J.filter(j=>j.resultado&&j.gp!=null&&j.gp+j.gc>=2&&j.grupo!=='Amistoso'&&!j.data_aprox&&j.data<hojeStr()); return l[Math.floor(r()*l.length)]; }
function vPlacar(){
  const j=placarJogo(), st=(jdHoje().placar ||= {t:[], fim:false, ok:false});
  setTimeout(()=>{ const b=$('#plenv'); if(!b) return; b.onclick=()=>{ const a=$('#plg').value, c=$('#pla').value; if(a===''||c===''){ $('#plerr').textContent='Preencha os dois lados.'; return; } const g=[+a,+c];
    st.t.push(g); const ok=g[0]===j.gp&&g[1]===j.gc; if(ok||st.t.length>=3){ st.fim=true; st.ok=ok; jdFim('placar', ok, ok?[15,10,6][st.t.length-1]:0); } else gSave(); route.keep=true; route(); }; });
  const dica=(x,y)=>x===y?'<span class="qc v">certo</span>':x<y?'<span class="qc a">foi mais ↑</span>':'<span class="qc a">foi menos ↓</span>';
  setTimeout(()=>{ const s=$('#plshare'); if(s) { const _t=()=>textoRank('Placar do dia', (st.ok?st.t.length:'X')+'/3', st.ok?4-st.t.length:0); s.onclick=()=>compartilha(_t()); const w=document.getElementById(s.id.replace('share','tw')); if(w) w.href='https://twitter.com/intent/tweet?text='+encodeURIComponent((_t()+'\n#GaloMetrics').slice(0,280)); }; });
  return `<a class="back" href="#desafios">← Desafios</a><div class="kicker">Desafio do dia</div><h1>Placar do dia</h1>
  <div class="pl-card a-up"><span class="osw">${esc(j.competicao||'')}${j.fase?' · '+esc(j.fase):''}</span><div class="pl-vs">${cr('galo','crb')}<b>Atlético</b><span class="vs">?  ×  ?</span><b>${esc(j.adversario)}</b>${cr(j.adversario_id,'crb crb2')}</div><span class="cou">${DIAS[new Date(j.data+'T12:00').getDay()]}, ${fmtD(j.data)}${j.estadio?' · '+esc(j.estadio):''}${j.cidade?' · '+esc(j.cidade):''}</span></div>
  <table><tbody>${st.t.map(g=>`<tr><td class="mono">${g[0]} x ${g[1]}</td><td>Galo: ${dica(g[0],j.gp)}</td><td>${esc(j.adversario)}: ${dica(g[1],j.gc)}</td></tr>`).join('')}</tbody></table>
  ${st.fim?`<div class="desaf-fim"><p class="osw">${st.ok?`★ Acertou em ${st.t.length}!`:'Não foi hoje.'} O placar foi <a href="#jogo-${j.id}">Atlético ${j.gp} x ${j.gc} ${esc(j.adversario)}</a>.</p><button type="button" class="more" id="plshare">Copiar resultado</button><a class="ghost tw" id="pltw" href="#" target="_blank" rel="noopener">Pronto para tweet ↗</a>${artBtn({t:'desafio',nome:'Placar do dia',res:(st.ok?st.t.length:'X')+'/3',ok:st.ok})}</div>`
  :`<div class="filters"><label>Gols do Galo<input id="plg" type="number" min="0" max="20" inputmode="numeric"></label><label>Gols do ${esc(j.adversario)}<input id="pla" type="number" min="0" max="20" inputmode="numeric"></label><button type="button" class="more" id="plenv" style="align-self:flex-end">Chutar (${3-st.t.length} restantes)</button></div><p id="plerr" class="count" role="alert" style="color:var(--d)"></p>`}`;
}

/* Mais ou menos */
function mmLista(){ const r=rngDia('maismenos'); const l=figuras().filter(f=>{ const p=D.jogadores.find(x=>x.nome===f.nome); return p&&golsBest(p)>=5; }).map(f=>({f, g:golsBest(D.jogadores.find(x=>x.nome===f.nome))}));
  for(let i=l.length-1;i>0;i--){ const k=Math.floor(r()*(i+1)); [l[i],l[k]]=[l[k],l[i]]; } return l; }
function vMaisMenos(){
  const L=mmLista(), st=(jdHoje().maismenos ||= {i:0, fim:false, ok:false, seq:0});
  const a=L[st.i], b=L[st.i+1];
  setTimeout(()=>{ document.querySelectorAll('[data-mm]').forEach(bt=>bt.onclick=()=>{ const esc_=bt.dataset.mm==='a'?a:b, outro=bt.dataset.mm==='a'?b:a; const ok=esc_.g>=outro.g;
    if(ok){ st.seq++; st.i++; st.ult=`${nomeV(a.f.nome)} ${a.g} × ${b.g} ${nomeV(b.f.nome)}`; if(st.i>=L.length-1){ st.fim=true; st.ok=true; jdFim('maismenos', true, Math.min(25,st.seq*2)); } else gSave(); }
    else { st.fim=true; st.ok=st.seq>=5; st.ult=`${nomeV(a.f.nome)} ${a.g} × ${b.g} ${nomeV(b.f.nome)}`; jdFim('maismenos', st.ok, Math.min(25,st.seq*2)); }
    route.keep=true; route(); }); const s=$('#mmshare'); if(s) { const _t=()=>textoRank('Mais ou menos', 'sequência de '+st.seq, st.seq); s.onclick=()=>compartilha(_t()); const w=document.getElementById(s.id.replace('share','tw')); if(w) w.href='https://twitter.com/intent/tweet?text='+encodeURIComponent((_t()+'\n#GaloMetrics').slice(0,280)); }; });
  const lado=(x,k)=>`<button type="button" class="mm-op" data-mm="${k}">${figHTML(x.f).replace(/^<a /,'<span ').replace(/<\/a>$/,'</span>').replace(/ href="[^"]*"/,'')}<span class="osw">${k==='a'?'Este fez mais':'Este fez mais'}</span></button>`;
  return `<a class="back" href="#desafios">← Desafios</a><div class="kicker">Desafio do dia</div><h1>Mais ou menos</h1><p class="count">Quem fez mais gols pelo Galo? Cada acerto aumenta a sequência; o primeiro erro encerra o jogo do dia. Com 5 acertos ou mais, conta como vitória. Gols pelo número aceito, quando existe.</p>
  <p class="classico-num"><b>${st.seq}</b> acertos seguidos${st.ult?` · último: ${esc(st.ult)}`:''}</p>
  ${st.fim?`<div class="desaf-fim"><p class="osw">${st.ok?'★ Boa sequência!':'Fim de jogo.'} Você fez ${st.seq} ${st.seq===1?'acerto':'acertos'}.</p><button type="button" class="more" id="mmshare">Copiar resultado</button><a class="ghost tw" id="mmtw" href="#" target="_blank" rel="noopener">Pronto para tweet ↗</a>${artBtn({t:'desafio',nome:'Mais ou menos',res:st.seq+' acertos',ok:st.ok})}</div>`
   :`<div class="mm">${lado(a,'a')}<span class="mm-x">×</span>${lado(b,'b')}</div>`}`;
}

/* ---------- Posição dos jogadores ---------- */
const POSS=['Goleiro','Defensor','Meia','Atacante'];
let PENC=null;
function posicaoDe(nome){
  const x=JOGX[slug(nome)]; if(x&&POSS.includes(x.posicao)) return {pos:x.posicao, est:false};
  const p=D.jogadores.find(q=>q.nome===nome); if(p&&p.posicao) return {pos:p.posicao, est:false};
  if(!PENC){ PENC={}; J.forEach(j=>(j.pen_defendidos||[]).forEach(d=>{ PENC[d.goleiro]=(PENC[d.goleiro]||0)+1; })); }
  if(PENC[nome]) return {pos:'Goleiro', est:true};
  if(p&&golsBest(p)>=30) return {pos:'Atacante', est:true};
  return null;
}
const posTxt=n=>{ const x=posicaoDe(n); return x?x.pos:''; };

/* ---------- categorias para Conexões e Impostor ---------- */
let CATS=null;
function categorias(){
  if(CATS) return CATS;
  const L=figuras(), byN={}; L.forEach(f=>byN[f.nome]=f);
  const pj=n=>D.jogadores.find(p=>p.nome===n);
  const conhecido=f=>f.r!=='comum'||/gols|jogos/.test(f.stat)&&(parseInt(f.stat.replace(/\D/g,''))||0)>=15;
  const C=[];
  const add=(id,nome,lista)=>{ const s=[...new Set(lista)].filter(n=>byN[n]); if(s.length>=4) C.push({id,nome,m:new Set(s)}); };
  const elenco=(f)=>{ const s=new Set(); J.filter(f).forEach(j=>{ const e=j.escalacao_galo; if(!e) return; e.titulares.forEach(n=>s.add(n)); e.substituicoes.forEach(x=>x.entrou&&s.add(x.entrou)); }); return [...s]; };
  const freq=(f,min)=>{ const c={}; J.filter(f).forEach(j=>{ const e=j.escalacao_galo; if(!e) return; new Set([...e.titulares,...e.substituicoes.map(x=>x.entrou)]).forEach(n=>{ c[n]=(c[n]||0)+1; }); }); return Object.keys(c).filter(n=>c[n]>=min); };
  add('lib2013','Campeões da Libertadores 2013', elenco(j=>j.id===5239||j.id===5238));
  add('bra2021','Campeões brasileiros de 2021', freq(j=>j.temporada===2021&&j.grupo==='Campeonato Brasileiro',12));
  add('serieb2006','Campanha da Série B de 2006', freq(j=>j.temporada===2006&&j.competicao==='Brasileiro-Série B',12));
  POSS.forEach(p=>add('pos-'+p,{Goleiro:'Goleiros',Defensor:'Defensores',Meia:'Meias',Atacante:'Atacantes'}[p], L.filter(f=>posTxt(f.nome)===p&&conhecido(f)).map(f=>f.nome)));
  add('g100','Fizeram 100 gols ou mais', L.filter(f=>golsBest(pj(f.nome))>=100).map(f=>f.nome));
  [1930,1950,1970,1980,1990,2000,2010].forEach(d=>add('dec'+d,`Estrearam nos anos ${String(d).slice(2)}`, L.filter(f=>f.dec===d&&conhecido(f)).map(f=>f.nome)));
  const czg={}; J.filter(j=>j.adversario_id==='cruzeiro mg').forEach(j=>j.gols.forEach(g=>{ if(g.lado==='galo'&&isGoal(g)) czg[g.jogador]=(czg[g.jogador]||0)+1; }));
  add('cz5','Marcaram 5 gols ou mais no clássico', Object.keys(czg).filter(n=>czg[n]>=5));
  const hat={}; J.forEach(j=>{ const c={}; j.gols.forEach(g=>{ if(g.lado==='galo'&&isGoal(g)) c[g.jogador]=(c[g.jogador]||0)+1; }); Object.entries(c).forEach(([n,v])=>{ if(v>=3&&j.data>=D.meta.escalacoes_desde) hat[n]=1; }); });
  add('hat','Fizeram hat-trick pelo Galo desde '+D.meta.escalacoes_desde.slice(0,4), Object.keys(hat));
  add('j300','Passaram de 300 jogos (desde '+D.meta.escalacoes_desde.slice(0,4)+')', L.filter(f=>(pj(f.nome).jogos||0)>=300).map(f=>f.nome));
  posicaoDe(''); add('pen','Defenderam pênaltis pelo Galo', Object.keys(PENC));
  CATS=C; return C;
}
function embaralha(a,r){ a=a.slice(); for(let i=a.length-1;i>0;i--){ const k=Math.floor(r()*(i+1)); [a[i],a[k]]=[a[k],a[i]]; } return a; }

/* ---------- Conexões ---------- */
function conexoesDia(){
  const r=rngDia('conexoes'), C=categorias();
  for(let tent=0;tent<200;tent++){
    const esc4=embaralha(C,r).slice(0,4); const grupos=[];
    let ok=true;
    for(const c of esc4){ const outros=esc4.filter(x=>x!==c); const pool=embaralha([...c.m].filter(n=>!outros.some(o=>o.m.has(n))&&!grupos.some(g=>g.m.includes(n))),r);
      if(pool.length<4){ ok=false; break; } grupos.push({id:c.id, nome:c.nome, m:pool.slice(0,4)}); }
    if(ok) return grupos;
  }
  return null;
}
const CORES=['#C9962B','#F5F2EA','#9a958a','#111'];
function vConexoes(){
  const G4=conexoesDia(); if(!G4) return `<p class="empty">Não foi possível montar o desafio de hoje.</p>`;
  const st=(jdHoje().conexoes ||= {achados:[], erros:0, fim:false, ok:false, sel:[]});
  const resolvidos=st.achados.map(id=>G4.find(g=>g.id===id));
  const resta=embaralha(G4.filter(g=>!st.achados.includes(g.id)).flatMap(g=>g.m), rngDia('cx-ordem'+(st.mix||0)));
  setTimeout(()=>{
    document.querySelectorAll('[data-cx]').forEach(b=>b.onclick=()=>{ const n=b.dataset.cx; const i=st.sel.indexOf(n); if(i>=0) st.sel.splice(i,1); else if(st.sel.length<4) st.sel.push(n); route.keep=true; route(); });
    const env=$('#cxenv'); if(env) env.onclick=()=>{ if(st.sel.length!==4){ toast('Escolha 4 jogadores.'); return; }
      const g=G4.find(x=>st.sel.every(n=>x.m.includes(n)));
      if(g){ st.achados.push(g.id); st.sel=[]; if(st.achados.length===4){ st.fim=true; st.ok=true; jdFim('conexoes', true, Math.max(8,24-4*st.erros)); } else gSave(); }
      else { const quase=G4.some(x=>st.sel.filter(n=>x.m.includes(n)).length===3); st.erros++; st.sel=[]; if(st.erros>=4){ st.fim=true; st.ok=false; st.achados=G4.map(x=>x.id); jdFim('conexoes', false, 0); } else { gSave(); toast(quase?'Quase! Faltou um.':'Não é um grupo.'); } }
      route.keep=true; route(); };
    const mx=$('#cxmix'); if(mx) mx.onclick=()=>{ st.mix=(st.mix||0)+1; gSave(); route.keep=true; route(); };
    const lp=$('#cxlimpa'); if(lp) lp.onclick=()=>{ st.sel=[]; route.keep=true; route(); };
    const s=$('#cxshare'); if(s) { const _t=()=>textoRank('Conexões alvinegras', st.ok?`${st.erros} erros`:'X', st.ok?Math.max(1,5-st.erros):0); s.onclick=()=>compartilha(_t()); const w=document.getElementById(s.id.replace('share','tw')); if(w) w.href='https://twitter.com/intent/tweet?text='+encodeURIComponent((_t()+'\n#GaloMetrics').slice(0,280)); };
  });
  return `<a class="back" href="#desafios">← Desafios</a><div class="kicker">Desafio do dia</div><h1>Conexões alvinegras</h1>
  <p class="count">Separe os 16 jogadores em 4 grupos de 4 que têm algo em comum. Você pode errar 3 vezes.</p>
  <div class="cx">${resolvidos.map((g,i)=>`<div class="cx-ok a-flip" style="background:${CORES[G4.indexOf(g)]};color:${G4.indexOf(g)===3?'#F5F2EA':'#111'}"><b>${esc(g.nome)}</b><span>${g.m.map(n=>esc(nomeV(n))).join(' · ')}</span></div>`).join('')}
  ${st.fim?'':`<div class="cx-grid">${resta.map(n=>`<button type="button" class="cx-t ${st.sel.includes(n)?'on':''}" data-cx="${esc(n)}" aria-pressed="${st.sel.includes(n)}">${esc(nomeV(n))}</button>`).join('')}</div>`}</div>
  ${st.fim?`<div class="desaf-fim"><p class="osw">${st.ok?`★ Fechou os 4 grupos com ${st.erros} ${st.erros===1?'erro':'erros'}!`:'Não foi hoje. Os grupos estão acima.'}</p><button type="button" class="more" id="cxshare">Copiar resultado</button><a class="ghost tw" id="cxtw" href="#" target="_blank" rel="noopener">Pronto para tweet ↗</a>${artBtn({t:'desafio',nome:'Conexões',res:st.ok?st.erros+' erros':'X',ok:st.ok})}</div>`
  :`<p class="count">Erros restantes: ${'● '.repeat(4-st.erros)}${'○ '.repeat(st.erros)}</p><div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="more" id="cxenv">Enviar grupo</button><button type="button" class="ghost" id="cxmix">Embaralhar</button><button type="button" class="ghost" id="cxlimpa">Limpar seleção</button></div>`}`;
}

/* ---------- Impostor ---------- */
function impostorDia(){
  const r=rngDia('impostor'), C=categorias().filter(c=>!c.id.startsWith('pos-')), L=figuras();
  const rodadas=[];
  for(const c of embaralha(C,r)){
    if(rodadas.length>=5) break;
    const mem=embaralha([...c.m],r).slice(0,4); if(mem.length<4) continue;
    const pos=posTxt(mem[0]), dec=FIGN[mem[0]].dec;
    let pool=L.filter(f=>!c.m.has(f.nome)&&(f.r!=='comum')&&(Math.abs(f.dec-dec)<=10||posTxt(f.nome)===pos));
    if(!pool.length) pool=L.filter(f=>!c.m.has(f.nome)&&f.r!=='comum');
    const imp=pool[Math.floor(r()*pool.length)].nome;
    rodadas.push({cat:c.nome, nomes:embaralha([...mem,imp],r), imp});
  }
  return rodadas;
}
function vImpostor(){
  const R=impostorDia(), st=(jdHoje().impostor ||= {i:0, acertos:0, fim:false, ok:false, resp:[]});
  const rod=R[st.i];
  setTimeout(()=>{ document.querySelectorAll('[data-imp]').forEach(b=>b.onclick=()=>{ const ok=b.dataset.imp===rod.imp; st.resp.push({ok, esc:b.dataset.imp}); if(ok) st.acertos++; st.i++;
      if(st.i>=R.length){ st.fim=true; st.ok=st.acertos>=3; jdFim('impostor', st.ok, st.acertos*4); } else gSave(); route.keep=true; route(); });
    const s=$('#imshare'); if(s) { const _t=()=>textoRank('Impostor', `${st.acertos}/${R.length}`, st.acertos); s.onclick=()=>compartilha(_t()); const w=document.getElementById(s.id.replace('share','tw')); if(w) w.href='https://twitter.com/intent/tweet?text='+encodeURIComponent((_t()+'\n#GaloMetrics').slice(0,280)); }; });
  const hist=st.resp.map((x,i)=>`<li>${x.ok?'★':'✗'} <b>${esc(R[i].cat)}</b>: o impostor era ${esc(nomeV(R[i].imp))}${x.ok?'':`, você escolheu ${esc(nomeV(x.esc))}`}.</li>`).join('');
  return `<a class="back" href="#desafios">← Desafios</a><div class="kicker">Desafio do dia</div><h1>Impostor</h1>
  <p class="count">Em cada rodada, quatro jogadores têm algo em comum e um não tem. Ache o impostor. São ${R.length} rodadas.</p>
  ${st.fim?`<div class="desaf-fim"><p class="osw">${st.ok?'★ ':''}Você achou ${st.acertos} de ${R.length} impostores.</p><button type="button" class="more" id="imshare">Copiar resultado</button><a class="ghost tw" id="imtw" href="#" target="_blank" rel="noopener">Pronto para tweet ↗</a>${artBtn({t:'desafio',nome:'Impostor',res:st.acertos+'/5',ok:st.ok})}</div>`
  :`<p class="classico-num"><b>${st.i+1}</b> de ${R.length} · ${st.acertos} ${st.acertos===1?'acerto':'acertos'}</p><div class="imp-g a-up">${rod.nomes.map(n=>`<button type="button" class="cx-t" data-imp="${esc(n)}">${esc(nomeV(n))}<small>${esc(posTxt(n)||'')}${posTxt(n)?' · ':''}${esc(FIGN[n].periodo)}</small></button>`).join('')}</div>`}
  ${hist?`<h2>Rodadas</h2><ul class="imp-h">${hist}</ul>`:''}`;
}

/* ---------- Adivinhe pela carreira ---------- */
function carreiraResp(){ const r=rngDia('carreira'); const l=figuras().filter(f=>{ const p=D.jogadores.find(x=>x.nome===f.nome); const ys=J.filter(j=>jogouOuMarcou(j,f.nome)).map(j=>j.temporada); return new Set(ys).size>=3&&(golsBest(p)>=15||(p.jogos||0)>=80); }); return l[Math.floor(r()*l.length)]; }
function vCarreira(){
  const alvo=carreiraResp(), nome=alvo.nome, p=D.jogadores.find(x=>x.nome===nome), st=(jdHoje().carreira ||= {t:[], fim:false, ok:false});
  const list=J.filter(j=>jogouOuMarcou(j,nome)); const gpj=j=>j.gols.filter(g=>isGoal(g)&&g.jogador===nome).length;
  const anos={}; list.forEach(j=>{ const a=(anos[j.temporada] ||= {j:0,g:0}); if(j.escalacao_galo&&j.data>=D.meta.escalacoes_desde) a.j++; a.g+=gpj(j); });
  const ys=Object.keys(anos).sort(), mx=Math.max(1,...ys.map(y=>anos[y].g));
  const comp={}, vit={}; list.forEach(j=>{ const g=gpj(j); if(g){ comp[j.competicao]=(comp[j.competicao]||0)+g; vit[j.adversario]=(vit[j.adversario]||0)+g; } });
  const top=o=>Object.entries(o).sort((a,b)=>b[1]-a[1])[0];
  const jg=(()=>{ const x=ACC.p[nome]?.jogos; return x?x.v+(x.dataAte?jogosApos(nome,x.dataAte):0):(p.jogos||0); })();
  const pistas=[
    ['Período e posição', `${alvo.periodo} · ${ys.length} temporadas · ${posTxt(nome)||'posição não registrada'}`],
    ['Números no Galo', `${N(golsBest(p))} gols${jg?` · ${N(jg)} jogos desde ${D.meta.escalacoes_desde.slice(0,4)}`:''}`],
    ['Gols por temporada', `<div class="cr-bars">${ys.map(y=>`<span title="${y}: ${anos[y].g} gols"><i style="height:${Math.max(2,70*anos[y].g/mx)}px"></i><small>${y.slice(2)}</small></span>`).join('')}</div>`],
    ['Onde mais marcou', top(comp)?`${esc(top(comp)[0])} (${top(comp)[1]} gols)`:'não marcou gols'],
    ['Vítima preferida', top(vit)?`${esc(top(vit)[0])} (${top(vit)[1]} gols)`:'não marcou gols'],
    ['Inicial do nome', `${semAc(alvo.nomeV)[0]} · ${alvo.nomeV.length} letras`],
  ];
  const ab=st.fim?pistas.length:Math.min(pistas.length, st.t.length+1);
  setTimeout(()=>{ const b=$('#crenv'); if(b){ const go=()=>{ const v=$('#crin').value.trim(); if(!FIGN[v]){ $('#crerr').textContent='Escolha um nome da lista.'; return; } if(st.t.includes(v)){ $('#crerr').textContent='Você já tentou esse.'; return; }
      st.t.push(v); const ok=v===nome; if(ok||st.t.length>=6){ st.fim=true; st.ok=ok; jdFim('carreira', ok, ok?Math.max(6,24-3*st.t.length):0); } else gSave(); route.keep=true; route(); };
    b.onclick=go; $('#crin').onkeydown=e=>{ if(e.key==='Enter') go(); }; $('#crin').oninput=()=>{ $('#crerr').textContent=''; }; }
    const s=$('#crshare'); if(s) { const _t=()=>textoRank('Adivinhe pela carreira', st.ok?`${st.t.length}/6`:'X/6', st.ok?7-st.t.length:0); s.onclick=()=>compartilha(_t()); const w=document.getElementById(s.id.replace('share','tw')); if(w) w.href='https://twitter.com/intent/tweet?text='+encodeURIComponent((_t()+'\n#GaloMetrics').slice(0,280)); }; });
  return `<a class="back" href="#desafios">← Desafios</a><div class="kicker">Desafio do dia</div><h1>Adivinhe pela carreira</h1>
  <p class="count">Uma pista nova a cada chute errado. Você tem 6 chutes.</p>
  <div class="cr-pistas">${pistas.slice(0,ab).map(([t,v],i)=>`<div class="cr-p a-up" style="animation-delay:${i===ab-1?0:0}s"><span class="osw">Pista ${i+1} · ${t}</span><div>${v}</div></div>`).join('')}${pistas.slice(ab).map((x,i)=>`<div class="cr-p fechada"><span class="osw">Pista ${ab+i+1}</span><div>?</div></div>`).join('')}</div>
  ${st.t.length?`<p class="count">Chutes: ${st.t.map(n=>`<s>${esc(nomeV(n))}</s>`).join(', ').replace(`<s>${esc(nomeV(nome))}</s>`,`<b>${esc(nomeV(nome))}</b>`)}</p>`:''}
  ${st.fim?`<div class="desaf-fim"><p class="osw">${st.ok?`★ Acertou em ${st.t.length}!`:'Não foi hoje.'} Era:</p>${figHTML(alvo,'a-flip')}<button type="button" class="more" id="crshare">Copiar resultado</button><a class="ghost tw" id="crtw" href="#" target="_blank" rel="noopener">Pronto para tweet ↗</a>${artBtn({t:'desafio',nome:'Carreira',res:(st.ok?st.t.length:'X')+'/6',ok:st.ok})}</div>`
  :`<div class="filters"><label>Seu chute<input id="crin" list="crl" placeholder="nome do jogador" autocomplete="off"></label><button type="button" class="more" id="crenv" style="align-self:flex-end">Chutar (${6-st.t.length} restantes)</button></div><datalist id="crl">${figuras().map(f=>`<option value="${esc(f.nome)}">`).join('')}</datalist><p id="crerr" class="count" role="alert" style="color:var(--d)"></p>`}`;
}

/* ---------- Ranking (com código de conferência) ---------- */
function hashTxt(s){ let h=5381; for(let i=0;i<s.length;i++) h=(h*33+s.charCodeAt(i))>>>0; return h.toString(36).toUpperCase().slice(-5); }
const RK_SAL='galo-1908';
function textoRank(jogo, res, pts){ const ap=(G.perfil&&G.perfil.apelido)||'Torcedor'; const d=fmtD(hojeStr()); const cod=hashTxt([RK_SAL,ap,d,jogo,pts].join('|'));
  return `${jogo} ${d}: ${res}\n${ap} · ${pts} pts no ranking · cód ${cod}\nGalo Metrics`; }
function leTextoRank(t){ const out=[]; const re=/^(.+?) (\d\d\/\d\d\/\d{4}): .*\n(.+?) · (\d+) pts no ranking · cód ([0-9A-Z]+)/gm; let m;
  while((m=re.exec(t))){ const [_,jogo,d,ap,pts,cod]=m; out.push({jogo,d,ap,pts:+pts,ok:hashTxt([RK_SAL,ap,d,jogo,+pts].join('|'))===cod}); } return out; }
const semanaDe=dstr=>{ const [dd,mm,yy]=dstr.split('/').map(Number); const d=new Date(yy,mm-1,dd); const seg=new Date(d); seg.setDate(d.getDate()-((d.getDay()+6)%7)); return `${seg.getFullYear()}-${String(seg.getMonth()+1).padStart(2,'0')}-${String(seg.getDate()).padStart(2,'0')}`; };
let RANK={};
async function carregaRanking(){ if(!GDB) return; try{ const s=await GDB.collection('ranking').limit(60).get(); s.docs.forEach(d=>{ RANK[d.id]=d.data(); }); }catch(e){} }
function vRanking(){
  const sem=semanaDe(fmtD(hojeStr())); const semanas=Object.keys(RANK).sort().reverse(); const atual=RANK[sem]||{pessoas:{}};
  const tab=o=>{ const l=Object.entries(o.pessoas||{}).map(([ap,x])=>({ap, pts:Object.values(x).reduce((s,v)=>s+v,0), n:Object.keys(x).length})).sort((a,b)=>b.pts-a.pts);
    return l.length?`<table><thead><tr><th>#</th><th>Torcedor</th><th class="n">Desafios</th><th class="n">Pontos</th></tr></thead><tbody>${l.map((x,i)=>`<tr><td class="mono">${i+1}</td><td>${i===0?'★ ':''}${esc(x.ap)}</td><td class="n">${x.n}</td><td class="n"><b>${x.pts}</b></td></tr>`).join('')}</tbody></table>`:'<p class="empty">Ninguém no ranking desta semana ainda.</p>'; };
  setTimeout(()=>{ const b=$('#rkadd'); if(!b) return; b.onclick=async()=>{ const it=leTextoRank($('#rktxt').value); const msg=$('#rkmsg');
    if(!it.length){ msg.textContent='Nenhum resultado reconhecido. Cole o texto copiado pelo botão "Copiar resultado".'; return; }
    const val=it.filter(x=>x.ok), inv=it.length-val.length; const por={};
    val.forEach(x=>{ const s=semanaDe(x.d); const doc=(por[s] ||= JSON.parse(JSON.stringify(RANK[s]||{pessoas:{}}))); const p=(doc.pessoas[x.ap] ||= {}); p[x.jogo+' '+x.d]=x.pts; });
    try{ for(const [s,doc] of Object.entries(por)){ await GDB.doc('ranking/'+s).set(doc); RANK[s]=doc; } msg.textContent=`${val.length} resultado(s) lançado(s)${inv?`, ${inv} com código inválido ignorado(s)`:''}.`; route.keep=true; route(); }
    catch(e){ msg.textContent='Não foi possível salvar agora.'; } }; });
  return `<div class="kicker">Desafios</div><h1>Ranking da semana</h1>
  <p class="lede">Jogue os desafios, copie o resultado e mande para ${esc(CFG.contato||'o Galo Metrics')}. Cada resultado tem um código de conferência, e os pontos entram no ranking da semana (de segunda a domingo).</p>
  <h2>Semana de ${fmtD(sem)}</h2>${tab(atual)}
  ${semanas.filter(s=>s!==sem).slice(0,4).map(s=>`<h2>Semana de ${fmtD(s)}</h2>${tab(RANK[s])}`).join('')}
  ${DONO?`<details class="dono-ed" open><summary>✎ Lançar resultados recebidos (só você vê)</summary><div class="dono"><label>Cole aqui um ou vários resultados<textarea id="rktxt" rows="6" style="width:100%"></textarea></label><p id="rkmsg" class="count" role="status"></p><button type="button" class="more" id="rkadd">Conferir e lançar</button></div></details>`:''}
  <p class="count">Pontos por desafio: Galodle 7 menos as tentativas, Quem é? 9 menos os chutes, Placar do dia 4 menos os chutes, Mais ou menos 1 por acerto, Conexões 5 menos os erros, Impostor 1 por impostor achado, Carreira 7 menos os chutes. Para aparecer com seu nome, defina um apelido no <a href="#perfil">Perfil</a> antes de jogar.</p>`;
}

/* ---------- Pronto para tweet ---------- */
function tw(texto, rotulo='Pronto para tweet'){ const t=(texto+'\n#GaloMetrics').slice(0,280); return `<a class="ghost tw" href="https://twitter.com/intent/tweet?text=${encodeURIComponent(t)}" target="_blank" rel="noopener">${rotulo} ↗</a>`; }
const estrelas=n=>n?('★'.repeat(Math.floor(n))+(n%1?'½':'')):'';
const resumoJogo=j=>{ const gg=(j.gols||[]).filter(g=>g.lado==='galo').map(g=>`${nomeV(g.jogador)}${g.minuto!=null?' '+g.minuto+"'":''}`);
  return `Atlético ${placar(j)} ${j.adversario}${j.fase?', '+j.fase:''}${j.competicao?' ('+j.competicao+')':''}, ${fmtD(j.data,j.data_aprox)}.${gg.length?' Gols do Galo: '+gg.join(', ')+'.':''}`; };

/* ---------- Diário de jogos (estilo Letterboxd) e estádio ---------- */
let AVAL={};
async function carregaAval(){ if(!GDB) return; try{ const s=await GDB.collection('avaliacoes').limit(1000).get(); s.docs.forEach(d=>{ AVAL[d.id]=d.data(); }); }catch(e){} }
function diario(){ G.diario ||= {}; return G.diario; }
function blocoDiario(j){
  const d=diario()[j.id]||{}, e=j.escalacao_galo, pub=AVAL[j.id];
  const lineup=e?[...e.titulares, ...e.substituicoes.map(s=>s.entrou).filter(Boolean)]:[];
  setTimeout(()=>{ const f=$('#dform2'); if(!f) return;
    f.onsubmit=async(ev)=>{ ev.preventDefault(); const nota=+f.elements.nota.value||0, txt=f.elements.texto.value.trim().slice(0,1000), est=f.elements.est.checked, cr=f.elements.craque?f.elements.craque.value:'';
      const nj={}; lineup.forEach((n,i)=>{ const el=f.elements['nj'+i]; if(el&&el.value!=='') nj[n]=Math.max(0,Math.min(10,+el.value)); });
      if(!nota&&!txt&&!est&&!cr&&!Object.keys(nj).length){ delete diario()[j.id]; } else diario()[j.id]={n:nota, t:txt, est, cr, nj, d:hojeStr()};
      if(DONO&&f.elements.pub&&f.elements.pub.checked&&GDB){ try{ await GDB.doc('avaliacoes/'+j.id).set({n:nota, t:txt, cr, nj, em:Date.now()}); AVAL[j.id]={n:nota,t:txt,cr,nj}; }catch(err){ toast('A avaliação pública não foi salva agora.'); } }
      else if(DONO&&f.elements.pub&&!f.elements.pub.checked&&AVAL[j.id]&&GDB){ try{ await GDB.doc('avaliacoes/'+j.id).delete(); delete AVAL[j.id]; }catch(err){} }
      gSave(); checaConquistas(); toast('Salvo no seu diário.'); route.keep=true; route(); };
  });
  const media=pub&&pub.nj&&Object.keys(pub.nj).length?Object.entries(pub.nj).sort((a,b)=>b[1]-a[1]):null;
  const pubHTML=pub?`<div class="aval-pub"><span class="osw">Avaliação do Galo Metrics</span><b class="stars">${estrelas(pub.n)}</b>${pub.cr?`<span>Craque do jogo: <b>${esc(nomeV(pub.cr))}</b></span>`:''}${pub.t?`<p>${esc(pub.t)}</p>`:''}${media?`<p class="count">Notas: ${media.map(([n,v])=>`${esc(nomeV(n))} ${String(v).replace('.',',')}`).join(' · ')}</p>`:''}</div>`:'';
  const opt=[...Array(11)].map((_,i)=>i/2).map(v=>`<option value="${v||''}"${(d.n||0)===v?' selected':''}>${v?estrelas(v)+' ('+String(v).replace('.',',')+')':'Sem nota'}</option>`).join('');
  const meu=d.n||d.t||d.est||d.cr?`<p class="count">No seu diário: ${d.est?'<b>esteve no estádio</b> · ':''}${d.n?`<b class="stars">${estrelas(d.n)}</b> · `:''}${d.cr?`craque: ${esc(nomeV(d.cr))} · `:''}${d.t?`“${esc(d.t)}”`:''}</p><div style="display:flex;gap:8px;flex-wrap:wrap">${tw(`${d.est?'Eu estava lá! ':''}${resumoJogo(j)}${d.n?' Minha nota: '+estrelas(d.n)+'.':''}${d.cr?' Craque: '+nomeV(d.cr)+'.':''}${d.t?' '+d.t:''}`)}</div>`:'';
  return `${pubHTML}<details class="diario" ${d.n||d.est?'':''}><summary>★ Meu diário: avaliar este jogo${d.n||d.est?' (já avaliado)':''}</summary>
  <form id="dform2" class="dono">
  <div class="dgrid"><label>Nota do jogo<select name="nota">${opt}</select></label>
  <label class="chk"><input type="checkbox" name="est" ${d.est?'checked':''}> Eu estava no estádio</label></div>
  ${lineup.length?`<label>Craque do jogo<select name="craque"><option value="">Escolha</option>${lineup.map(n=>`<option value="${esc(n)}"${d.cr===n?' selected':''}>${esc(nomeV(n))}</option>`).join('')}</select></label>
  <p class="count" style="margin-top:12px">Notas para os jogadores do Galo (0 a 10, deixe em branco para não avaliar):</p>
  <div class="nj-grid">${lineup.map((n,i)=>`<label>${esc(nomeV(n))}<input type="number" name="nj${i}" min="0" max="10" step="0.5" value="${d.nj&&d.nj[n]!=null?d.nj[n]:''}"></label>`).join('')}</div>`:''}
  <label>Sua resenha<textarea name="texto" rows="3" maxlength="1000" style="width:100%" placeholder="O que você achou do jogo?">${esc(d.t||'')}</textarea></label>
  ${DONO?`<label class="chk"><input type="checkbox" name="pub" ${pub?'checked':''}> Publicar como avaliação do Galo Metrics (todos veem)</label>`:''}
  <button type="submit" class="more">Salvar no diário</button></form></details>${meu}`;
}
function statsEstadio(){
  const ids=Object.entries(diario()).filter(([id,x])=>x.est&&byId[id]).map(([id])=>byId[id]).sort((a,b)=>a.data<b.data?-1:1);
  const r=rec(ids.filter(j=>j.resultado)); const gols={}, est={}, adv={};
  ids.forEach(j=>{ j.gols.forEach(g=>{ if(g.lado==='galo'&&isGoal(g)) gols[g.jogador]=(gols[g.jogador]||0)+1; }); if(j.estadio) est[j.estadio]=(est[j.estadio]||0)+1; adv[j.adversario]=(adv[j.adversario]||0)+1; });
  const big=ids.filter(j=>j.resultado==='V').sort((a,b)=>(b.gp-b.gc)-(a.gp-a.gc))[0];
  return {ids, r, gols, est, adv, big};
}
function vDiario(){
  const D_=diario(), av=Object.entries(D_).filter(([id,x])=>byId[id]&&(x.n||x.t||x.cr)).map(([id,x])=>({j:byId[id],x})).sort((a,b)=>(b.x.d||'').localeCompare(a.x.d||'')||b.j.data.localeCompare(a.j.data));
  const S=statsEstadio(), ap=S.r.V+S.r.E+S.r.D?aprov(S.r):'–';
  const top=o=>Object.entries(o).sort((a,b)=>b[1]-a[1]);
  const notas={}; Object.entries(D_).forEach(([id,x])=>Object.entries(x.nj||{}).forEach(([n,v])=>{ (notas[n] ||= []).push(v); }));
  const medias=Object.entries(notas).map(([n,v])=>({n, m:v.reduce((s,a)=>s+a,0)/v.length, c:v.length})).sort((a,b)=>b.m-a.m||b.c-a.c);
  const crs={}; Object.values(D_).forEach(x=>{ if(x.cr) crs[x.cr]=(crs[x.cr]||0)+1; });
  const mediaJ=av.filter(a=>a.x.n).length?(av.filter(a=>a.x.n).reduce((s,a)=>s+a.x.n,0)/av.filter(a=>a.x.n).length):0;
  return `<div class="kicker">Ficha do torcedor</div><h1>Meu diário</h1>
  <p class="lede">Avalie jogos, dê nota aos jogadores e registre as partidas em que você esteve no estádio. Abra qualquer jogo e use "Meu diário".</p>
  ${secEstadio()}
  <h2>Minhas avaliações</h2>
  ${av.length?`<p class="count">${av.length} ${av.length===1?'jogo avaliado':'jogos avaliados'}${mediaJ?` · nota média ${estrelas(Math.round(mediaJ*2)/2)} (${mediaJ.toFixed(1).replace('.',',')})`:''}</p>
  <div class="aval-list">${av.map(({j,x})=>`<a class="aval-it" href="#jogo-${j.id}"><span class="mono uf">${fmtD(j.data,j.data_aprox)}</span><span>${linha(j)}</span><b class="stars">${estrelas(x.n)}</b>${x.est?'<span class="tag light">no estádio</span>':''}${x.t?`<p>“${esc(x.t)}”</p>`:''}</a>`).join('')}</div>`
  :`<p class="empty">Você ainda não avaliou jogos.</p>`}
  ${medias.length?`<div class="grid2"><div><h3>Suas maiores notas</h3><table><thead><tr><th>Jogador</th><th class="n">Média</th><th class="n">Jogos</th></tr></thead><tbody>${medias.slice(0,10).map(x=>`<tr><td><a href="#jogador-${slug(x.n)}">${esc(nomeV(x.n))}</a></td><td class="n"><b>${x.m.toFixed(1).replace('.',',')}</b></td><td class="n">${x.c}</td></tr>`).join('')}</tbody></table></div>
  <div><h3>Craques que você escolheu</h3><table><tbody>${top(crs).slice(0,10).map(([n,c])=>`<tr><td><a href="#jogador-${slug(n)}">${esc(nomeV(n))}</a></td><td class="n">${c}×</td></tr>`).join('')||'<tr><td>Nenhum ainda.</td></tr>'}</tbody></table></div></div>`:''}
  <p class="count">Seu diário fica salvo neste aparelho e entra no código de backup do álbum.</p>`;
}

/* ---------- Conquistas criadas pelo dono ---------- */
const TIPOS_CONQ=[
  ['jogadores_todos','Visitou todos estes jogadores','x','Nomes separados por vírgula: Mário de Castro, Jairo, Said'],
  ['jogadores_algum','Visitou pelo menos um destes jogadores','x','Nomes separados por vírgula'],
  ['paginas_todas','Visitou todas estas páginas','x','Endereços depois do #, separados por vírgula: jogo-5239, adversario-cruzeiro-mg'],
  ['figurinhas_todas','Tem todas estas figurinhas','x','Nomes separados por vírgula'],
  ['estadios_n','Esteve em N estádios diferentes','n','Conta os jogos marcados como "Eu estava no estádio"'],
  ['cidades_n','Viu o Galo em N cidades diferentes','n','Conta os jogos marcados como "Eu estava no estádio"'],
  ['vivo_n','Ganhou N figurinhas vendo jogadores ao vivo','n',''],
  ['jogo_aniversario','Visitou um jogo do dia do seu aniversário','','Usa o aniversário que a pessoa põe no Perfil'],
  ['jogo_ano_nasc','Visitou um jogo do ano em que nasceu','','Usa o ano de nascimento do Perfil'],
  ['jogador_chara','Visitou um jogador xará','','Compara com o primeiro nome que a pessoa põe no Perfil'],
  ['jogo_hoje','Visitou um jogo que aconteceu neste mesmo dia, em outro ano','',''],
  ['horario','Abriu o site entre duas horas','x','Faixa de horas, ex.: 0-5 (madrugada)'],
  ['goleada','Visitou um jogo em que o Galo fez N gols ou mais','n',''],
  ['jogo_antes','Visitou um jogo anterior ao ano N','n','Ex.: 1930'],
  ['estrangeiros','Visitou N adversários de fora do Brasil','n',''],
  ['jogos','Visitou N fichas de jogos','n',''],['jogadores','Visitou N jogadores','n',''],['adversarios','Visitou N adversários','n',''],
  ['dias','Entrou N dias seguidos','n',''],['figurinhas','Colou N figurinhas','n',''],['figurinha_de','Tem a figurinha do jogador X','x','Nome do jogador'],
  ['pagina','Visitou a página X','x','Endereço depois do #, ex.: jogo-5239'],['desafios','Venceu N desafios no total','n',''],['avaliacoes','Avaliou N jogos','n',''],
  ['estadio','Esteve em N jogos no estádio','n',''],['estadio_jogo','Esteve no estádio no jogo X','x','Número do jogo, ex.: 5239'],['palpites','Fez N palpites','n',''],['pontos','Somou N pontos no total','n','']];
const lista=x=>String(x||'').split(/[,;\n]/).map(s=>s.trim()).filter(Boolean);
const slugNome=n=>{ const p=D.jogadores.find(q=>q.nome.toLowerCase()===n.toLowerCase())||D.jogadores.find(q=>nomeV(q.nome).toLowerCase()===n.toLowerCase()); return p?slug(p.nome):slug(n); };
const visJogos=()=>Object.keys(G.vis.jogo||{}).map(id=>byId[id]).filter(Boolean);
function progressoCustom(c){ const v=+c.valor||1, x=c.param||'', pf=G.perfil||{};
  switch(c.tipo){
    case 'jogadores_todos': { const l=lista(x); return [l.filter(n=>G.vis.jogador[slugNome(n)]).length, l.length||1]; }
    case 'jogadores_algum': return [lista(x).some(n=>G.vis.jogador[slugNome(n)])?1:0,1];
    case 'paginas_todas': { const l=lista(x).map(s=>s.replace(/^#/,'')); return [l.filter(p=>(G.vis.pag||{})[p]).length, l.length||1]; }
    case 'figurinhas_todas': { const l=lista(x); const nm=n=>{ const p=D.jogadores.find(q=>q.nome.toLowerCase()===n.toLowerCase()||nomeV(q.nome).toLowerCase()===n.toLowerCase()); return p?p.nome:n; }; return [l.filter(n=>G.owned[nm(n)]).length, l.length||1]; }
    case 'estadios_n': return [new Set(vistoAoVivo().map(j=>j.estadio).filter(Boolean)).size, v];
    case 'cidades_n': return [new Set(vistoAoVivo().map(j=>j.cidade).filter(Boolean)).size, v];
    case 'vivo_n': return [Object.keys(G.vivo||{}).length, v];
    case 'jogo_aniversario': return [pf.aniv&&visJogos().some(j=>j.data.slice(5)===pf.aniv)?1:0,1];
    case 'jogo_ano_nasc': return [pf.ano&&visJogos().some(j=>j.temporada===+pf.ano)?1:0,1];
    case 'jogador_chara': { const nm=semAc(pf.nome||'').trim(); return [nm.length>=2&&Object.keys(G.vis.jogador).some(s=>{ const p=D.jogadores.find(q=>slug(q.nome)===s); return p&&semAc(nomeV(p.nome)).split(/\s+/).includes(nm); })?1:0,1]; }
    case 'jogo_hoje': return [(G.flags||{}).hoje?1:0,1];
    case 'horario': { const [h1,h2]=String(x).split('-').map(Number); const hs=Object.keys((G.flags||{}).horas||{}).map(Number); return [hs.some(h=>h1<=h2?h>=h1&&h<=h2:h>=h1||h<=h2)?1:0,1]; }
    case 'goleada': return [visJogos().some(j=>(j.gp||0)>=v)?1:0,1];
    case 'jogo_antes': return [visJogos().some(j=>j.temporada<v)?1:0,1];
    case 'estrangeiros': return [Object.keys(G.vis.adversario).filter(s=>{ const a=advRows().find(r=>slug(r.id)===s); return a&&a.uf&&a.uf.length===3; }).length, v];
    case 'jogos': return [cnt(G.vis.jogo),v]; case 'jogadores': return [cnt(G.vis.jogador),v]; case 'adversarios': return [cnt(G.vis.adversario),v];
    case 'dias': return [G.seq.max,v]; case 'figurinhas': return [cnt(G.owned),v]; case 'figurinha_de': return [G.owned[x]||Object.keys(G.owned).some(n=>nomeV(n).toLowerCase()===x.toLowerCase())?1:0,1];
    case 'pagina': return [(G.vis.pag||{})[x.replace(/^#/,'')]?1:0,1];
    case 'desafios': return [Object.values(G.jd).reduce((s,d)=>s+Object.values(d).filter(y=>y&&y.ok).length,0),v];
    case 'avaliacoes': return [Object.values(diario()).filter(y=>y.n||y.t).length,v];
    case 'estadio': return [Object.values(diario()).filter(y=>y.est).length,v];
    case 'estadio_jogo': return [(diario()[x]||{}).est?1:0,1];
    case 'palpites': return [Object.values(G.palpites||{}).filter(p=>p.gp!=null).length,v];
    case 'pontos': return [G.total,v];
  } return [0,1]; }
function todasConq(){ return CONQ.concat((CFG.conquistas||[]).map(c=>({id:'c_'+c.id, nome:c.nome, desc:c.desc, pts:+c.pts||0, secreta:!!c.secreta, p:()=>progressoCustom(c), custom:true}))); }
function donoConquistas(){
  const L=CFG.conquistas||[];
  const tipoInfo=k=>TIPOS_CONQ.find(t=>t[0]===k)||['','','',''];
  setTimeout(()=>{ const b=$('#cqadd'); if(!b) return;
    const ajusta=()=>{ const t=tipoInfo($('#cq_tipo').value); $('#cq_lx').style.display=t[2]==='x'?'':'none'; $('#cq_ln').style.display=t[2]==='n'?'':'none'; $('#cq_hint').textContent=t[3]||''; };
    $('#cq_tipo').onchange=ajusta; ajusta();
    b.onclick=async()=>{ const v=k=>(($('#cq_'+k)||{}).value||'').trim(); const m=$('#cqmsg'); const t=tipoInfo(v('tipo'));
      if(!v('nome')){ m.textContent='Dê um nome para a conquista.'; return; }
      if(t[2]==='x'&&!v('param')){ m.textContent='Preencha o campo X para esse tipo.'; return; }
      if(['jogadores_todos','jogadores_algum','figurinhas_todas'].includes(t[0])){ const faltam=lista(v('param')).filter(n=>!D.jogadores.some(q=>q.nome.toLowerCase()===n.toLowerCase()||nomeV(q.nome).toLowerCase()===n.toLowerCase())); if(faltam.length){ m.textContent='Não achei na base: '+faltam.join(', ')+'. Confira a grafia.'; return; } }
      const c=JSON.parse(JSON.stringify(CFG)); c.conquistas=(c.conquistas||[]).concat([{id:Date.now().toString(36), nome:v('nome'), desc:v('desc'), pts:+v('pts')||10, secreta:$('#cq_sec').checked, tipo:t[0], valor:+v('valor')||1, param:v('param')}]);
      await salvaCfg(c); };
    document.querySelectorAll('[data-cqdel]').forEach(x=>x.onclick=async()=>{ const c=JSON.parse(JSON.stringify(CFG)); c.conquistas=(c.conquistas||[]).filter(y=>y.id!==x.dataset.cqdel); await salvaCfg(c); }); });
  return `<h2>Conquistas criadas por você</h2>
  ${L.length?`<table><tbody>${L.map(c=>{ const t=tipoInfo(c.tipo); return `<tr><td><b>${esc(c.nome)}</b>${c.secreta?' <span class="tag light">secreta</span>':''}<br><small class="uf">${esc(c.desc||'')}${c.desc?' · ':''}${esc(t[1])}${t[2]==='x'?': '+esc(c.param):t[2]==='n'?' (N = '+c.valor+')':''} · +${c.pts} pts</small></td><td><button type="button" class="ghost" data-cqdel="${esc(c.id)}">Apagar</button></td></tr>`; }).join('')}</tbody></table>`:'<p class="count">Nenhuma ainda.</p>'}
  <div class="dono"><div class="dgrid"><label>Nome<input id="cq_nome" placeholder="Ex.: Trio maldito"></label><label>Descrição<input id="cq_desc" placeholder="Ex.: Visitou Mário de Castro, Jairo e Said"></label>
  <label>Regra<select id="cq_tipo">${TIPOS_CONQ.map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select></label>
  <label id="cq_ln">N (quantidade)<input id="cq_valor" type="number" min="1" value="10"></label>
  <label id="cq_lx">X<input id="cq_param" placeholder="Mário de Castro, Jairo, Said"></label>
  <label>Pontos<input id="cq_pts" type="number" min="0" value="20"></label></div>
  <p id="cq_hint" class="count"></p>
  <label class="chk"><input type="checkbox" id="cq_sec"> Secreta: o nome e a descrição só aparecem depois que a pessoa conquista</label>
  <p id="cqmsg" class="count" role="status"></p><button type="button" class="more" id="cqadd">Adicionar conquista</button></div>`;
}

const contaMarc=m=>{ const c={}; (m||[]).forEach(n=>{ c[n]=(c[n]||0)+1; }); return Object.entries(c).map(([n,k])=>nomeV(n)+(k>1?` (${k})`:'')).join(', '); };

/* ---------- Público: pessoas que o Galo levou ao estádio ---------- */
const ehMandante=j=>j.galo_mandante===true||(j.galo_mandante==null&&j.mando==='C');
let _pubC=null;
function publicoTot(){
  if(_pubC) return _pubC;
  const com=J.filter(j=>j.resultado&&j.publico>0), casa=com.filter(ehMandante);
  const soma=l=>l.reduce((a,j)=>a+j.publico,0);
  const dec={}; com.forEach(j=>{ const d=Math.floor(+j.data.slice(0,4)/10)*10; const x=(dec[d] ||= {g:0,gn:0,c:0,cn:0}); x.g+=j.publico; x.gn++; if(ehMandante(j)){ x.c+=j.publico; x.cn++; } });
  return _pubC={geral:soma(com), gn:com.length, casa:soma(casa), cn:casa.length, dec, desde:com.length?com[0].data:null,
    topCasa:[...casa].sort((a,b)=>b.publico-a.publico).slice(0,10)};
}
function blocoPublico(det){
  const P=publicoTot(); if(!P.gn) return '';
  const med=(s,n)=>n?N(Math.round(s/n)):'–';
  return `<h2>Pessoas que o Galo levou ao estádio</h2>
  <div class="tiles"><div class="tile"><b>${N(P.geral)}</b><span>Público total, todos os jogos</span></div>
  <div class="tile"><b>${N(P.casa)}</b><span>Como mandante</span></div>
  <div class="tile"><b>${med(P.geral,P.gn)}</b><span>Média por jogo</span></div>
  <div class="tile"><b>${med(P.casa,P.cn)}</b><span>Média como mandante</span></div></div>
  <p class="count">Soma do público registrado nas fichas (pagantes ou presentes, como cada ficha informa) em ${N(P.gn)} jogos, ${N(P.cn)} deles com o Galo mandante. Jogos sem público informado ficam de fora, então o número real é maior.</p>
  ${det?`<table><thead><tr><th>Década</th><th class="n">Público total</th><th class="n hide-s">Jogos</th><th class="n">Como mandante</th><th class="n">Média mandante</th></tr></thead><tbody>${Object.entries(P.dec).map(([d,x])=>`<tr><td class="mono">${d}s</td><td class="n mono">${N(x.g)}</td><td class="n mono hide-s">${N(x.gn)}</td><td class="n mono">${N(x.c)}</td><td class="n mono">${med(x.c,x.cn)}</td></tr>`).join('')}</tbody></table>`:`<a href="#recordes" class="more">Público por década e maiores casas cheias →</a>`}`;
}
/* ---------- Campinho ---------- */
function linhasCampo(tit, form){
  if(form&&FORMS[form]){ const F=FORMS[form]; const out=[]; let k=0; F.forEach(n=>{ out.push(tit.slice(k,k+n)); k+=n; }); return out; }
  const L={Goleiro:[],Defensor:[],Meia:[],Atacante:[]}; tit.forEach((n,i)=>{ let p=posTxt(n)||(i===0?'Goleiro':'Meia'); if(p==='Goleiro'&&L.Goleiro.length) p='Defensor'; L[p].push(n); });
  if(!L.Goleiro.length&&tit.length) L.Goleiro.push(L.Defensor.shift()||tit[0]);
  return [L.Goleiro,L.Defensor,L.Meia,L.Atacante].filter(x=>x.length);
}
function campoHTML(tit, extra={}){
  const ls=linhasCampo(tit, extra.form);
  return `<div class="campo" role="img" aria-label="Escalação em campo: ${esc(tit.map(nomeV).join(', '))}">${ls.slice().reverse().map(l=>`<div class="campo-l">${l.map(n=>{ const g=(extra.gols||{})[n]||0, nt=(extra.notas||{})[n];
    return `<div class="campo-p${extra.craque===n?' craque':''}"><span class="campo-dot" aria-hidden="true">${extra.craque===n?'★':''}</span><a href="#jogador-${slug(n)}">${esc(nomeV(n))}</a>${g?`<span class="campo-g">${'⚽'.repeat(Math.min(g,4))}</span>`:''}${nt!=null?`<span class="campo-n">${String(nt).replace('.',',')}</span>`:''}</div>`; }).join('')}</div>`).join('')}</div>`;
}

/* ---------- Palpites para jogos que ainda não aconteceram ---------- */
function palp(){ G.palpites ||= {}; return G.palpites; }
function kickoff(j){ const x=(D.proximo||{})[j.id]||{}; const m=String(x.hora||'').match(/(\d{1,2})\s*h\s*(\d{2})?/); const h=m?+m[1]:12, mi=m&&m[2]?+m[2]:0; return new Date(`${j.data}T${String(h).padStart(2,'0')}:${String(mi).padStart(2,'0')}:00-03:00`); }
const palpAberto=j=>!j.resultado&&new Date()<kickoff(j);
function candidatos(){ const ult=J.filter(j=>j.resultado&&j.escalacao_galo&&j.escalacao_galo.titulares.length).slice(-25); const c={};
  ult.forEach(j=>{ const e=j.escalacao_galo; [...e.titulares, ...e.substituicoes.map(s=>s.entrou)].forEach(n=>{ if(n) c[n]=(c[n]||0)+(e.titulares.includes(n)?2:1); }); });
  const L=Object.keys(c).sort((a,b)=>c[b]-c[a]); const por={}; POSS.forEach(p=>por[p]=[]); L.forEach(n=>{ const p=posTxt(n)||'Meia'; (por[p] ||= []).push(n); }); return {L, por}; }
const FORMS={'2-3-5':[1,2,3,5],'4-3-3':[1,4,3,3],'4-4-2':[1,4,4,2],'4-2-3-1':[1,4,5,1],'3-5-2':[1,3,5,2],'5-3-2':[1,5,3,2]};
function pontuaPalpite(j,p){
  if(!j.resultado||j.gp==null||p.gp==null) return null;
  const r={placar:0, res:0, marc:0, esc:0, det:[]};
  if(p.gp===j.gp&&p.gc===j.gc){ r.placar=10; r.det.push('placar exato +10'); }
  else if(Math.sign(p.gp-p.gc)===Math.sign(j.gp-j.gc)){ r.res=5; r.det.push('resultado certo +5'); }
  const marcou=new Set(j.gols.filter(g=>g.lado==='galo'&&isGoal(g)).map(g=>g.jogador));
  const real={}; j.gols.filter(g=>g.lado==='galo'&&isGoal(g)).forEach(g=>{ real[g.jogador]=(real[g.jogador]||0)+1; }); const chute={}; (p.marc||[]).forEach(n=>{ chute[n]=(chute[n]||0)+1; });
  Object.entries(chute).forEach(([n,c])=>{ r.marc+=3*Math.min(c, real[n]||0); }); if(r.marc) r.det.push(`gols certos +${r.marc}`);
  const tit=j.escalacao_galo?new Set(j.escalacao_galo.titulares):null;
  if(tit&&tit.size){ (p.esc||[]).forEach(n=>{ if(tit.has(n)) r.esc++; }); if(r.esc) r.det.push(`escalação ${r.esc}/11 +${r.esc}`); }
  r.total=r.placar+r.res+r.marc+r.esc; return r;
}
function pagaPalpites(){ let ganhou=0; Object.entries(palp()).forEach(([id,p])=>{ const j=byId[id]; if(!j||p.pago) return; const r=pontuaPalpite(j,p); if(!r) return; p.pago=true; p.res=r; if(r.total){ G.pts+=r.total; G.total+=r.total; G.hist.unshift({d:Date.now(), n:r.total, m:'palpite: '+j.adversario}); ganhou+=r.total; } });
  if(ganhou){ gSave(); atualizaChip(); toast(`+${ganhou} pontos pelos seus palpites`); } }
function blocoPalpite(j){
  const p=palp()[j.id]||{}, aberto=palpAberto(j);
  if(j.resultado){ if(p.gp==null) return ''; const r=pontuaPalpite(j,p);
    return `<div class="aval-pub"><span class="osw">Seu palpite</span><b>Atlético ${p.gp} x ${p.gc} ${esc(j.adversario)}</b>${(p.marc||[]).length?`<span>Marcadores: ${esc(contaMarc(p.marc))}</span>`:''}${r?`<span>Resultado: <b>${r.total} pontos</b>${r.det.length?' ('+r.det.join(', ')+')':''}</span>`:''}</div>`; }
  const C=candidatos(), form=p.form||'4-3-3', F=FORMS[form];
  setTimeout(()=>{ const f=$('#pform'); if(!f) return;
    f.elements.form.onchange=()=>{ const q=palp()[j.id]||{}; q.form=f.elements.form.value; palp()[j.id]=q; gSave(); route.keep=true; route(); };
    f.onsubmit=ev=>{ ev.preventDefault(); if(!palpAberto(j)){ toast('Os palpites deste jogo já fecharam.'); return; }
      const gp=f.elements.gp.value, gc=f.elements.gc.value; if(gp===''||gc===''){ $('#perr').textContent='Preencha o placar dos dois lados.'; return; }
      const esc_=[...f.querySelectorAll('[data-slot]')].map(s=>s.value).filter(Boolean);
      if(new Set(esc_).size!==esc_.length){ $('#perr').textContent='Tem jogador repetido na escalação.'; return; }
      const marc=[...f.querySelectorAll('[data-gol]')].map(s=>s.value).filter(Boolean).slice(0,+gp);
      palp()[j.id]={gp:+gp, gc:+gc, marc, esc:esc_, form:f.elements.form.value, em:Date.now()};
      gSave(); checaConquistas(); toast('Palpite salvo.'); route.keep=true; route(); };
    const optsG=`<option value="">Não sei</option>${C.L.map(n=>`<option value="${esc(n)}">${esc(nomeV(n))}${posTxt(n)?' · '+posTxt(n):''}</option>`).join('')}`;
    const desenhaGols=()=>{ const box=$('#plgols'); if(!box) return; const n=Math.max(0,Math.min(10,+f.elements.gp.value||0)); const atuais=[...box.querySelectorAll('select')].map(s=>s.value); const base=atuais.length?atuais:(p.marc||[]);
      box.innerHTML=n?[...Array(n)].map((_,i)=>`<label>${i+1}º gol<select data-gol="${i}" ${aberto?'':'disabled'}>${optsG}</select></label>`).join(''):'<p class="count">Com 0 gols do Galo, não tem marcador.</p>';
      box.querySelectorAll('select').forEach((s,i)=>{ s.value=base[i]||''; }); };
    desenhaGols(); f.elements.gp.oninput=desenhaGols;
    f.querySelectorAll('[data-slot]').forEach(s=>s.onchange=()=>{ const v=[...f.querySelectorAll('[data-slot]')].map(x=>x.value); f.querySelectorAll('[data-slot]').forEach(x=>{ x.classList.toggle('dup', !!x.value&&v.filter(y=>y===x.value).length>1); }); });
  });
  const linhas=['Goleiro','Defensor','Meia','Atacante']; let k=0;
  const slots=F.map((n,li)=>`<div class="pl-linha"><span class="osw">${['Gol','Defesa','Meio','Ataque'][li]}</span>${[...Array(n)].map(()=>{ const i=k++; const pri=C.por[linhas[li]]||[]; const opts=[...pri, ...C.L.filter(x=>!pri.includes(x))];
    return `<select data-slot="${i}" aria-label="${linhas[li]} ${i+1}" ${aberto?'':'disabled'}><option value="">—</option>${opts.map(o=>`<option value="${esc(o)}"${(p.esc||[])[i]===o?' selected':''}>${esc(nomeV(o))}</option>`).join('')}</select>`; }).join('')}</div>`).reverse().join('');
  const salvo=p.gp!=null;
  return `<section class="palpite"><h2 style="margin-top:0">★ Meu palpite</h2>
  ${aberto?`<p class="count">Fecha ${kickoff(j).toLocaleString('pt-BR',{weekday:'long',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}. Placar exato vale 10 pontos, acertar o vencedor ou o empate vale 5, cada gol com o autor certo 3 e cada titular certo 1.</p>`:'<p class="count">Os palpites deste jogo estão fechados. Os pontos entram quando o resultado for lançado.</p>'}
  <form id="pform" class="dono">
  <div class="pl-placar"><label>Atlético<input type="number" name="gp" min="0" max="15" value="${p.gp??''}" ${aberto?'':'disabled'}></label><span class="pl-x">×</span><label>${esc(j.adversario)}<input type="number" name="gc" min="0" max="15" value="${p.gc??''}" ${aberto?'':'disabled'}></label></div>
  <div class="pl-gols"><span class="osw">Quem marca os gols do Galo</span><div id="plgols"></div><p class="count">Uma linha por gol do seu placar. Pode repetir o jogador para doblete ou hat-trick.</p></div>
  <label>Esquema<select name="form" ${aberto?'':'disabled'}>${Object.keys(FORMS).map(f=>`<option${f===form?' selected':''}>${f}</option>`).join('')}</select></label>
  <div class="pl-campo">${slots}</div>
  <p id="perr" class="count" role="alert" style="color:var(--d)"></p>
  ${aberto?`<button type="submit" class="more">${salvo?'Atualizar palpite':'Salvar palpite'}</button>`:''}
  </form>
  ${salvo&&(p.esc||[]).length?`<h3>Seu time no campinho</h3>${campoHTML(p.esc,{form:p.form, gols:(p.marc||[]).reduce((m,n)=>(m[n]=(m[n]||0)+1,m),{})})}`:''}
  ${salvo?`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">${tw(`Meu palpite: Atlético ${p.gp} x ${p.gc} ${j.adversario}${(p.marc||[]).length?'. Gols de '+contaMarc(p.marc):''}.`)}${artBtn({t:'palpite', id:j.id})}</div>`:''}</section>`;
}
function vPalpites(){
  const fut=J.filter(j=>!j.resultado&&j.data>=hojeStr()).slice(0,6);
  const ant=Object.entries(palp()).filter(([id,p])=>byId[id]&&byId[id].resultado&&p.gp!=null).map(([id,p])=>({j:byId[id],p,r:pontuaPalpite(byId[id],p)})).sort((a,b)=>b.j.data.localeCompare(a.j.data));
  const tot=ant.reduce((s,x)=>s+(x.r?x.r.total:0),0), exatos=ant.filter(x=>x.r&&x.r.placar).length;
  return `<div class="kicker">Jogar</div><h1>Palpites</h1><p class="lede">Chute placar, marcadores e escalação dos próximos jogos. Quando o resultado sai, os pontos vão para o seu álbum.</p>
  <h2>Próximos jogos</h2>${fut.length?`<table><tbody>${fut.map(j=>{ const p=palp()[j.id]; return `<tr class="click" onclick="location.hash='jogo-${j.id}'"><td class="mono">${fmtD(j.data)}</td><td>${linha(j)}</td><td>${esc(j.competicao||'')}</td><td>${p&&p.gp!=null?`<b>seu palpite: ${p.gp} x ${p.gc}</b>`:palpAberto(j)?'<span class="tag">Palpitar</span>':'fechado'}</td></tr>`; }).join('')}</tbody></table>`:'<p class="empty">Nenhum jogo futuro na base. Quando o dono cadastrar o próximo jogo, ele aparece aqui.</p>'}
  <h2>Meus palpites</h2>${ant.length?`<div class="tiles"><div class="tile"><b>${ant.length}</b><span>Palpites</span></div><div class="tile"><b>${exatos}</b><span>Placares exatos</span></div><div class="tile"><b>${tot}</b><span>Pontos</span></div></div>
  <table><thead><tr><th>Jogo</th><th>Palpite</th><th class="n">Pontos</th></tr></thead><tbody>${ant.map(x=>`<tr class="click" onclick="location.hash='jogo-${x.j.id}'"><td>${linha(x.j)}</td><td class="mono">${x.p.gp} x ${x.p.gc}</td><td class="n"><b>${x.r?x.r.total:'–'}</b></td></tr>`).join('')}</tbody></table>`:'<p class="empty">Os palpites aparecem aqui depois que os jogos acontecem.</p>'}`;
}

/* ---------- Artes para o Twitter (1200×675) ---------- */
const artBtn=spec=>`<button type="button" class="ghost" data-arte="${esc(JSON.stringify(spec))}">Baixar arte</button>`;
async function desenhaArte(s){
  const W=1200,H=675,P=60, cv=document.createElement('canvas'); cv.width=W; cv.height=H; const x=cv.getContext('2d');
  await Promise.all(['400 80px "Abril Fatface"','700 40px Oswald','700 30px "Courier Prime"','400 30px "Libre Caslon Text"'].map(f=>document.fonts.load(f).catch(()=>{})));
  const INK='#111', PAP='#F5F2EA', GOLD='#C9962B';
  const F=(f,sz)=>({abril:`400 ${sz}px "Abril Fatface", Georgia, serif`, osw:`700 ${sz}px Oswald, Archivo, sans-serif`, mono:`700 ${sz}px "Courier Prime", monospace`, cas:`400 ${sz}px "Libre Caslon Text", Georgia, serif`}[f]);
  const T=(t,px,py,f,sz,c=INK,al='left',max=0)=>{ x.font=F(f,sz); if(max) while(sz>14&&x.measureText(t).width>max){ sz-=2; x.font=F(f,sz); } x.fillStyle=c; x.textAlign=al; x.textBaseline='alphabetic'; x.fillText(t,px,py); return x.measureText(t).width; };
  const Tm=(t,px,py,sz,max,al='left')=>{ x.font=F('abril',sz); while(sz>20&&x.measureText(t).width>max){ sz-=2; x.font=F('abril',sz); } x.textAlign=al; x.textBaseline='alphabetic'; x.fillStyle='rgba(201,150,43,.8)'; x.fillText(t,px+5,py+4); x.fillStyle=INK; x.fillText(t,px,py); return sz; };
  x.fillStyle=PAP; x.fillRect(0,0,W,H);
  x.fillStyle='rgba(17,17,17,.06)'; for(let i=0;i<W;i+=7) for(let k=0;k<H;k+=7) x.fillRect(i,k,1.2,1.2);
  x.fillStyle=INK; x.fillRect(0,0,W,3); for(let i=0;i<W;i+=36) x.fillRect(i,3,18,18); x.fillRect(0,21,W,3);
  x.fillStyle=INK; x.fillRect(0,H-70,W,70); T('GALO METRICS',P,H-24,'abril',34,PAP); T('A história do Galo em números · #GaloMetrics',W-P,H-27,'mono',18,GOLD,'right');
  const crest=async(id,cx,cy,sz)=>{ const im=await loadImg(escSrc(id)); if(im) cvImg(x,im,cx-sz/2,cy-sz/2,sz,sz); };
  const carimbo=(t,cx,cy,rot=-0.12)=>{ x.save(); x.translate(cx,cy); x.rotate(rot); x.font=F('abril',34); const w=x.measureText(t).width+36; x.strokeStyle=GOLD; x.lineWidth=5; x.strokeRect(-w/2,-30,w,58); x.lineWidth=2; x.strokeRect(-w/2+7,-23,w-14,44); x.fillStyle=GOLD; x.textAlign='center'; x.fillText(t,0,14); x.restore(); };
  if(s.t==='jogo'||s.t==='palpite'){
    const j=byId[s.id]; const isP=s.t==='palpite'; const d=isP?(palp()[j.id]||{}):(diario()[j.id]||{});
    const tit=isP?(d.esc||[]):((j.escalacao_galo&&j.escalacao_galo.titulares)||[]);
    const temCampo=tit.length>=7, LW=temCampo?640:W;
    const gL=j.galo_mandante!=null?j.galo_mandante:j.mando!=='F', L=gL?'galo':j.adversario_id, R=gL?j.adversario_id:'galo';
    T(isP?'MEU PALPITE':(d.est?'EU ESTAVA LÁ':'MEU JOGO'),P,72,'osw',24,GOLD);
    T(`${(j.competicao||'').toUpperCase()}${j.fase?' · '+j.fase.toUpperCase():''} · ${fmtD(j.data,j.data_aprox)}`,P,104,'osw',22,INK,'left',LW-2*P);
    const cxL=temCampo?P+80:P+110, cxR=temCampo?LW-80:W-P-110, csz=temCampo?120:160;
    await crest(L,cxL,210,L==='galo'?csz:csz*0.82); await crest(R,cxR,210,R==='galo'?csz:csz*0.82);
    const gp=isP?d.gp:j.gp, gc=isP?d.gc:j.gc;
    Tm(gp==null?'×':(gL?`${gp} – ${gc}`:`${gc} – ${gp}`),(cxL+cxR)/2,255,temCampo?110:150,temCampo?260:420,'center');
    T(gL?'ATLÉTICO':j.adversario.toUpperCase(),cxL,310,'osw',temCampo?24:32,INK,'center',200); T(gL?j.adversario.toUpperCase():'ATLÉTICO',cxR,310,'osw',temCampo?24:32,INK,'center',200);
    const marc=isP?contaMarc(d.marc):j.gols.filter(g=>g.lado==='galo').map(g=>`${nomeV(g.jogador)}${g.minuto!=null?' '+g.minuto+"'":''}`).join(' · ');
    let yy=360; if(marc){ T((isP?'Gols de ':'Gols: ')+marc,temCampo?P:W/2,yy,'mono',20,INK,temCampo?'left':'center',LW-2*P); yy+=48; }
    if(!isP){
      if(d.n){ T('★'.repeat(Math.floor(d.n))+(d.n%1?'½':''),temCampo?P:W/2,yy+20,'cas',50,GOLD,temCampo?'left':'center'); yy+=62; }
      if(d.cr){ T('Craque do jogo: '+nomeV(d.cr),temCampo?P:W/2,yy,'osw',24,INK,temCampo?'left':'center',LW-2*P); yy+=36; }
      if(d.t){ x.font=F('cas',20); const ws=('“'+d.t+'”').split(/\s+/); let ln='', n=0; for(const w of ws){ const t2=ln?ln+' '+w:w; if(x.measureText(t2).width>LW-2*P&&ln){ T(ln,temCampo?P:W/2,yy,'cas',20,INK,temCampo?'left':'center'); yy+=28; ln=w; if(++n>=3){ ln+='…'; break; } } else ln=t2; } if(ln&&yy<H-90) T(ln,temCampo?P:W/2,yy,'cas',20,INK,temCampo?'left':'center'); }
      if(!d.n&&!d.cr&&!d.t&&!d.est) T('Avalie este jogo no Galo Metrics',temCampo?P:W/2,yy+10,'cas',22,'#6b665c',temCampo?'left':'center');
      if(d.est) carimbo('EU FUI!',temCampo?LW-120:W-200,temCampo?78:150,0.1);
    } else carimbo('PALPITE',temCampo?LW-120:W-190,temCampo?78:150,0.1);
    if(temCampo){
      const X0=660,Y0=40,PW=W-X0-30,PH=H-70-Y0-20;
      x.fillStyle='#E6E0CF'; x.fillRect(X0,Y0,PW,PH); for(let i=0;i<6;i++){ if(i%2){ x.fillStyle='#DDD6C2'; x.fillRect(X0,Y0+i*PH/6,PW,PH/6); } }
      x.strokeStyle=INK; x.lineWidth=3; x.strokeRect(X0,Y0,PW,PH); x.beginPath(); x.moveTo(X0,Y0+PH/2); x.lineTo(X0+PW,Y0+PH/2); x.stroke(); x.beginPath(); x.arc(X0+PW/2,Y0+PH/2,46,0,Math.PI*2); x.stroke();
      x.strokeRect(X0+PW/2-90,Y0+PH-60,180,60); x.strokeRect(X0+PW/2-90,Y0,180,60);
      const gols={}; (isP?(d.marc||[]):j.gols.filter(g=>g.lado==='galo'&&isGoal(g)).map(g=>g.jogador)).forEach(n=>{ gols[n]=(gols[n]||0)+1; });
      const ls=linhasCampo(tit, isP?d.form:null); const nl=ls.length;
      ls.forEach((l,li)=>{ const yP=Y0+PH-48-li*((PH-96)/Math.max(1,nl-1)); l.forEach((n,pi)=>{ const xP=X0+PW*(pi+1)/(l.length+1);
        x.beginPath(); x.arc(xP,yP-10,13,0,Math.PI*2); x.fillStyle=(!isP&&d.cr===n)?GOLD:INK; x.fill(); x.strokeStyle=PAP; x.lineWidth=3; x.stroke();
        T(nomeV(n).toUpperCase(),xP,yP+20,'osw',15,INK,'center',PW/(l.length+0.5));
        const extra=[(gols[n]?'⚽'.repeat(Math.min(3,gols[n])):''),(!isP&&d.nj&&d.nj[n]!=null?String(d.nj[n]).replace('.',','):'')].filter(Boolean).join(' ');
        if(extra) T(extra,xP,yP+40,'mono',14,'#8C6610','center'); }); });
    }
  }
  if(s.t==='estadio'){
    const S=statsEstadio(); T('FICHA DO TORCEDOR',P,80,'osw',24,GOLD); Tm('Fui ao estádio',P,170,92,W-2*P);
    const cols=[['JOGOS',S.ids.length,INK],['VITÓRIAS',S.r.V,'#1f7a43'],['EMPATES',S.r.E,'#b8860b'],['DERROTAS',S.r.D,'#c0392b'],['APROV.',S.r.V+S.r.E+S.r.D?aprov(S.r):'–',INK]];
    const cw=(W-2*P)/5; cols.forEach(([l,v,c],i)=>{ T(String(v),P+i*cw,300,'abril',96,c,'left',cw-20); T(l,P+i*cw,340,'osw',22,INK); });
    const top=Object.entries(S.gols).sort((a,b)=>b[1]-a[1])[0];
    T(`${S.r.gp} gols do Galo vistos${top?` · quem mais vi marcar: ${nomeV(top[0])} (${top[1]})`:''}`,P,420,'cas',28,INK,'left',W-2*P);
    if(S.big) T(`Maior vitória que vi: Atlético ${placar(S.big)} ${S.big.adversario} (${fmtD(S.big.data)})`,P,465,'cas',24,INK,'left',W-2*P);
    if(S.ids.length>=5) carimbo(pct(S.r)>=0.6?'PÉ-QUENTE':pct(S.r)<0.4?'PÉ-FRIO':'FIEL',W-230,150,0.12);
  }
  if(s.t==='desafio'){
    T('DESAFIO DO DIA · '+fmtD(hojeStr()),P,80,'osw',24,GOLD); Tm(s.nome,P,175,96,s.grade?W-2*P-330:W-2*P);
    Tm(String(s.res),P,330,120,W-2*P-(s.grade?330:0));
    if(s.grade){ s.grade.split('\n').forEach((r,ri)=>[...r].forEach((c,ci)=>{ x.fillStyle=c==='v'?'#2f7d47':c==='a'?'#D9A21B':'#555'; x.fillRect(W-P-5*58+ci*58,70+ri*58,50,50); })); }
    T((G.perfil&&G.perfil.apelido)||'',P,420,'osw',30,INK);
    carimbo(s.ok?'VENCI!':'AMANHÃ TEM MAIS',W-260,530,-0.08);
  }
  return cv;
}
async function abreArte(spec){
  const box=document.createElement('div'); box.className='gm-achou'; box.setAttribute('role','dialog'); box.setAttribute('aria-label','Arte para o Twitter');
  box.innerHTML=`<div class="gm-achou-in arte-in"><p class="osw">Preparando a arte…</p></div>`; document.body.appendChild(box);
  const fecha=()=>box.remove(); box.onclick=e=>{ if(e.target===box) fecha(); };
  try{ const cv=await desenhaArte(spec); const url=cv.toDataURL('image/png');
    box.querySelector('.arte-in').innerHTML=`<p class="osw">Arte pronta para o Twitter</p><img src="${url}" alt="Prévia da arte" class="arte-img"><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center"><button type="button" class="more" id="artdl">Baixar PNG</button><button type="button" class="ghost" id="artfx">Fechar</button></div><p class="count">Baixe a imagem e anexe no tweet. Se o download não abrir, clique com o botão direito (ou toque e segure) na imagem para salvar.</p>`;
    box.querySelector('#artfx').onclick=fecha; box.querySelector('#artdl').focus();
    box.querySelector('#artdl').onclick=async()=>{ const nome=`galo-metrics-${spec.t}.png`; const blob=await (await fetch(url)).blob();
      const dl = window.claude&&window.claude.use ? await window.claude.use('downloads').catch(()=>null) : null;
      if(dl){ try{ await dl.save({filename:nome, data:blob}); toast('Arte salva.'); }catch(e){ if(!(e&&e.code==='declined')) toast('Não deu para baixar aqui. Salve pela imagem.'); } }
      else { const a=document.createElement('a'); a.href=url; a.download=nome; document.body.appendChild(a); a.click(); a.remove(); } };
  }catch(e){ console.error(e); box.querySelector('.arte-in').innerHTML='<p>Não foi possível gerar a arte.</p>'; }
}
document.addEventListener('click',e=>{ const b=e.target.closest&&e.target.closest('[data-arte]'); if(!b) return; e.preventDefault(); let s; try{ s=JSON.parse(b.dataset.arte); }catch(err){ return; }
  if(s.t==='jogo'&&!(diario()[s.id]||{}).n&&!(diario()[s.id]||{}).est){ const d=document.querySelector('details.diario'); toast('Dica: avalie o jogo em "Meu diário" para a nota, o craque e o carimbo aparecerem na arte.'); if(d) d.open=true; }
  abreArte(s); });
document.addEventListener('click',e=>{ document.querySelectorAll('#nav details[open]').forEach(d=>{ if(!d.contains(e.target)) d.removeAttribute('open'); }); });

function route(){
  try{ sincronizaVivo(); }catch(e){}
  const raw=(location.hash||'#inicio').slice(1); const [h0,params]=raw.split('?'); const h=decodeURIComponent(h0); let html, sec=h.split('-')[0];
  if(h==='inicio') html=vInicio();
  else if(h==='jogos') html=vJogos(params);
  else if(h.startsWith('jogo-')) {html=vJogo(+h.slice(5)); sec='jogos';}
  else if(h==='jogadores') html=vJogadores();
  else if(h.startsWith('jogador-')) {html=vJogador(h.slice(8)); sec='jogadores';}
  else if(h==='adversarios') html=vAdversarios();
  else if(h.startsWith('adversario-')) {html=vAdversario(h.slice(11)); sec='adversarios';}
  else if(h==='temporadas') html=vTemporadas();
  else if(h.startsWith('temporada-')) {html=vTemporada(h.slice(10)); sec='temporadas';}
  else if(h==='tecnicos') html=vTecnicos();
  else if(h==='recordes') html=vRecordes();
  else if(h==='perfil') html=vPerfil();
  else if(h==='diario') {html=vDiario(); sec='perfil';}
  else if(h==='palpites') {html=vPalpites(); sec='desafios';}
  else if(h==='desafios') html=vDesafios();
  else if(h==='desafio-galodle') {html=vGalodle(); sec='desafios';}
  else if(h==='desafio-quem') {html=vQuem(); sec='desafios';}
  else if(h==='desafio-placar') {html=vPlacar(); sec='desafios';}
  else if(h==='desafio-maismenos') {html=vMaisMenos(); sec='desafios';}
  else if(h==='desafio-conexoes') {html=vConexoes(); sec='desafios';}
  else if(h==='desafio-impostor') {html=vImpostor(); sec='desafios';}
  else if(h==='desafio-carreira') {html=vCarreira(); sec='desafios';}
  else if(h==='ranking') {html=vRanking(); sec='desafios';}
  else if(h==='novo-jogo') {html=vNovoJogo(); sec='jogos';}
  else if(h==='album') html=vAlbum();
  else if(h==='dono') html=vDono();
  else if(h==='comparar') {html=vComparar(params); sec='jogadores';}
  else if(h==='competicoes') html=vCompeticoes();
  else if(h==='pergunte') html=vPergunte(params);
  else if(h==='cidades') html=vCidades();
  else if(h.startsWith('cidade-')) {html=vCidade(h.slice(7)); sec='cidades';}
  else if(h==='mapa') html=vMapa(params);
  else if(h==='viradas') {html=vViradas(params); sec='recordes';}
  else if(h==='sugestoes') html=vSugestoes(params);
  else if(h==='colaboradores') html=vColaboradores();
  else if(h==='apoie') html=vApoie();
  else if(h.startsWith('competicao-')) {html=vCompeticao(h.slice(11)); sec='competicoes';}
  else {html=vInicio(); sec='inicio';}
  try{ marcaVisita(h); }catch(e){}
  if(/^(jogo|jogador|adversario|cidade)-/.test(h)) html+=`<p class="count sug-link"><a href="#sugestoes?${new URLSearchParams({sobre:h})}">Viu um erro nesta página, ou tem um escudo ou foto para mandar? Fale com a gente →</a></p>`;
  $('#app').innerHTML=notaPagina(h)+html;
  ligaNota();
  const alvo = ['palpites','diario','ranking','album','perfil','dono','comparar','temporadas','tecnicos','recordes','mapa','pergunte','sugestoes','colaboradores','apoie'].includes(h)?h:sec;
  document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('on',a.getAttribute('href').slice(1)===alvo));
  document.querySelectorAll('#nav details').forEach(d=>{ d.removeAttribute('open'); d.classList.toggle('on', !!d.querySelector('a.on')); });
  if(!route.keep) window.scrollTo(0,0); route.keep=false;
  try{ gVisita(h); }catch(e){ console.error(e); }
  try{ pagaPalpites(); checaConquistas(); }catch(e){ console.error(e); }
}

const inline=document.getElementById('db');
(inline&&inline.textContent.trim().length>2 ? Promise.resolve(JSON.parse(inline.textContent)) : fetch('data/galo.json').then(r=>r.json())).then(d=>{
  D=d; J=d.jogos; ESC=d.escudos||{}; J.forEach(j=>byId[j.id]=j); buildAcc();
  const FONTES=[['O Canto do Galo','https://galopedia.blogspot.com'],['RSSSF Brasil','https://www.rsssfbrasil.com'],['Futebol80','https://www.futebol80.com.br'],['Galo Digital','https://www.galodigital.com.br'],['ogol','https://www.ogol.com.br'],['Transfermarkt','https://www.transfermarkt.com.br'],['Atletico.com.br','https://atletico.com.br'],['pesquisas pessoais',null]];
  $('#foot').innerHTML=`Galo Metrics · versão beta · ${N(J.length)} jogos · Atualizado em ${fmtD(d.meta.gerado_em)}<br>Fontes: ${FONTES.map(([n,u])=>u?`<a href="${u}" target="_blank" rel="noopener">${esc(n)}</a>`:esc(n)).join(' · ')}<br><a href="#sugestoes">Sugestões, correções, escudos e fotos</a> · <a href="#colaboradores">Colaboradores</a> · <a href="#apoie">♥ Apoie o Galo Metrics</a>`;
  gLoad(); window.addEventListener('hashchange',route); route(); gmInit();
}).catch(e=>{console.error(e);$('#app').innerHTML='<p class="empty">Não foi possível carregar a base de dados.</p>';});
